$content$.section.setting = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var articleNode = document.querySelector("section > div.section > article");
		var errorUl     = articleNode.querySelector("article > div.article > ul > li > ul.error");

		if (windowWidth > 736) {
			if (errorUl)  errorUl.parentNode.style.height = (windowHeight - 111) + "px";

			articleNode.style.height = (windowHeight - 91) + "px";  // 73 + 18
		} else {
			if (errorUl)  errorUl.parentNode.removeAttribute("style");

			articleNode.removeAttribute("style");
		}
	},

	service: function() {
		window.addEventListener("resize", this.resize, false);
		this.resize();

		var articleId = this.conf.articleId;
		var sectionNavSlideSize = {};

		i18n   = this.dataset.i18n;
		useOrg = this.dataset.use_org;

		if (i18n.lang != document.querySelector("html").getAttribute("lang")) {
			$jnode$.device.lang = i18n.lang;
			document.querySelector("html").setAttribute("lang", i18n.lang);

			var sectionTitles = document.querySelectorAll("body > nav > ul > li > label > input + span > font:last-child");
			sectionTitles[0].innerHTML = i18n.label_project;
			sectionTitles[1].innerHTML = i18n.label_gantt;
			sectionTitles[2].innerHTML = i18n.label_weekly;
			sectionTitles[3].innerHTML = i18n.label_monthly;
			sectionTitles[4].innerHTML = i18n.label_setting;

			$jnode$.node.setLabelLang(i18n.lang, this.conf);
			$controller$.prompt.setLabel({ok:i18n.label_ok, cancel:i18n.label_cancel});
			dateFormatter = new $module$.date.Formatter("LONG_DATE", JSON.parse(this.dataset.date_i18n));
		}

		if (startId && startId.indexOf("/setting/") == 0)  alert_precondition_required = i18n.alert_precondition_required;

		setUserSettingMenu(this.dataset.use_org);

		if (this.dataset.is_admin) {
			if (this.dataset.sync_setting && this.dataset.exclude_admin) {
				sectionNavSlideSize.shrink = "shrink_admin1";
				sectionNavSlideSize.expand = "expand_admin1";
			} else if (this.dataset.sync_setting || this.dataset.exclude_admin) {
				sectionNavSlideSize.shrink = "shrink_admin2";
				sectionNavSlideSize.expand = "expand_admin2";
			} else {
				sectionNavSlideSize.shrink = "shrink_admin3";
				sectionNavSlideSize.expand = "expand_admin3";
			}

			if (articleId == null)  articleId = "/setting/system";
		} else {
			sectionNavSlideSize.shrink = "shrink_user";
			sectionNavSlideSize.expand = "expand_user";

			if (articleId == null)  articleId = "/setting/personal";
		}

		if (articleId == "/setting/user" || articleId == "/setting/org") {
			if (useOrg)  articleId = "/setting/org";
			else         articleId = "/setting/user";
		}

		setSectionTitle(this.conf.nodeId);
		setArticleMenus(sectionNavSlideSize, articleId);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};