$content$.helpsection.ko.download = {
	service: function() {
		menuClassDiv.innerHTML = document.querySelector("body > nav > div > div ul > li > label > input:checked + span").innerHTML;
		$jnode$.pushHistory(this.conf);

		document.querySelector("div.helpsection > article > div.memo > a").addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/ko/download/donate", {
				renderer: "c-",
				title:    "기부받을 입금계좌",
				icon:     true,
				width:    200,
				height:   117
			});
		}, false);
	}
};