$content$.article.project.create = {
	service: function() {
		var that = this;
		$jnode$.pushHistory(that.conf);

		document.querySelector("body > section > div.section > nav > div:first-child").innerHTML = i18n.label_create_project;

		var memberTable = document.querySelector("article > div.article > form > table.form > tbody > tr.member > td > table");
		var leaderCell  = memberTable.querySelector("table > thead > tr > td:last-child");
		leaderCell.style.width = (leaderCell.offsetWidth - 4) + "px";
		memberTable.style.tableLayout = "fixed";

		var projectInfo = that.dataset.projectInfo;
		var startdate   = projectInfo.startdate;
		var enddate     = projectInfo.enddate;
		var startDate   = dateUtil.parse(startdate);
		var endDate     = dateUtil.parse(enddate);

		var startdateSpan     = document.querySelector("article > div.article > form > table.form > tbody > tr:nth-child(2) > td > div > span:first-of-type");
		var enddateSpan       = document.querySelector("article > div.article > form > table.form > tbody > tr:nth-child(2) > td > div > span:nth-of-type(2)");
		var startdateCalendar = document.querySelector("ul.calendar_period > li:first-child > div > ul > li > div > div.calendar");
		var enddateCalendar   = document.querySelector("ul.calendar_period > li:last-child > div > ul > li > div > div.calendar");
		var memberTbody       = memberTable.lastElementChild;
		var memberButton      = document.querySelector("article > div.article > form > table.form > tbody > tr.member > th > button");
		var okButton          = document.querySelector("article > div.article > form > ul.submit > li > button");
		var historyCalendarCallback = null;
		var useOrg = that.dataset.use_org;

		startdateSpan.innerHTML = dateFormatter.format(startDate, dateFormatter.DateStyle.LONG) + "<FONT>" + startdate + "</FONT>";
		enddateSpan.innerHTML   = dateFormatter.format(endDate, dateFormatter.DateStyle.LONG) + "<FONT>" + enddate + "</FONT>";

		displayCalendar(startDate, "date", startdateSpan, startdateCalendar, startdate, function() {
			startdateCalendar.nextElementSibling.click();
		});

		displayCalendar(endDate, "date", enddateSpan, enddateCalendar, enddate, function() {
			enddateCalendar.nextElementSibling.click();
		});

		startdateSpan.addEventListener("click", function(event) {
			if (window.innerWidth < 898) {
				enddateCalendar.nextElementSibling.click();
				startdateCalendar.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "popup");

				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyCalendarCallback = $jnode$.node.pushPseudoHistory(function() {
						startdateCalendar.nextElementSibling.click();
					});
				}
			}
		}, false);

		enddateSpan.addEventListener("click", function(event) {
			if (window.innerWidth < 898) {
				startdateCalendar.nextElementSibling.click();
				enddateCalendar.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "popup");

				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyCalendarCallback = $jnode$.node.pushPseudoHistory(function() {
						enddateCalendar.nextElementSibling.click();
					});
				}
			}
		}, false);

		startdateCalendar.nextElementSibling.addEventListener("click", function(event) {
			this.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
			if (isPhone)  document.body.style.removeProperty("overflow");
			if (historyCalendarCallback)  historyCalendarCallback();
		}, false);

		enddateCalendar.nextElementSibling.addEventListener("click", function(event) {
			this.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
			if (isPhone)  document.body.style.removeProperty("overflow");
			if (historyCalendarCallback)  historyCalendarCallback();
		}, false);

		memberButton.addEventListener("click", function(event) {
			var winupContentId = "/member/user";
			if (useOrg)  winupContentId = "/member/org";

			$jnode$.requireContent("winup", winupContentId, {
				useLoading: true,
				icon:       true,
				title:      i18n.label_select_member,
				width:      705,
				height:     360,
				unload:     true
			});
		}, false);

		$jnode$.storage.eventhandler4member = {
			open: function() {
				var memberList  = [];
				var memberCells = memberTbody.querySelectorAll("tbody > tr > td:first-child");

				for (var i = 0; i < memberCells.length; i++) {
					var memberData = {
						user_id:       memberCells[i].parentNode.getAttribute("id"),
						user_name:     memberCells[i].querySelector("td > span:first-of-type").firstChild.nodeValue,
						position_name: memberCells[i].querySelector("td > span:nth-of-type(3)").firstChild.nodeValue,
						position_id:   memberCells[i].querySelector("td > font:first-of-type").firstChild.nodeValue
					};

					if (useOrg) {
						memberData.org_name = memberCells[i].querySelector("td > span:last-of-type").firstChild.nodeValue;
						memberData.org_id   = memberCells[i].querySelector("td > font:last-of-type").firstChild.nodeValue;
					}

					memberList.push(memberData);
				}

				return memberList;
			},

			ok: function(datas, close) {
				var checkedValue = null;
				var checkedInput = memberTbody.querySelector("tbody > tr > td > input:checked");
				var dataCount    = datas.length;

				if (checkedInput) {
					checkedValue = checkedInput.value;
				}

				memberTbody.innerHTML = "";

				for (var i = 0; i < datas.length; i++) {
					var userId = datas[i].user_id;
					var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
					var row = document.createElement("tr");
					row.setAttribute("id", userId);
					memberTbody.appendChild(row);

					var orgInfo = "";
					if (useOrg)  orgInfo = " @ <SPAN>" + $jnode$.escapeXML(datas[i].org_name) + "</SPAN><FONT>" + datas[i].org_id + "</FONT>";

					var memberCell = row.insertCell(0);
					memberCell.innerHTML = (isRetiree ? i18n.label_retiree + ": " : "") + "<SPAN>" + $jnode$.escapeXML(datas[i].user_name) + "</SPAN> (<SPAN>" + $jnode$.escapeXML(isRetiree ? userId.substring(13, userId.length - 1) : userId) + "</SPAN> / <SPAN>" + $jnode$.escapeXML(datas[i].position_name) + "</SPAN><FONT>" + datas[i].position_id + "</FONT>)" + orgInfo;

					if (isRetiree)  memberCell.setAttribute("class", "retiree");

					var managerInput = document.createElement("input");
					managerInput.setAttribute("type", "radio");
					managerInput.setAttribute("name", "manager");
					managerInput.value = userId;

					var managerCell = row.insertCell(1);
					managerCell.appendChild(managerInput);
				}

				if (checkedValue) {
					var checkedMember = memberTbody.querySelector("tbody > tr > td > input[value='" + checkedValue + "']");
					if (checkedMember)  checkedMember.checked = true;
				}

				if (close)  close();
			}
		};

		if (that.dataset.member)  $jnode$.storage.eventhandler4member.ok([that.dataset.member]);

		okButton.addEventListener("click", function(event) {
			var alertMessage = null;

			var params = {
				command:      "createProject",
				project_name: document.projectForm.project_name.value,
				startdate:    startdateSpan.firstElementChild.innerHTML,
				enddate:      enddateSpan.firstElementChild.innerHTML
			};

			if (params.project_name == "") {
				alertMessage = i18n.alert_input_project_name;
				document.projectForm.project_name.focus();
			} else {
				var memberIds  = [];
				var memberRows = memberTbody.querySelectorAll("tbody > tr");

				for (var i = 0; i < memberRows.length; i++) {
					memberIds.push(memberRows[i].getAttribute("id"));
				}

				if (memberIds.length == 0) {
					alertMessage = i18n.alert_select_project_member;
					memberButton.focus();
				} else {
					params.user_id = JSON.stringify(memberIds);

					if (memberIds.length == 1) {
						params.manager = memberIds[0];
					} else {
						var checkedInput = memberTbody.querySelector("tbody > tr > td > input:checked");
						if (checkedInput)  params.manager = checkedInput.value;
						else               alertMessage = i18n.alert_select_project_manager;
					}
				}
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				if (params.startdate > params.enddate) {
					var tempEnddate = params.startdate;
					params.startdate = params.enddate;
					params.enddate   = tempEnddate;
				}

				$jnode$.ajax.service({
					"url":      "/ajax/project.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var projectId = response.project_id;

						if (projectId == 0) {
							// 다시 생성하는 화면으로...
							document.querySelector("body > section > div.section > nav > fieldset > ul > li > div > ul > li:first-child > ul > li:first-child > button:first-child").click();
						} else {
							startId = "";
							alert_precondition_required = null;

							params.project_id = projectId;
							$content$.section.project.appendProject(params, null, true);
						}
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.projectForm.project_name.focus();
	},

	unload: function() {
		delete $jnode$.storage.eventhandler4member;
	}
};