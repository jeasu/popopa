/*
 * @(#)pohe_kr.u.mui.MUI.js  1.0, 2012-09-03
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-09-03
 */
$$js_namespace$$("pohe_kr.u.mui");

/**
 * The Local Internationalization Object of POHE.
 * <BR/><BR/>
 * 
 * If your local language is not English or Korean, you should customize the contents of this file.
 */
pohe_kr.u.mui.MUI = {
	button : {
		cancel : {
			title : "Cancel",
			styleclass : "red"
		},

		close : {
			title : "Close",
			styleclass : "blue"
		},

		complete : {
			title : "Complete",
			styleclass : "blue"
		},

		more : {
			title : "More...",
			styleclass : "blue"
		},

		ok : {
			title : "OK",
			styleclass : "blue"
		}
	},

	popup : {
		calendar : "Calendar",
		color : "Color"
	}
};