if (window.parent.stopRefresh15)  window.parent.stopRefresh15();

if (resultMessage) {
	resultMessage = $module$.base64.decode(resultMessage);

	if (resultMessage == "SUCCESS") {
		window.parent.$controller$.winup.close();
		window.parent.handleHash("#article:/setting/about");
	} else {
		window.parent.$controller$.prompt.alert(resultMessage);
		window.parent.$controller$.loading.hide();
	}
} else {
	window.parent.$controller$.loading.hide();
}

alertSelectPuzFile = $module$.base64.decode(alertSelectPuzFile);

document.querySelector("body > form > ul > li:last-child > button").addEventListener("click", function(event) {
	var puzValue = document.upgradeForm.puz.value;

	if (puzValue.search(/\.puz$/i) < 0) {
		this.parentNode.previousElementSibling.innerHTML = alertSelectPuzFile;
	} else {
		window.parent.refresh15();  // 15초가 지나도 로딩중이면 강제로 새로고침
		window.parent.$controller$.loading.show();
		window.parent.document.querySelector("body > aside.winup.open").setAttribute("class", "winup");
		document.upgradeForm.submit();
	}
}, false);