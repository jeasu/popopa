function handleHash(hash, nodeConf) {
	var separatedHashs = hash.split(":");
	var nodeType       = separatedHashs[0].substring(1);
	var nodeId         = separatedHashs[1];

	if (nodeType == "helpsection") {
		var menuInput = document.querySelector("body > nav > div > div ul > li > label > input[name='menu'][value='" + nodeId + "']");
		menuInput.checked = true;
		$jnode$.requireContent("helpsection", nodeId, {useLoading:true, renderer:"-j"});
	}
}

var historyHandler = {
	handler: handleHash
}

function openParentNode(node) {
	var parentNode = node.parentNode.parentNode.previousElementSibling;
	if (parentNode)  parentNode.setAttribute("class", "opened");
	return parentNode;
}

function openSection(sectionId) {
	var lang = document.langForm.lang.value;

	if (sectionId.indexOf("/") != 0)  sectionId = "/" + sectionId;
	if (sectionId.indexOf("/" + lang) != 0)  sectionId = "/" + lang + sectionId;

	var sectionMenu = document.querySelector("body > nav > div > div ul > li > label > input[value='" + sectionId + "']");
	if (sectionMenu) {
		sectionMenu.checked = true;
		$jnode$.requireContent("helpsection", sectionId, {useLoading:true, renderer:"-j"});
	}
}