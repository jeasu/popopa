$$js_import$$("pohe_kr.v.direct.table.Resolver");
$$css_refer$$("pohe_kr.v.direct.table", false, __$$screen_mode$$__ == "m");