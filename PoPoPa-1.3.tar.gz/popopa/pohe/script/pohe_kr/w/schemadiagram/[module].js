$$js_import$$("pohe_kr.u.HTMLElementUtil");
$$js_import$$("pohe_kr.u.JsonUtil");
$$js_import$$("pohe_kr.u.XmlUtil");
$$js_import$$("pohe_kr.w.schemadiagram.Resolver");
$$js_import$$("pohe_kr.w.schemadiagram.Service");
$$js_import$$("pohe_kr.w.schemadiagram.Style");