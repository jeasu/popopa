$content$.winup.setting.org.edit = {
	service: function() {
		var topOrg    = this.conf.top_org;  // 삭제된 부서원들을 최상위 부서로 이동하기 위해
		var orgId     = this.conf.org_id;
		var orgName   = this.conf.org_name;
		var orgParent = this.conf.org_parent;

		document.orgForm.org_name.value = orgName;

		document.orgForm.querySelector("form > ul.submit > li > button:first-child").addEventListener("click", function(event) {
			var params = {
				command:  "updateOrg",
				org_id:   orgId,
				org_name: document.orgForm.org_name.value
			};

			var alertMessage    = null;

			if (params.org_name == "") {
				alertMessage = i18n.alert_input_org_name;
				document.orgForm.org_name.focus();
			}
			
			if (alertMessage) {
				document.orgForm.querySelector("form > ul.submit > li.alert").innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/org.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$controller$.tree.change(params, orgId);
						$controller$.tree.click(orgId);

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		var deleteButton = document.orgForm.querySelector("form > ul.submit > li > button:last-child");
		if (orgParent == null)  deleteButton.disabled = true;

		deleteButton.addEventListener("click", function(event) {
			$controller$.prompt.confirm(i18n.confirm_delete_org, function(close) {
				$controller$.loading.show();

				var deletedIds     = [orgId];
				var treeContainers = document.querySelector("aside.tree ul > li > span.selected").nextElementSibling.querySelectorAll("div > ul[id]");

				for (var i = 0; i < treeContainers.length; i++) {
					deletedIds.push(treeContainers[i].getAttribute("id"));
				}

				$jnode$.ajax.service({
					"url":      "/ajax/org.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command:    "deleteOrg",
						top_org:    topOrg,
						org_id:     orgId,
						deleted_id: deletedIds.join(","),
						org_parent: orgParent
					},
					"success": function(response) {
						$controller$.tree.remove(orgId);
						$controller$.tree.click(orgParent);

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				close();
			});
		}, false);
	}
};