$$module_import$$("pohe_kr.m.button"     , pohe_kr.u.Script.resolve);
$$module_import$$("pohe_kr.m.list"       , pohe_kr.u.Script.resolve);
$$module_import$$("pohe_kr.m.sidebar"    , pohe_kr.u.Script.resolve);
$$module_import$$("pohe_kr.m.select"     , pohe_kr.u.Script.resolve);
$$module_import$$("pohe_kr.m.slider"     , pohe_kr.u.Script.resolve);
$$module_import$$("pohe_kr.m.slidingmenu", pohe_kr.u.Script.resolve);
$$module_import$$("pohe_kr.m.switcher"   , pohe_kr.u.Script.resolve);