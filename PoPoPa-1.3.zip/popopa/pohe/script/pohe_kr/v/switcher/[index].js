$$js_import$$("pohe_kr.v.switcher.Mapping");
$$js_import$$("pohe_kr.v.switcher.Resolver");