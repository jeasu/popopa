if (resultMessage) {
	resultMessage = $module$.base64.decode(resultMessage);

	if (resultMessage == "SUCCESS") {
		window.parent.$controller$.winup.close();
		window.parent.handleHash("#article:/setting/about");
	} else {
		window.parent.$controller$.prompt.alert(resultMessage);
		window.parent.$controller$.loading.hide();
	}
} else {
	window.parent.$controller$.loading.hide();
}

alertSelectPuzFile = $module$.base64.decode(alertSelectPuzFile);

document.querySelector("body > form > ul > li:last-child > button").addEventListener("click", function(event) {
	var puzValue = document.upgradeForm.puz.value;

	if (puzValue.search(/\.puz$/i) < 0) {
		this.parentNode.previousElementSibling.innerHTML = alertSelectPuzFile;
	} else {
		window.parent.$controller$.loading.show();
		document.upgradeForm.submit();
	}
}, false);