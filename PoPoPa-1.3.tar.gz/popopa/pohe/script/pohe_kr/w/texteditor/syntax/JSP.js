/*
 * @(#)pohe_kr.w.texteditor.syntax.JSP.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.texteditor.syntax");

/**
 * TEXT 문자열에 JSP 타입으로 color syntax를 보여주는 객체.
 * <BR/><BR/>
 * 
 * this 객체는 내부적으로 아래의 객체들을 사용해서 구현했다. 따라서, 이들 객체들도 같이 import를 해야 제대로 color syntax가 적용된 화면을 볼 수 있다.
 * 
 * <UL>
 *   <LI><CODE>pohe_kr.w.texteditor.syntax.CSS</CODE></LI>
 *   <LI><CODE>pohe_kr.w.texteditor.syntax.HTML</CODE></LI>
 *   <LI><CODE>pohe_kr.w.texteditor.syntax.JAVA</CODE></LI>
 *   <LI><CODE>pohe_kr.w.texteditor.syntax.JS</CODE></LI>
 *   <LI><CODE>pohe_kr.w.texteditor.syntax.XML</CODE></LI>
 * </Ul>
 */
pohe_kr.w.texteditor.syntax.JSP = {

	/**
	 * TEXT 문자열에 JSP 타입으로 설정할 syntax color.
	 */
	ColorSyntax: {
		"jspcomments":  "#3F7F5F",
		"jspscripting": "#BF5F3F"
	},

	/**
	 * TEXT 문자열을 JSP 타입으로 color syntax를 준다.
	 *
	 * @param  {String} text  {@nullable false} JSP 타입으로 color syntax를 줄 TEXT 문자열
	 * @return {String} JSP 타입으로 color syntax를 준 HTML 코드
	 */
	getColorSyntax: function(text) {
		var colorSyntaxJspcomments=pohe_kr.w.texteditor.syntax.JSP.ColorSyntax.jspcomments;var colorSyntaxJspscripting=pohe_kr.w.texteditor.syntax.JSP.ColorSyntax.jspscripting;var colorSyntaxDirectives=pohe_kr.w.texteditor.syntax.XML.ColorSyntax.element;var colorSyntaxAttributename=pohe_kr.w.texteditor.syntax.XML.ColorSyntax.attributename;var colorSyntaxAttributevalue=
pohe_kr.w.texteditor.syntax.XML.ColorSyntax.attributevalue;if(pohe_kr.w.texteditor.syntax.XML==null){alert('Please import "pohe_kr.w.texteditor.syntax.XML".');return pohe_kr.w.texteditor.syntax.$$default$$.getColorSyntax(text)}var objCommentsReg={};var objExpressionReg={};var objDirectivesReg={};var objDeclarationsReg={};var objScriptletsReg={};if(pohe_kr.w.texteditor.syntax.JAVA==null)alert('Please import "pohe_kr.w.texteditor.syntax.JAVA".');else{var matched=text.match(new RegExp("<%[\\s\\S]*?%>",
"gmi"));if(matched)for(var i=0;i<matched.length;i++)if(matched[i].indexOf("--")==2&&matched[i].lastIndexOf("--")==matched[i].length-4){objCommentsReg["<%--[[-- jsp comments syntax "+i+" --]]--%>"]=matched[i];text=text.replace(matched[i],"<%--[[-- jsp comments syntax "+i+" --]]--%>")}else if(matched[i].indexOf("=")==2){objExpressionReg["<%=[[-- jsp expression syntax "+i+" --]]%>"]=matched[i].substring(3,matched[i].length-2);text=text.replace(matched[i],"<%=[[-- jsp expression syntax "+i+" --]]%>")}else if(matched[i].indexOf("@")==
2){objDirectivesReg["<%@[[-- jsp directives syntax "+i+" --]]%>"]=matched[i].substring(3,matched[i].length-2);text=text.replace(matched[i],"<%@[[-- jsp directives syntax "+i+" --]]%>")}else if(matched[i].indexOf("!")==2){objDeclarationsReg["<%![[-- jsp declarations syntax "+i+" --]]%>"]=matched[i].substring(3,matched[i].length-2);text=text.replace(matched[i],"<%![[-- jsp declarations syntax "+i+" --]]%>")}else{objScriptletsReg["<%[[-- jsp scriptlets syntax "+i+" --]]%>"]=matched[i].substring(2,matched[i].length-
2);text=text.replace(matched[i],"<%[[-- jsp scriptlets syntax "+i+" --]]%>")}}var objScriptReg={};var scriptMatched=text.match(new RegExp("<[\\w]+:script[\\s]*>[\\s\\S]*?</[\\w]+:script>|<[\\w]+:[\\w]+_eval[\\s|>]?[\\s\\S]*?</[\\w]+:[\\w]+_eval>","gmi"));if(scriptMatched)for(var i=0;i<scriptMatched.length;i++){var startIndex=scriptMatched[i].indexOf(">");var endIndex=scriptMatched[i].lastIndexOf("<");if(startIndex>0&&startIndex<endIndex-1){objScriptReg["[[-- js script syntax for pohe "+i+" --]]"]=
scriptMatched[i].substring(startIndex+1,endIndex);text=text.replace(scriptMatched[i],scriptMatched[i].substring(0,startIndex+1)+"[[-- js script syntax for pohe "+i+" --]]"+scriptMatched[i].substring(endIndex))}}text=pohe_kr.w.texteditor.syntax.HTML.getColorSyntax(text.replace(/\$/g,"$$$$"));for(var key in objScriptReg)text=text.replace(key,pohe_kr.w.texteditor.syntax.JS.getColorSyntax(objScriptReg[key]).replace(/\$/g,"$$$$"));for(var key in objScriptletsReg)text=text.replace(key.replace(/\</g,"&lt;").replace(/\>/g,
"&gt;"),'<FONT color="'+colorSyntaxJspscripting+'">&lt;%</FONT>'+pohe_kr.w.texteditor.syntax.JAVA.getColorSyntax(objScriptletsReg[key]).replace(/\$/g,"$$$$")+'<FONT color="'+colorSyntaxJspscripting+'">%&gt;</FONT>');for(var key in objDeclarationsReg)text=text.replace(key.replace(/\</g,"&lt;").replace(/\>/g,"&gt;"),'<FONT color="'+colorSyntaxJspscripting+'">&lt;%!</FONT>'+pohe_kr.w.texteditor.syntax.JAVA.getColorSyntax(objDeclarationsReg[key]).replace(/\$/g,"$$$$")+'<FONT color="'+colorSyntaxJspscripting+
'">%&gt;</FONT>');for(var key in objDirectivesReg)text=text.replace(key.replace(/\</g,"&lt;").replace(/\>/g,"&gt;"),'<FONT color="'+colorSyntaxJspscripting+'">&lt;%@</FONT>'+getDirectivesSyntax(objDirectivesReg[key]).replace(/\$/g,"$$$$")+'<FONT color="'+colorSyntaxJspscripting+'">%&gt;</FONT>');for(var key in objExpressionReg)text=text.replace(key.replace(/\</g,"&lt;").replace(/\>/g,"&gt;"),'<FONT color="'+colorSyntaxJspscripting+'">&lt;%=</FONT>'+pohe_kr.w.texteditor.syntax.JAVA.getColorSyntax(objExpressionReg[key]).replace(/\$/g,
"$$$$")+'<FONT color="'+colorSyntaxJspscripting+'">%&gt;</FONT>');for(var key in objCommentsReg)text=text.replace(key.replace(/\</g,"&lt;").replace(/\>/g,"&gt;"),'<FONT color="'+colorSyntaxJspcomments+'">'+objCommentsReg[key].replace(/\&/g,"&amp;").replace(/\</g,"&lt;").replace(/\>/g,"&gt;").replace(/\"/g,"&quot;").replace(/\'/g,"&#39;").replace(/\r\n/g,"\n").replace(/\n/g,"<BR />").replace(/\s\<BR \/\>/g,"&nbsp;<BR />").replace(/\s\s/g,"&nbsp; ").replace(/\$/g,"$$$$")+"</FONT>");function getDirectivesSyntax(value){var textValue=
"";var directivesTitle=value.match(new RegExp("[\\s]*(page|taglib|include)\\s","gm"));if(directivesTitle){var titleLength=directivesTitle[0].length-1;textValue='<FONT color="'+colorSyntaxDirectives+'">'+value.substring(0,titleLength)+"</FONT>"+getAttributeSyntax(value.substring(titleLength))}else textValue=getAttributeSyntax(value);return textValue}function getAttributeSyntax(value){var textValue=value;var attrValueMatched=value.match(new RegExp("[\\w]+=((\"[^\"]*\")|('[^']*'))","gm"));if(attrValueMatched)for(var i=
0;i<attrValueMatched.length;i++){var keyValues=attrValueMatched[i].split("=",2);if(keyValues.length==2)textValue=textValue.replace(attrValueMatched[i],'<FONT color="'+colorSyntaxAttributename+'">'+keyValues[0]+'</FONT>=<FONT color="'+colorSyntaxAttributevalue+'">'+keyValues[1].replace(/\"/g,"&quot;").replace(/\'/g,"&#39;")+"</FONT>")}return textValue}return text
	}
};