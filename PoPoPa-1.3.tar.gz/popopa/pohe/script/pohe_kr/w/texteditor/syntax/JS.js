/*
 * @(#)pohe_kr.w.texteditor.syntax.JS.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.texteditor.syntax");

/**
 * TEXT 문자열에 JavaScript 타입으로 color syntax를 보여주는 객체.
 */
pohe_kr.w.texteditor.syntax.JS = {

	/**
	 * TEXT 문자열에 JavaScript 타입으로 설정할 syntax color.
	 */
	ColorSyntax: {
		"comments": "#3F7F5F",
		"keyword":  "#7F007F",
		"string":   "#2A00FF"
	},

	/**
	 * TEXT 문자열을 JavaScript 타입으로 color syntax를 준다.
	 *
	 * @param  {String} text  {@nullable false} JavaScript 타입으로 color syntax를 줄 TEXT 문자열
	 * @return {String} JavaScript 타입으로 color syntax를 준 HTML 코드
	 */
	getColorSyntax: function(text) {
		var colorSyntaxComments=pohe_kr.w.texteditor.syntax.JS.ColorSyntax.comments;var colorSyntaxKeyword=pohe_kr.w.texteditor.syntax.JS.ColorSyntax.keyword;var colorSyntaxString=pohe_kr.w.texteditor.syntax.JS.ColorSyntax.string;text=" "+text.replace(/\&/g,"&amp;").replace(/\</g,"&lt;").replace(/\>/g,"&gt;").replace(/\\"/g,"\\&quot;").replace(/\\'/g,"\\&#39;").replace(/\\\\&quot;/g,
'\\\\"').replace(/\\\\&#39;/g,"\\\\'")+" ";var blockCommentsMatched=text.match(new RegExp("/\\*[\\s\\S]*?\\*/","gm"));var objBlockCommentsReg={};if(blockCommentsMatched)for(var i=0;i<blockCommentsMatched.length;i++){objBlockCommentsReg["/* block comments "+i+" */"]=blockCommentsMatched[i];text=text.replace(blockCommentsMatched[i],"<FONT color="+colorSyntaxComments+">/* block comments "+i+" */</FONT>")}var stringValueMatched=text.match(new RegExp("(\"[^\"|\n]*\")|('[^'|\n]*')","gm"));var objStringValueReg=
{};text=text.replace(/\"/g,"&quot;").replace(/\'/g,"&#39;");if(stringValueMatched){for(var i=0;i<stringValueMatched.length;i++){var stringValueValue=stringValueMatched[i].replace(/\"/g,"&quot;").replace(/\'/g,"&#39;");var skipObjStringValueReg=false;var blockCommentsCheckMatched=stringValueValue.match(new RegExp("<FONT color="+colorSyntaxComments+">/\\* block comments\\s.*\\s\\*/</FONT>","gm"));if(blockCommentsCheckMatched){var blockCommentsCheckMatcheds=[];setBlockCommentsCheckMatcheds(blockCommentsCheckMatcheds,
blockCommentsCheckMatched[0]);for(var j=0;j<blockCommentsCheckMatcheds.length;j++){var replacedValue=objBlockCommentsReg[blockCommentsCheckMatcheds[j].substring(20,blockCommentsCheckMatcheds[j].length-7)];if(replacedValue==null){skipObjStringValueReg=true;break}stringValueValue=stringValueValue.replace(blockCommentsCheckMatcheds[j],replacedValue.replace(/\$/g,"$$$$"))}}if(skipObjStringValueReg==false){objStringValueReg["&quot; string value "+i+" &quot;"]=stringValueValue;text=text.replace(stringValueMatched[i].replace(/\"/g,
"&quot;").replace(/\'/g,"&#39;"),"<FONT color="+colorSyntaxString+">&quot; string value "+i+" &quot;</FONT>")}}function setBlockCommentsCheckMatcheds(blockCommentsCheckMatcheds,blockCommentsCheckMatchedValue){var endIndex=blockCommentsCheckMatchedValue.indexOf("*/</FONT>");if(endIndex>0)if(blockCommentsCheckMatchedValue.length-9>endIndex){blockCommentsCheckMatcheds.push(blockCommentsCheckMatchedValue.substring(0,endIndex+9));var startIndex=blockCommentsCheckMatchedValue.indexOf("<FONT color="+colorSyntaxComments+
">/* block comments ",endIndex+9);if(startIndex>0)setBlockCommentsCheckMatcheds(blockCommentsCheckMatcheds,blockCommentsCheckMatchedValue.substring(startIndex))}else blockCommentsCheckMatcheds.push(blockCommentsCheckMatchedValue)}}var lineCommentsMatched=text.match(new RegExp("//.*\n","gm"));var objLineCommentsReg={};if(lineCommentsMatched)for(var i=0;i<lineCommentsMatched.length;i++){var lineCommentsValue=lineCommentsMatched[i];var skipObjLineCommentsReg=false;var stringValueCheckMatched=lineCommentsValue.match(new RegExp("<FONT color="+
colorSyntaxString+">&quot; string value\\s.*\\s&quot;</FONT>","gm"));if(stringValueCheckMatched){var stringValueCheckMatcheds=[];setStringValueCheckMatcheds(stringValueCheckMatcheds,stringValueCheckMatched[0]);for(var j=0;j<stringValueCheckMatcheds.length;j++){var replacedValue=objStringValueReg[stringValueCheckMatcheds[j].substring(20,stringValueCheckMatcheds[j].length-7)];if(replacedValue==null||replacedValue.indexOf("\n")>0){skipObjLineCommentsReg=true;break}lineCommentsValue=lineCommentsValue.replace(stringValueCheckMatcheds[j],
replacedValue.replace(/\$/g,"$$$$"))}}function setStringValueCheckMatcheds(stringValueCheckMatcheds,stringValueCheckMatchedValue){var endIndex=stringValueCheckMatchedValue.indexOf("&quot;</FONT>");if(endIndex>0)if(stringValueCheckMatchedValue.length-13>endIndex){stringValueCheckMatcheds.push(stringValueCheckMatchedValue.substring(0,endIndex+13));var startIndex=stringValueCheckMatchedValue.indexOf("<FONT color="+colorSyntaxString+">&quot; string value ",endIndex+13);if(startIndex>0)setStringValueCheckMatcheds(stringValueCheckMatcheds,
stringValueCheckMatchedValue.substring(startIndex))}else stringValueCheckMatcheds.push(stringValueCheckMatchedValue)}if(skipObjLineCommentsReg==false){objLineCommentsReg["// line comments "+i+"\n"]=lineCommentsValue;text=text.replace(lineCommentsMatched[i],'<FONT color="'+colorSyntaxComments+'">// line comments '+i+"\n</FONT>")}}var delimeter="[\\s|,|\\(|\\)|{|}|\\]|\\[|\\-|+|*|%|/|=|~|!|&|<|>|?|:|;|.||]";var keywords=["abstract","break","case","catch","class","const","continue","default","delete",
"do","else","extends","false","final","finally","for","function","goto","if","implements","in","instanceof","interface","new","null","package","private","protected","public","return","static","super","switch","synchronized","this","throw","throws","transient","true","try","typeof","var","while","with"];for(var i=0;i<keywords.length;i++){var keywordMatched=text.match(new RegExp(delimeter+keywords[i]+delimeter,"gm"));var objKeywordReg={};if(keywordMatched)for(var j=0;j<keywordMatched.length;j++)objKeywordReg[keywordMatched[j]]=
true;for(var key in objKeywordReg){var replacedKey=key.replace(/\//g,"\\/").replace(/\?/g,"\\?").replace(/\$/g,"\\$").replace(/\{/g,"\\{").replace(/\}/g,"\\}").replace(/\[/g,"\\[").replace(/\]/g,"\\]").replace(/\*/g,"\\*").replace(/\(/g,"\\(").replace(/\)/g,"\\)").replace(/\|/g,"\\|").replace(/\+/g,"\\+");text=text.replace(new RegExp(replacedKey,"gm"),key.substring(0,1)+'<FONT color="'+colorSyntaxKeyword+'">'+key.substring(1,key.length-1)+"</FONT>"+key.substring(key.length-1))}}for(var key in objStringValueReg)text=
text.replace("<FONT color="+colorSyntaxString+">"+key+"</FONT>",'<FONT color="'+colorSyntaxString+'">'+objStringValueReg[key].replace(/\$/g,"$$$$")+"</FONT>");for(var key in objLineCommentsReg)text=text.replace('<FONT color="'+colorSyntaxComments+'">'+key+"</FONT>",'<FONT color="'+colorSyntaxComments+'">'+objLineCommentsReg[key].replace(/\$/g,"$$$$")+"</FONT>");for(var key in objBlockCommentsReg)text=text.replace("<FONT color="+colorSyntaxComments+">"+key+"</FONT>",'<FONT color="'+colorSyntaxComments+
'">'+objBlockCommentsReg[key].replace(/\"/g,"&quot;").replace(/\'/g,"&#39;").replace(/\$/g,"$$$$")+"</FONT>");return text.substring(1,text.length-1).replace(/\r\n/g,"\n").replace(/\n/g,"<BR />").replace(/\s\<BR \/\>/g,"&nbsp;<BR />").replace(/\s\s/g,"&nbsp; ")
	}
};