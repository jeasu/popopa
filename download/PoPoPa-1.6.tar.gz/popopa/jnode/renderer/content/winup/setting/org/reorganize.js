$content$.winup.setting.org.reorganize = {
	applyMoved: true,
	objMovedUser: {},

	applyParentTree: function() {
		var that       = this;
		var treeId     = document.querySelector("aside.tree:not([id]) ul > li > span.selected").parentNode.parentNode.getAttribute("id");
		var equalLeft  = document.querySelector("aside.tree#left ul > li > span.selected").parentNode.parentNode.getAttribute("id") == treeId;
		var equalRight = document.querySelector("aside.tree#right ul > li > span.selected").parentNode.parentNode.getAttribute("id") == treeId;

		if (Object.keys(that.objMovedUser).length) {
			$controller$.loading.show();

			var params = {
				command: "moveAndGetUserList"
			};

			var movedInfos = [];
			for (var key in that.objMovedUser) {
				movedInfos.push(key + ":" + that.objMovedUser[key]);
			}

			params.moved_info = movedInfos.join(",");
			that.objMovedUser = {};

			$jnode$.ajax.service({
				"url":      "/ajax/user.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  params,
				"success": function(response) {
					if (equalLeft || equalRight)  $controller$.tree.click(treeId);
					else                          $controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}
	},

	service: function() {
		var that = this;

		var leftUserUl          = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:first-child > div:last-child > ul");
		var rightUserUl         = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child > div:last-child > ul");
		var moveRightButton1    = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:nth-child(2) > button:first-child");
		var moveLeftButton1     = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:nth-child(2) > button:last-child");
		var moveRightButton2    = document.querySelector("aside.winup article > div.winup > ul:last-child > li:last-child > button:first-child");
		var moveLeftButton2     = document.querySelector("aside.winup article > div.winup > ul:last-child > li:last-child > button:nth-child(2)");
		var selectOrgButton     = document.querySelector("aside.winup article > div.winup > ul:last-child > li:first-child > button");
		var leftOrgCloseButton  = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:first-child > div:first-child > ul > li > div > button");
		var rightOrgCloseButton = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child > div:first-child > ul > li > div > button");
		var historyOrgSelectCallback = null;

		moveRightButton1.disabled = true;
		moveRightButton2.disabled = true;
		moveLeftButton1.disabled  = true;
		moveLeftButton2.disabled  = true

		$jnode$.requireControllers(["tree#left", "tree#right"], {caller:that.conf}, function() {
			var orgDatas     = that.dataset.orgDatas;
			var leftOrgId    = that.conf.left_org;
			var rightOrgId   = that.conf.right_org;
			var currentOrgId = leftOrgId;
			var tabInputs    = document.querySelectorAll("aside.winup article > div.winup > ul:first-child > li > label > input");

			function setTreeText(entrySet) {
				var textDiv = document.createElement("div");
				textDiv.setAttribute("class", (entrySet.org_parent ? "org" : "company"));
				textDiv.appendChild(document.createTextNode(entrySet.org_name));

				return textDiv;
			}

			function setTreeList(entrySet) {
				var list = entrySet.sub_org;
				return ((list && list.length) ? list : null);
			}

			function addListClickListener(userLi) {
				userLi.addEventListener("click", function(event) {
					if (this.getAttribute("class") == "checked") {
						this.removeAttribute("class");
					} else {
						this.setAttribute("class", "checked");
					}
				}, false);
			}

			function setUserList(userUl, userList) {
				userUl.innerHTML = "";

				for (var i = 0; i < userList.length; i++) {
					var userLi = document.createElement("li");
					userLi.innerHTML = "<SPAN>" + $jnode$.escapeXML(userList[i].user_name) + "</SPAN> (<SPAN>" + $jnode$.escapeXML(userList[i].user_id) + "</SPAN> / <SPAN>" + $jnode$.escapeXML(userList[i].position_name) + "</SPAN><FONT>" + userList[i].position_id + "</FONT>)";
					userUl.appendChild(userLi);

					addListClickListener(userLi);
				}
			}

			function handleTreeClick(userUl, orgId) {
				if (leftOrgId == rightOrgId) {
					moveRightButton1.disabled = true;
					moveRightButton2.disabled = true;
					moveLeftButton1.disabled  = true;
					moveLeftButton2.disabled  = true
				} else {
					moveRightButton1.disabled = false;
					moveRightButton2.disabled = false;
					moveLeftButton1.disabled  = false;
					moveLeftButton2.disabled  = false
				}

				$controller$.loading.show();

				var params = {
					"org_id": orgId
				};

				if (Object.keys(that.objMovedUser).length == 0) {
					params.command = "getUserList";
				} else {
					params.command = "moveAndGetUserList";

					var movedInfos = [];
					for (var key in that.objMovedUser) {
						movedInfos.push(key + ":" + that.objMovedUser[key]);
					}

					params.moved_info = movedInfos.join(",");
					that.objMovedUser = {};
				}

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						setUserList(userUl, response);

						if (params.command == "moveAndGetUserList" && that.applyMoved) {
							$controller$.tree.click(currentOrgId);
						} else {
							$controller$.loading.hide();
						}
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}

			function addTreeLeftClickListener(textNode, entrySet) {
				leftOrgCloseButton.click();
				// document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:first-child").removeAttribute("class");

				if (leftOrgId != entrySet.org_id) {
					if (currentOrgId == leftOrgId || currentOrgId == rightOrgId)  that.applyMoved = true;
					else                                                          that.applyMoved = false;

					leftOrgId = entrySet.org_id;

					var selectedNode = document.querySelector("aside.tree#left ul > li > span.selected");
					if (selectedNode) {
						selectedNode.removeAttribute("class");
					}

					textNode.setAttribute("class", "selected");
					tabInputs[0].nextElementSibling.innerHTML = $jnode$.escapeXML(entrySet.org_name);

					handleTreeClick(leftUserUl, entrySet.org_id);
				}
			}

			function addTreeRightClickListener(textNode, entrySet) {
				rightOrgCloseButton.click();
				// document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child").removeAttribute("class");

				if (rightOrgId != entrySet.org_id) {
					if (currentOrgId == leftOrgId || currentOrgId == rightOrgId)  that.applyMoved = true;
					else                                                          that.applyMoved = false;

					rightOrgId = entrySet.org_id;

					var selectedNode = document.querySelector("aside.tree#right ul > li > span.selected");
					if (selectedNode) {
						selectedNode.removeAttribute("class");
					}

					textNode.setAttribute("class", "selected");
					tabInputs[1].nextElementSibling.innerHTML = $jnode$.escapeXML(entrySet.org_name);

					handleTreeClick(rightUserUl, entrySet.org_id);
				}
			}

			$controller$["tree#left"].service({
				datas:     orgDatas,
				id:        function(entrySet) { return entrySet.org_id; },
				text:      setTreeText,
				list:      setTreeList,
				click:     addTreeLeftClickListener,
				unfoldAll: true
			});

			$controller$["tree#right"].service({
				datas:     orgDatas,
				id:        function(entrySet) { return entrySet.org_id; },
				text:      setTreeText,
				list:      setTreeList,
				click:     addTreeRightClickListener,
				unfoldAll: true
			});

			// $controller$["tree#left"].click(leftOrgId);
			// $controller$["tree#right"].click(rightOrgId);
			document.querySelector("aside.tree#left ul[id='" + leftOrgId + "'] > li > span").setAttribute("class", "selected");
			document.querySelector("aside.tree#right ul[id='" + rightOrgId + "'] > li > span").setAttribute("class", "selected");

			tabInputs[0].nextElementSibling.innerHTML = document.querySelector("aside.tree#left ul[id='" + leftOrgId + "'] > li > span > div").innerHTML;
			tabInputs[1].nextElementSibling.innerHTML = document.querySelector("aside.tree#left ul[id='" + rightOrgId + "'] > li > span > div").innerHTML;

			if (leftOrgId != rightOrgId) {
				moveRightButton1.disabled = false;
				moveRightButton2.disabled = false;
				moveLeftButton1.disabled  = false;
				moveLeftButton2.disabled  = false
			}

			setUserList(leftUserUl, that.dataset.left_userList);
			setUserList(rightUserUl, that.dataset.right_userList);

			function moveOrg(sourceUl, targetUl, sourceId, targetId) {
				var checkedUserSpans = sourceUl.querySelectorAll("ul > li.checked > span:nth-of-type(2)");

				for (var i = 0; i < checkedUserSpans.length; i++) {
					var userId = checkedUserSpans[i].firstChild.nodeValue;
					var userLi = checkedUserSpans[i].parentNode;

					userLi.removeAttribute("class");
					targetUl.appendChild(userLi);

					// 설정된 적이 사용자를 다시 이동한 경우는 원래 위치로 돌아오는 것이므로 that.objMovedUser에서 지운다.
					if (that.objMovedUser[userId] == sourceId)  delete that.objMovedUser[userId];
					else                                        that.objMovedUser[userId] = targetId;
				}
			}

			moveRightButton1.addEventListener("click", function(event) {
				moveOrg(leftUserUl, rightUserUl, leftOrgId, rightOrgId);
			}, false);

			moveRightButton2.addEventListener("click", function(event) {
				moveOrg(leftUserUl, rightUserUl, leftOrgId, rightOrgId);
			}, false);

			moveLeftButton1.addEventListener("click", function(event) {
				moveOrg(rightUserUl, leftUserUl, rightOrgId, leftOrgId);
			}, false);

			moveLeftButton2.addEventListener("click", function(event) {
				moveOrg(rightUserUl, leftUserUl, rightOrgId, leftOrgId);
			}, false);

			for (var i = 0; i < tabInputs.length; i++) {
				tabInputs[i].addEventListener("click", function(event) {
					var leftTab  = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:first-child");
					var rightTab = document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child");

					if (this.value == "left") {
						leftTab.removeAttribute("class");
						rightTab.setAttribute("class", "hidden");

						moveRightButton2.removeAttribute("class");
						moveLeftButton2.setAttribute("class", "hidden");
					} else {
						leftTab.setAttribute("class", "hidden");
						rightTab.removeAttribute("class");

						moveRightButton2.setAttribute("class", "hidden");
						moveLeftButton2.removeAttribute("class");
					}
				}, false);
			}

			tabInputs[0].click();

			selectOrgButton.addEventListener("click", function(event) {
				if (tabInputs[0].checked) {
					if (isPhone) {
						document.body.style.overflow = "hidden";

						historyOrgSelectCallback = $jnode$.node.pushPseudoHistory(function() {
							leftOrgCloseButton.click();
						});
					}

					document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:first-child").setAttribute("class", "open_org");
				} else {
					if (isPhone) {
						document.body.style.overflow = "hidden";

						historyOrgSelectCallback = $jnode$.node.pushPseudoHistory(function() {
							rightOrgCloseButton.click();
						});
					}

					document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child").setAttribute("class", "open_org");
				}
			}, false);

			leftOrgCloseButton.addEventListener("click", function(event) {
				if (isPhone) {
					document.body.style.removeProperty("overflow");
					if (historyOrgSelectCallback)  historyOrgSelectCallback();
				}

				document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:first-child").removeAttribute("class");
			}, false);

			rightOrgCloseButton.addEventListener("click", function(event) {
				if (isPhone) {
					document.body.style.removeProperty("overflow");
					if (historyOrgSelectCallback)  historyOrgSelectCallback();
				}

				document.querySelector("aside.winup article > div.winup > ul:nth-child(2) > li:last-child").removeAttribute("class");
			}, false);
		});
	}
};