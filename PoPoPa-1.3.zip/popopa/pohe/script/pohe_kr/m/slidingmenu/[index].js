$$js_import$$("pohe_kr.m.slidingmenu.Resolver");
$$js_import$$("pohe_kr.m.slidingmenu.Service");