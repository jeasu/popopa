$content$.helpsection.ko.install.register = {
	service: function() {
		menuClassDiv.innerHTML = document.querySelector("body > nav > div > div ul > li > label > input:checked + span").innerHTML;
		$jnode$.pushHistory(this.conf);
	}
};