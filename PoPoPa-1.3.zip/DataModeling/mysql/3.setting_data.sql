/**********************************/
/* 초기 설정 값                   */
/**********************************/                          /*  user_id, setting_key         , setting_value */
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'lang'              , 'auto'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'use_init_admin'    , 'true'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'update_account'    , 'false' );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'use_org'           , 'false' );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'use_project_period', 'true'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'exclude_admin'     , 'false' );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'auth_level'        , 'high'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'anchor_week'       , 'auto'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'anchor_month'      , 'auto'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'report_user'       , 'member');
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'display_user'      , 'false' );