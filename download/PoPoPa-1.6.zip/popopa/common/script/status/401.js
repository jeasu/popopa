function callLogin() {
	$controller$.loading.show();

	$jnode$.ajax.service({
		"url":      "/ajax/auth.json",
		"method":   "POST",
		"datatype": "json",
		"headers": {
			"Content-Type": "application/json",
			"Accept":       "application/json"
		},
		"params": {
			"command":  "login",
			"user_id":  document.loginForm.user_id.value,
			"password": document.loginForm.password.value,
			"stateful": (document.loginForm.stateful.checked ? "Y" : "N")
		},
		"success": function(response) {
			document.location.reload();
		},
		"error": function(error) {
			$jnode$.ajax.alertError(error, [
				{"code":"401", "message":"-", "callback":function() {
					document.querySelector("article > div.article > form > div").innerHTML = error.error_message;

					if (error.debug_message == "Wrong password")  document.loginForm.password.select();
					else                                          document.loginForm.user_id.select();

					window.scrollTo(0, document.body.scrollHeight);
				}}
			]);

			$controller$.loading.hide();
		}
	});
}

document.loginForm.user_id.addEventListener("keydown", function(event) {
	var keyCode = event.keyCode || event.which;

	if(keyCode == 13) {
		event.preventDefault();
		document.loginForm.password.focus();
	}
}, false);

document.loginForm.password.addEventListener("keydown", function(event) {
	var keyCode = event.keyCode || event.which;

	if(keyCode == 13) {
		event.preventDefault();
		callLogin();
	}
}, false);

document.querySelector("article > div.article > form > table > tbody > tr > td:nth-child(3) > button").addEventListener("click", function(event) {
	callLogin();
}, false);

document.loginForm.user_id.focus();