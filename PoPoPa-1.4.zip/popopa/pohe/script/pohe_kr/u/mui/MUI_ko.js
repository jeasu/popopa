/*
 * @(#)pohe_kr.u.mui.MUI.js  1.0, 2012-09-03
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-09-03
 */
$$js_namespace$$("pohe_kr.u.mui");

/**
 * The Korean(ko) Internationalization Object of POHE.
 */
pohe_kr.u.mui.MUI = {
	button : {
		cancel : {
			title : "취소",
			styleclass : "red"
		},

		close : {
			title : "닫기",
			styleclass : "blue"
		},

		complete : {
			title : "완료",
			styleclass : "blue"
		},

		more : {
			title : "기타...",
			styleclass : "blue"
		},

		ok : {
			title : "확인",
			styleclass : "blue"
		}
	},

	popup : {
		calendar : "달력",
		color : "색"
	}
};