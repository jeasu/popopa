/**********************************/
/* 초기 설정된 관리자             */
/**********************************/                                                                                  /* user_id   , user_name        , user_password, user_level, user_changed                    , user_retired, position_id, org_id */
INSERT INTO usr (user_id, user_name, user_password, user_level, user_changed, user_retired, position_id, org_id) values ('${admin}', 'PoPoPa Customer', '${admin}'   , '0'       , DATE_FORMAT(NOW(),'%Y-%m-%dT%T'), null        , null       , null);