$content$.winup.gantt.edit = {
	service: function() {
		var that          = this;
		var taskId        = this.conf.task_id;
		var startdate     = this.conf.startdate;
		var enddate       = this.conf.enddate;
		var startdateSpan = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr:nth-child(2) > td > div > span:first-of-type");
		var enddateSpan   = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr:nth-child(2) > td > div > span:nth-of-type(2)");

		if (startdate) {
			var startDate = dateUtil.parse(startdate);
			var endDate   = dateUtil.parse(enddate);

			var startdateCalendar = document.querySelector("ul.calendar_period > li:first-child > div > ul > li > div > div.calendar");
			var enddateCalendar   = document.querySelector("ul.calendar_period > li:last-child > div > ul > li > div > div.calendar");
			var historyCalendarCallback = null;

			startdateSpan.innerHTML = dateFormatter.format(startDate, dateFormatter.DateStyle.LONG) + "<FONT>" + startdate + "</FONT>";
			enddateSpan.innerHTML   = dateFormatter.format(endDate, dateFormatter.DateStyle.LONG) + "<FONT>" + enddate + "</FONT>";

			function disableAdjustNextTasks(selEnddate) {
				if (enddate == selEnddate) {
					document.taskForm.adjust_next_tasks.disabled = true;
					document.taskForm.dayoff.disabled = true;
				} else {
					document.taskForm.adjust_next_tasks.disabled = false;
					document.taskForm.dayoff.disabled = false;
				}
			}

			disableAdjustNextTasks(enddate);

			displayCalendar(startDate, "date", startdateSpan, startdateCalendar, startdate, function(selecteddate) {
				var selStartdate = selecteddate;
				var selEnddate   = enddateSpan.firstElementChild.innerHTML;
				if (selStartdate > selEnddate)  selEnddate = selStartdate;

				disableAdjustNextTasks(selEnddate);
				startdateCalendar.nextElementSibling.click();
			});

			displayCalendar(endDate, "date", enddateSpan, enddateCalendar, enddate, function(selecteddate) {
				var selStartdate = startdateSpan.firstElementChild.innerHTML;
				var selEnddate   = selecteddate;
				if (selStartdate > selEnddate)  selEnddate = selStartdate;

				disableAdjustNextTasks(selEnddate);
				enddateCalendar.nextElementSibling.click();
			});

			startdateSpan.addEventListener("click", function(event) {
				if (window.innerWidth < 737) {
					enddateCalendar.nextElementSibling.click();
					startdateCalendar.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "popup");

					if (isPhone) {
						document.body.style.overflow = "hidden";

						historyCalendarCallback = $jnode$.node.pushPseudoHistory(function() {
							startdateCalendar.nextElementSibling.click();
						});
					}
				}
			}, false);

			enddateSpan.addEventListener("click", function(event) {
				if (window.innerWidth < 737) {
					startdateCalendar.nextElementSibling.click();
					enddateCalendar.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "popup");

					if (isPhone) {
						document.body.style.overflow = "hidden";

						historyCalendarCallback = $jnode$.node.pushPseudoHistory(function() {
							enddateCalendar.nextElementSibling.click();
						});
					}
				}
			}, false);

			startdateCalendar.nextElementSibling.addEventListener("click", function(event) {
				this.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
				if (isPhone)  document.body.style.removeProperty("overflow");
				if (historyCalendarCallback)  historyCalendarCallback();
			}, false);

			enddateCalendar.nextElementSibling.addEventListener("click", function(event) {
				this.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
				if (isPhone)  document.body.style.removeProperty("overflow");
				if (historyCalendarCallback)  historyCalendarCallback();
			}, false);

			document.taskForm.adjust_next_tasks.addEventListener("change", function(event) {
				if (this.checked)  this.parentNode.nextElementSibling.setAttribute("class", "checked");
				else               this.parentNode.nextElementSibling.removeAttribute("class");
			}, false);

			// Firefox는 2px의 여백과 1px의 border가 생김
			if (navigator.userAgent.indexOf("Firefox") > 0) {
				document.taskForm.progress.style.height = "29px";
			}

			document.taskForm.progress.addEventListener("input", function(event) {
				this.parentNode.nextElementSibling.innerHTML = this.value + "%";
			}, false);

			// IE는 input event가 안 먹기 때문에 change event를 추가로 구현
			document.taskForm.progress.addEventListener("change", function(event) {
				this.parentNode.nextElementSibling.innerHTML = this.value + "%";
			}, false);
		}

		document.taskForm.querySelector("form > ul > li:last-child > button:first-child").addEventListener("click", function(event) {
			var alertMessage = null;

			var params = {
				command:    "updateTask",
				project_id: that.conf.project_id,
				task_id:    taskId,
				task_name:  document.taskForm.task_name.value
			};

			if (startdate) {
				params.user_id           = document.taskForm.user_id.value;
				params.startdate         = startdateSpan.firstElementChild.innerHTML;
				params.enddate           = enddateSpan.firstElementChild.innerHTML;
				params.progress          = document.taskForm.progress.value;
				params.adjust_next_tasks = (document.taskForm.adjust_next_tasks.checked ? "true" : "false");
			} else {
				params.user_id   = "";
				params.startdate = "";
				params.enddate   = "";
				params.progress  = 0;
			}

			if (params.task_name == "") {
				alertMessage = i18n.alert_input_task_name;
				document.taskForm.task_name.focus();
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				if (params.startdate && params.startdate > params.enddate) {
					var tempEnddate  = params.startdate;
					params.startdate = params.enddate;
					params.enddate   = tempEnddate;
				}

				if (params.adjust_next_tasks == "true") {
					if (enddate == params.enddate) {
						params.adjust_next_tasks = "false";
					} else {
						var dayoff     = document.taskForm.dayoff.value;
						var oldEndDate = dateUtil.parse(enddate);
						var newEndDate = dateUtil.parse(params.enddate);
						var diffPeriod = ((newEndDate.getTime() - oldEndDate.getTime()) / 86400000); // 24 * 60 * 60 * 1000

						if (dayoff != "0") {
							if (Math.abs(diffPeriod) % 7 == 0) {
								dayoff = "0";
							} else {
								var oldWeek = oldEndDate.getDay();
								var newWeek = newEndDate.getDay();

								if (enddate > params.enddate) {
									if (oldWeek == 0) {
										diffPeriod += 2;
										oldWeek = 5;
									} else if (oldWeek == 6) {
										diffPeriod += 1;
										oldWeek = 5;
									}

									if (newWeek == 0) {
										diffPeriod += 1;
										newWeek = 1;
									} else if (newWeek == 6) {
										diffPeriod += 2;
										newWeek = 1;
									}

									if (newWeek > oldWeek) {
										diffPeriod += 2;
									}
								} else {
									if (oldWeek == 0) {
										diffPeriod -= 1;
										oldWeek = 5;
									} else if (oldWeek == 6) {
										diffPeriod -= 2;
										oldWeek = 5;
									}

									if (newWeek == 0) {
										diffPeriod -= 2;
										newWeek = 5;
									} else if (newWeek == 6) {
										diffPeriod -= 2;
										newWeek = 5;
									}

									if (newWeek < oldWeek) {
										diffPeriod -= 2;
									}
								}
							}
						}

						if (diffPeriod == 0) {
							params.adjust_next_tasks = "false";
						} else {
							params.diff_period = diffPeriod;
							params.old_enddate = enddate;
							params.dayoff      = dayoff;
						}
					}
				}

				$jnode$.ajax.service({
					"url":      "/ajax/gantt.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var itemUl = document.querySelector("body > section > div > ul > li:first-child > ul > li:last-child > div > div > label > input:checked + div > ul");
						var itemLi = itemUl.firstElementChild;
						itemLi.setAttribute("title", params.task_name);
						itemLi.firstElementChild.lastElementChild.firstChild.nodeValue = params.task_name;

						if (itemUl.getAttribute("class") != "activity") {
							var progressDayList  = $content$.section.gantt.progressDayList;
							var progressDayIndex = progressDayList.length;
							var ganttStartdate   = progressDayList[0].date;
							var ganttEnddate     = progressDayList[progressDayIndex - 1].date;

							// 시작일이 간트챠트 기간보다 빠를 때
							if (response.min_startdate < ganttStartdate) {
								var ganttStartDate = dateUtil.parse(ganttStartdate);
								var taskStartDate  = dateUtil.parse(response.min_startdate);

								var appendBeforePeriod = ((ganttStartDate.getTime() - taskStartDate.getTime()) / 86400000); // 24 * 60 * 60 * 1000
								appendBeforePeriod += (7 - appendBeforePeriod % 7);

								$content$.section.gantt.drawPeriodHeader(dateUtil.format(dateUtil.toDate(ganttStartDate, -1 * appendBeforePeriod)), dateUtil.format(dateUtil.toDate(ganttStartDate, -1)), that.conf.currentdate, true);
								$content$.section.gantt.addProgressArea(appendBeforePeriod, true);
							}

							// 종료일이 간트챠트 기간보다 늦을 때
							if (response.max_enddate > ganttEnddate) {
								var ganttEndDate = dateUtil.parse(ganttEnddate);
								var taskEndDate  = dateUtil.parse(response.max_enddate);

								var appendAfterPeriod = ((taskEndDate.getTime() - ganttEndDate.getTime()) / 86400000); // 24 * 60 * 60 * 1000
								appendAfterPeriod += (7 - appendAfterPeriod % 7);

								$content$.section.gantt.drawPeriodHeader(dateUtil.format(dateUtil.toDate(ganttEndDate, 1)), dateUtil.format(dateUtil.toDate(ganttEndDate, appendAfterPeriod)), that.conf.currentdate);
								$content$.section.gantt.addProgressArea(progressDayIndex);
							}

							$content$.section.gantt.updateTaskValues(params.task_id, params);

							function updateTaskPeriod(taskInfo) {
								var itemUl = document.querySelector("body > section > div > ul > li:first-child > ul > li:last-child > div > div > label > input[value='" + taskInfo.task_id + "'] + div > ul");

								var progressStatus   = getProgressStatus(taskInfo.progress, taskInfo.startdate, taskInfo.enddate);
								var outboundProgress = isOutboundProgress($content$.section.gantt.dataset.projectInfo.startdate, $content$.section.gantt.dataset.projectInfo.enddate, taskInfo.startdate, taskInfo.enddate);

								itemUl.setAttribute("class", progressStatus);
								if (outboundProgress)  $jnode$.node.addClass(itemUl, "outbound");

								var periodLi     = itemUl.lastElementChild.firstElementChild.firstElementChild.nextElementSibling;
								var startdateDiv = periodLi.firstElementChild;
								var enddateDiv   = periodLi.lastElementChild;

								startdateDiv.setAttribute("id", taskInfo.startdate);
								enddateDiv.setAttribute("id", taskInfo.enddate);

								if (taskInfo.startdate == taskInfo.enddate) {
									startdateDiv.innerHTML = dateFormatter.format(dateUtil.parse(taskInfo.startdate), dateFormatter.DateStyle.MEDIUM);
								} else {
									startdateDiv.innerHTML = dateFormatter.format(dateUtil.parse(taskInfo.startdate), dateFormatter.DateStyle.MEDIUM) + " ~";
								}

								enddateDiv.innerHTML = dateFormatter.format(dateUtil.parse(taskInfo.enddate), dateFormatter.DateStyle.MEDIUM);

								var progressBar = document.querySelector("body > section > div > ul > li:last-child > ul > li:last-child > div > label > input[value='" + taskInfo.task_id + "'] + div > div");
								if (progressStatus.search(/^delayed/) == 0) {
									progressBar.setAttribute("class", "delayed");
								} else {
									if (outboundProgress)  progressBar.setAttribute("class", "outbound");
									else                   progressBar.removeAttribute("class");
								}

								var startIntervals    = (dateUtil.parse(taskInfo.startdate).getTime() - $content$.section.gantt.progressStartDate.getTime()) / 86400000;
								var progressIntervals = (dateUtil.parse(taskInfo.enddate).getTime() - dateUtil.parse(taskInfo.startdate).getTime()) / 86400000 + 1;

								progressBar.style.left  = (startIntervals * 20 - 1) + "px";
								progressBar.style.width = (progressIntervals * 20 - 1) + "px";
							}

							var nextTaskList = response.nextTaskList;

							for (var i = 0; i < nextTaskList.length; i++) {
								updateTaskPeriod(nextTaskList[i]);
							}
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.taskForm.querySelector("form > ul > li:last-child > button:last-child").addEventListener("click", function(event) {
			$controller$.prompt.confirm((startdate ? i18n.confirm_delete_task : i18n.confirm_delete_activity), function(close) {
				$controller$.loading.show();

				var taskParentId      = document.querySelector("body > section > div > ul > li:first-child > ul > li:last-child > div > div > label > input:checked").parentNode.getAttribute("class");
				var deletedTaskIdList = [taskId].concat($content$.section.gantt.getChildTaskList(taskId));
				var taskSiblingCount  = document.querySelectorAll("body > section > div > ul > li:first-child > ul > li:last-child > div > div > label[class='" + taskParentId + "']").length;

				var params = {
					command:       "deleteTask",
					project_id:    that.conf.project_id,
					task_id:       taskId,
					task_ids:      deletedTaskIdList.join(","),
					task_parent:   taskParentId,
					sibling_count: taskSiblingCount
				};

				if (taskSiblingCount == 1) {
					params = $content$.section.gantt.setActivity2TaskValues(params, deletedTaskIdList);
				}

				$jnode$.ajax.service({
					"url":      "/ajax/gantt.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var addButton1  = document.querySelector("body > section > div > ul > li:first-child > ul > li:first-child > ul > li:last-child > ul > li:first-child");
						var editButton1 = addButton1.nextElementSibling;
						var addButton2  = document.querySelector("body > section > div.section > footer > ul > li > ul > li:nth-child(2) > button:nth-child(2)");
						var editButton2 = addButton2.nextElementSibling;

						editButton1.setAttribute("class", "disabled");
						editButton2.disabled = true;

						if (response.deleteAllTasks) {
							$content$.section.gantt.appendEmptyTask();
						} else {
							addButton1.setAttribute("class", "disabled");
							addButton2.disabled = true;

							var itemTaskContainer     = document.querySelector("body > section > div > ul > li:first-child > ul > li:last-child > div > div");
							var progressTaskContainer = document.querySelector("body > section > div > ul > li:last-child > ul > li:last-child > div");

							for (var i = 0; i < deletedTaskIdList.length; i++) {
								itemTaskContainer.removeChild(itemTaskContainer.querySelector("div > label > input[value='" + deletedTaskIdList[i] + "']").parentNode);
								progressTaskContainer.removeChild(progressTaskContainer.querySelector("div > label > input[value='" + deletedTaskIdList[i] + "']").parentNode);
							}

							if (response.changeActivity2Task) {
								$content$.section.gantt.updateTaskValues(taskParentId, params);
							} else if (itemTaskContainer.firstElementChild == null) {
								$content$.section.gantt.appendEmptyTask();
							}
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				close();
			});
		}, false);
	}
};