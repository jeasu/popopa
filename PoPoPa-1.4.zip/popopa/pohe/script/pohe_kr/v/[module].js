$$module_import$$("pohe_kr.v.button"  , pohe_kr.u.Script.resolve);
$$module_import$$("pohe_kr.v.list"    , pohe_kr.u.Script.resolve);
$$module_import$$("pohe_kr.v.switcher", pohe_kr.u.Script.resolve);

$$module_import$$("pohe_kr.v.direct.media", pohe_kr.u.Script.resolve);
$$module_import$$("pohe_kr.v.direct.table", pohe_kr.u.Script.resolve);