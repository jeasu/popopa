$$js_import$$("pohe_kr.w.texteditor.syntax.CSS");
$$js_import$$("pohe_kr.w.texteditor.syntax.HTML");
$$js_import$$("pohe_kr.w.texteditor.syntax.JAVA");
$$js_import$$("pohe_kr.w.texteditor.syntax.JS");
$$js_import$$("pohe_kr.w.texteditor.syntax.JSP");
$$js_import$$("pohe_kr.w.texteditor.syntax.SQL");
$$js_import$$("pohe_kr.w.texteditor.syntax.XML");