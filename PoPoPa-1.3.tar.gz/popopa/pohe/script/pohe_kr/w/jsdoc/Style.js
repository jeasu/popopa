/*
 * @(#)pohe_kr.w.jsdoc.Style.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.jsdoc");

/**
 * JS(JavaScript) 파일을 DOC로 표현해주는 HTMLElement의 Style 객체.
 */
pohe_kr.w.jsdoc.Style = {

	/**
	 * grobal style
	 */
	"$" : {
		width:null,
		height:null,
		expand:"all",
		border:"1",
		bordercolor:"#ABADB3",
		bgcolor:"#FFFFFF",
		padding:"10px"
	}
};