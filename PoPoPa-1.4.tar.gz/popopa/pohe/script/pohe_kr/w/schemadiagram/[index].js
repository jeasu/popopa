$$js_import$$("pohe_kr.w.schemadiagram.Resolver");
$$js_import$$("pohe_kr.w.schemadiagram.Service");
$$js_import$$("pohe_kr.w.schemadiagram.Style");