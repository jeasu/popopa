/*
 * @(#)pohe_kr.w.texteditor.syntax.HTML.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.texteditor.syntax");

/**
 * TEXT 문자열에 HTML 타입으로 color syntax를 보여주는 객체.
 * <BR/><BR/>
 * 
 * this 객체는 내부적으로 아래의 객체들을 사용해서 구현했다. 따라서, 이들 객체들도 같이 import를 해야 제대로 color syntax가 적용된 화면을 볼 수 있다.
 * 
 * <UL>
 *   <LI><CODE>pohe_kr.w.texteditor.syntax.CSS</CODE></LI>
 *   <LI><CODE>pohe_kr.w.texteditor.syntax.JS</CODE></LI>
 *   <LI><CODE>pohe_kr.w.texteditor.syntax.XML</CODE></LI>
 * </Ul>
 */
pohe_kr.w.texteditor.syntax.HTML = {

	/**
	 * TEXT 문자열을 HTML 타입으로 color syntax를 준다.
	 *
	 * @param  {String} text  {@nullable false} HTML 타입으로 color syntax를 줄 TEXT 문자열
	 * @return {String} HTML 타입으로 color syntax를 준 HTML 코드
	 */
	getColorSyntax: function(text) {
		if(pohe_kr.w.texteditor.syntax.XML==null){alert('Please import "pohe_kr.w.texteditor.syntax.XML".');return pohe_kr.w.texteditor.syntax.$$default$$.getColorSyntax(text)}var objScriptReg={};if(pohe_kr.w.texteditor.syntax.JS==null)alert('Please import "pohe_kr.w.texteditor.syntax.JS".');else{var matched=text.match(new RegExp("<script[\\s|>]?[\\s\\S]*?<\/script>","gmi"));if(matched)for(var i=0;i<matched.length;i++){var scriptIndex=matched[i].indexOf(">");
if(scriptIndex>0&&scriptIndex<matched[i].length-10){objScriptReg["[[-- js script syntax "+i+" --]]"]=matched[i].substring(scriptIndex+1,matched[i].length-9);text=text.replace(matched[i],matched[i].substring(0,scriptIndex+1)+"[[-- js script syntax "+i+" --]]"+matched[i].substring(matched[i].length-9))}}}var objCssReg={};if(pohe_kr.w.texteditor.syntax.CSS==null)alert('Please import "pohe_kr.w.texteditor.syntax.CSS".');else{var matched=text.match(new RegExp("<style[\\s|>]?[\\s\\S]*?</style>","gmi"));
if(matched)for(var i=0;i<matched.length;i++){var cssIndex=matched[i].indexOf(">");if(cssIndex>0&&cssIndex<matched[i].length-9){objCssReg["[[-- css syntax "+i+" --]]"]=matched[i].substring(cssIndex+1,matched[i].length-8);text=text.replace(matched[i],matched[i].substring(0,cssIndex+1)+"[[-- css syntax "+i+" --]]"+matched[i].substring(matched[i].length-8))}}}text=pohe_kr.w.texteditor.syntax.XML.getColorSyntax(text);for(var key in objCssReg)text=text.replace(key,pohe_kr.w.texteditor.syntax.CSS.getColorSyntax(objCssReg[key]).replace(/\$/g,
"$$$$"));for(var key in objScriptReg)text=text.replace(key,pohe_kr.w.texteditor.syntax.JS.getColorSyntax(objScriptReg[key]).replace(/\$/g,"$$$$"));return text
	}
};

/**
 * TEXT 문자열에 color syntax를 보여 줄때 HTML 타입과 동일한 syntax를 줄 HTM 타입의 객체
 */
pohe_kr.w.texteditor.syntax.HTM = pohe_kr.w.texteditor.syntax.HTML;