/*
 * @(#)pohe_kr.w.texteditor.Style.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.texteditor");

/**
 * TEXT 문자열에 color syntax 표현이 가능한 TEXTEDITOR의 Style 객체.
 */
pohe_kr.w.texteditor.Style = {

	/**
	 * grobal style
	 */
	"$" : {
		tabindent:"4",
		width:"100%",
		height:null,
		border:"1",
		bordercolor:"#ABADB3",
		bgcolor:"#FFFFFF",
		currentlinecolor:"#E8F2FE",
		fontsize:"13px",
		fontcolor:"#000000",
		linenumbercolor:"#808080",
		linenumberbgcolor:"#F0F0F0",
		linenumberbordercolor:"#E3E3E3",
		scroll:"true"
	}
};