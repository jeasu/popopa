$$js_import$$("pohe_kr.v.slidingmenu.Mapping");
$$js_import$$("pohe_kr.v.slidingmenu.Resolver");