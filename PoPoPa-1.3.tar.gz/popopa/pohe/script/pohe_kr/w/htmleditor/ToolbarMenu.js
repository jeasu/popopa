/*
 * @(#)pohe_kr.w.htmleditor.ToolbarMenu.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.htmleditor");

/**
 * HTMLEDITOR의 Toolbar Menu 객체.
 * <BR/><BR/>
 * 
 * HTMLEDITOR에 사용될 Toolbar Menu의 순서와 <CODE>fontName</CODE>, <CODE>symbol</CODE>에 사용할 항목에 대해서만 설정이 가능하다.
 * <BR/><BR/>
 * 
 * Toolbar Menu의 설정은 toolbar key에 설정하며, 사용하고자 하는 Toolbar 개수만큼 배열을 만들고,
 * 그 배열에 다시 Menu ID를 배열로 구성하면 된다. 이때 <CODE>null</CODE>로 설정하면 구분선이 삽입된다.
 * HTMLEDITOR에 사용할 수 있는 Toolbar Menu는 아래와 같다.
 * <BR/><BR/>
 * 
 * <TABLE border="0" cellspacing="1" cellpadding="3" bgcolor="#8A9096" style="border-collapse:separate;">
 *   <TR bgcolor="#E5E5E5" align="center">
 *     <TD>Menu ID</TD>
 *     <TD>Menu 이름</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>fontName</CODE></TD>
 *     <TD>글자체</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>fontSize</CODE></TD>
 *     <TD>글자크기</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>foreColor</CODE></TD>
 *     <TD>글자색</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>hiliteColor</CODE></TD>
 *     <TD>강조</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>bold</CODE></TD>
 *     <TD>굵게</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>italic</CODE></TD>
 *     <TD>기울림꼴</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>underline</CODE></TD>
 *     <TD>밑줄</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>strikeThrough</CODE></TD>
 *     <TD>취소선</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>superscript</CODE></TD>
 *     <TD>윗첨자</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>subscript</CODE></TD>
 *     <TD>아래첨자</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>justifyLeft</CODE></TD>
 *     <TD>왼쪽 정렬</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>justifyCenter</CODE></TD>
 *     <TD>가운데 정렬</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>justifyRight</CODE></TD>
 *     <TD>오른쪽 정렬</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>insertOrderedList</CODE></TD>
 *     <TD>번호 서식</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>insertUnorderedList</CODE></TD>
 *     <TD>글머리 기호 서식</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>outdent</CODE></TD>
 *     <TD>내어쓰기</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>indent</CODE></TD>
 *     <TD>들여쓰기</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>cut</CODE></TD>
 *     <TD>잘라내기</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>copy</CODE></TD>
 *     <TD>복사하기</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>paste</CODE></TD>
 *     <TD>붙여넣기</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>pasteSpecial</CODE></TD>
 *     <TD>선택하여 붙여넣기</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>removeFormat</CODE></TD>
 *     <TD>서식 제거</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>undo</CODE></TD>
 *     <TD>실행 취소</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>redo</CODE></TD>
 *     <TD>다시 실행</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>refresh</CODE></TD>
 *     <TD>새로 고침</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>createLink</CODE></TD>
 *     <TD>하이퍼링크</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>table</CODE></TD>
 *     <TD>표</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>picture</CODE></TD>
 *     <TD>이미지</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>picturePro</CODE></TD>
 *     <TD>이미지</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>hr</CODE></TD>
 *     <TD>가로줄</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>dateTime</CODE></TD>
 *     <TD>날짜/시간</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>symbol</CODE></TD>
 *     <TD>기호</TD>
 *   </TR>
 *   <TR bgcolor="#FFFFFF">
 *     <TD><CODE>number</CODE></TD>
 *     <TD>번호</TD>
 *   </TR>
 * </TABLE>
 * <BR/><BR/>
 * 
 * <CODE>picture</CODE>는 URL 경로의 파일만 삽일을 할 수 있다. 로컬 사용자의 파일을 업로드하여 삽입을 하기 위해서는 <CODE>picturePro</CODE>를 사용하면 된다.
 * <CODE>picturePro</CODE>는 내부적으로 <CODE>/servlet/kr.pohe.tl.w.htmleditor.HtmleditorServlet</CODE>이라는 Java Servlet을 사용한다.
 * <CODE>/servlet/kr.pohe.tl.w.htmleditor.HtmleditorServlet</CODE>의 자세한 사용법은 아래를 참조한다.
 * 
 * <BLOCKQUOTE>
 *     <A href="http://pohe.kr/api/?url=/servlet/kr.pohe.tl.w.htmleditor.HtmleditorServlet" target="_blank"><CODE>/servlet/kr.pohe.tl.w.htmleditor.HtmleditorServlet</CODE> 사용법</A>
 * </BLOCKQUOTE>
 * 
 * <CODE>fontName</CODE>은 언어별로 따로 설정하며, 설정된 언어 순서로 폰트 이름이 보여진다.
 * 단, 사용자의 요청 언어의 언어에 설정된 폰트들이 가장 먼저 보여진다.
 * <BR/><BR/>
 * 
 * <CODE>symbol</CODE>은 가로, 세로 정사각형 형태로 보여진다.
 * 예를 들어, symbol이 144개라면 가로 12개에 세로 12개가 보여진다.
 * 정사각형 형태로 보여질 수 있는 개수보다 적으면 나머지는 빈칸으로 채워 보여진다.
 */
pohe_kr.w.htmleditor.ToolbarMenu = {

	/**
	 * grobal toolbar menu
	 */
	"$" : {
		"toolbar": [
			[
				"fontName",
				"fontSize",
				null,
				"foreColor",
				"hiliteColor",
				null,
				"bold",
				"italic",
				"underline",
				null,
				"strikeThrough",
				"superscript",
				"subscript",
				null,
				"justifyLeft",
				"justifyCenter",
				"justifyRight",
				null,
				"insertOrderedList",
				"insertUnorderedList",
				null,
				"outdent",
				"indent"
			],
			[
				"cut",
				"copy",
				"paste",
				"pasteSpecial",
				null,
				"removeFormat",
				"undo",
				"redo",
				"refresh",
				null,
				"createLink",
				"table",
				"picture",  // "picturePro",
				"hr",
				null,
				"dateTime",
				"symbol",
				"number"
			],
		],
		"fontName": {
			"en": [
				"Segoe UI",
				"Arial",
				"Arial Black",
				"Arial Narrow",
				"Arial Unicode MS",
				"Comic Sans MS",
				"Consolas",
				"Courier New",
				"System",
				"Times New Roman",
				"Verdana"
			],
			"zh": [
				"Microsoft JhengHei",
				"Microsoft YaHei",
				"宋体",
				"新宋体",
				"黑体"
			],
			"ja": [
				"メイリオ",
				"ＭＳ ゴシック",
				"ＭＳ Ｐゴシック",
				"ＭＳ 明朝",
				"ＭＳ Ｐ明朝"
			],
			"ko": [
				"맑은 고딕",
				"굴림",
				"궁서",
				"돋움",
				"바탕"
			]
		},
		"symbol":[
			"《", "》", "「", "」", "『", "』", "【", "】", "·", "‥", "…", "§",
			"※", "☆", "★", "○", "●", "◎", "◇", "◆", "□", "■", "△", "▲",
			"▽", "▼", "◁", "◀", "▷", "▶", "♤", "♠", "♡", "♥", "♧", "♣",
			"⊙", "◈", "▣", "◐", "◑", "▤", "▥", "▨", "▧", "▦", "▩", "‰",
			"±", "×", "÷", "≠", "≤", "≥", "∞", "∴", "°", "′", "″", "∠",
			"⊥", "⌒", "∂", "≡", "≒", "≪", "≫", "√", "∽", "∝", "∵", "∫",
			"∬", "∈", "∋", "⊆", "⊇", "⊂", "⊃", "∪", "∩", "∧", "∨", "￢",
			"⇒", "⇔", "∀", "∃", "¡", "¿", "ː", "∮", "∑", "∏", "♭", "♩",
			"♪", "♬", "→", "←", "↑", "↓", "↔", "↕", "↗", "↙", "↖", "↘",
			"№", "㏇", "™", "※", "♨", "☏", "☎", "☜", "☞", "¶", "†", "‡",
			"®", "ª", "º", "½", "⅓", "⅔", "¼", "¾", "⅛", "⅜", "⅝", "⅞",
			"♂", "♀", "￦", "＄", "￥", "￡", "€", "℃", "Å", "℉", "￠", "¤"
		]
	}
};