$content$.winup.gantt.add = {
	service: function() {
		var that         = this;
		var confPosition = this.conf.position;
		var confIndent   = this.conf.indent;
		var startdate    = this.conf.startdate;
		var enddate      = this.conf.enddate;
		var startDate    = dateUtil.parse(startdate);
		var endDate      = dateUtil.parse(enddate);

		var startdateSpan     = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr:nth-child(2) > td > div > span:first-of-type");
		var enddateSpan       = document.querySelector("aside.winup article > div.winup > form > table.form > tbody > tr:nth-child(2) > td > div > span:nth-of-type(2)");
		var startdateCalendar = document.querySelector("ul.calendar_period > li:first-child > div > ul > li > div > div.calendar");
		var enddateCalendar   = document.querySelector("ul.calendar_period > li:last-child > div > ul > li > div > div.calendar");
		var historyCalendarCallback = null;

		startdateSpan.innerHTML = dateFormatter.format(startDate, dateFormatter.DateStyle.LONG) + "<FONT>" + startdate + "</FONT>";
		enddateSpan.innerHTML   = dateFormatter.format(endDate, dateFormatter.DateStyle.LONG) + "<FONT>" + enddate + "</FONT>";

		displayCalendar(startDate, "date", startdateSpan, startdateCalendar, startdate, function() {
			startdateCalendar.nextElementSibling.click();
		});

		displayCalendar(endDate, "date", enddateSpan, enddateCalendar, enddate, function() {
			enddateCalendar.nextElementSibling.click();
		});

		startdateSpan.addEventListener("click", function(event) {
			if (window.innerWidth < 737) {
				enddateCalendar.nextElementSibling.click();
				startdateCalendar.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "popup");

				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyCalendarCallback = $jnode$.node.pushPseudoHistory(function() {
						startdateCalendar.nextElementSibling.click();
					});
				}
			}
		}, false);

		enddateSpan.addEventListener("click", function(event) {
			if (window.innerWidth < 737) {
				startdateCalendar.nextElementSibling.click();
				enddateCalendar.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "popup");

				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyCalendarCallback = $jnode$.node.pushPseudoHistory(function() {
						enddateCalendar.nextElementSibling.click();
					});
				}
			}
		}, false);

		startdateCalendar.nextElementSibling.addEventListener("click", function(event) {
			this.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
			if (isPhone)  document.body.style.removeProperty("overflow");
			if (historyCalendarCallback)  historyCalendarCallback();
		}, false);

		enddateCalendar.nextElementSibling.addEventListener("click", function(event) {
			this.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
			if (isPhone)  document.body.style.removeProperty("overflow");
			if (historyCalendarCallback)  historyCalendarCallback();
		}, false);

		document.taskForm.querySelector("form > ul > li:last-child > button").addEventListener("click", function(event) {
			var alertMessage = null;
			var userId = document.taskForm.user_id.value;

			var params = {
				command:      "addTask",
				project_id:   that.conf.project_id,
				task_name:    document.taskForm.task_name.value,
				user_id:      userId,
				user_name:    $content$.section.gantt.userMap[userId].user_name,
				startdate:    startdateSpan.firstElementChild.innerHTML,
				enddate:      enddateSpan.firstElementChild.innerHTML,
				progress:     0,
				task_parent:  that.conf.task_parent,
				task_sibling: that.conf.task_sibling,
				indent:       confIndent,
				position:     document.taskForm.position.value
			};

			if (params.position == "child") {
				params.task_parent = params.task_sibling;
				params.indent      = confIndent + 1;
			}

			if (params.task_name == "") {
				alertMessage = i18n.alert_input_task_name;
				document.taskForm.task_name.focus();
			}

			if (alertMessage) {
				this.parentNode.previousElementSibling.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				if (params.startdate > params.enddate) {
					var tempEnddate  = params.startdate;
					params.startdate = params.enddate;
					params.enddate   = tempEnddate;
				}

				params.changeTask2Activity = (confPosition == "next" && params.position == "child");

				$jnode$.ajax.service({
					"url":      "/ajax/gantt.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						params.task_id = response.task_id;

						var progressDayList  = $content$.section.gantt.progressDayList;
						var progressDayIndex = progressDayList.length;
						var ganttStartdate   = progressDayList[0].date;
						var ganttEnddate     = progressDayList[progressDayIndex - 1].date;

						// 시작일이 간트챠트 기간보다 빠를 때
						if (params.startdate < ganttStartdate) {
							var ganttStartDate = dateUtil.parse(ganttStartdate);
							var taskStartDate  = dateUtil.parse(params.startdate);

							var appendBeforePeriod = ((ganttStartDate.getTime() - taskStartDate.getTime()) / 86400000); // 24 * 60 * 60 * 1000
							appendBeforePeriod += (7 - appendBeforePeriod % 7);

							$content$.section.gantt.drawPeriodHeader(dateUtil.format(dateUtil.toDate(ganttStartDate, -1 * appendBeforePeriod)), dateUtil.format(dateUtil.toDate(ganttStartDate, -1)), that.conf.currentdate, true);
							$content$.section.gantt.addProgressArea(appendBeforePeriod, true);
						}

						// 종료일이 간트챠트 기간보다 늦을 때
						if (params.enddate > ganttEnddate) {
							var ganttEndDate = dateUtil.parse(ganttEnddate);
							var taskEndDate  = dateUtil.parse(params.enddate);

							var appendAfterPeriod = ((taskEndDate.getTime() - ganttEndDate.getTime()) / 86400000); // 24 * 60 * 60 * 1000
							appendAfterPeriod += (7 - appendAfterPeriod % 7);

							$content$.section.gantt.drawPeriodHeader(dateUtil.format(dateUtil.toDate(ganttEndDate, 1)), dateUtil.format(dateUtil.toDate(ganttEndDate, appendAfterPeriod)), that.conf.currentdate);
							$content$.section.gantt.addProgressArea(progressDayIndex);
						}

						if (params.changeTask2Activity) {
							$content$.section.gantt.changeTask2Activity(params.task_parent);
						}

						// Empty Task 존재 여부 체크
						var emptyTask = document.querySelector("body > section > div > ul > li:last-child > ul > li:last-child > div > div.empty");
						if (emptyTask) {
							var progressTaskContainer = emptyTask.parentNode;
							progressTaskContainer.removeChild(emptyTask);
							$content$.section.gantt.appendTask(params);

							document.querySelector("body > section > div > ul > li:first-child > ul > li:first-child > ul > li:last-child > ul > li:last-child").removeAttribute("class");
							document.querySelector("body > section > div.section > footer > ul > li > ul > li:nth-child(2) > button:last-child").disabled = false;

							document.querySelector("body > section > div > ul > li:first-child > ul > li:last-child > div > div > label > input").checked = true;
							progressTaskContainer.firstElementChild.firstElementChild.checked = true;
						} else {
							var index = $content$.section.gantt.getTaskIndex(params.task_sibling, params.position);
							$content$.section.gantt.appendTask(params, index);
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.taskForm.task_name.focus();
	}
};