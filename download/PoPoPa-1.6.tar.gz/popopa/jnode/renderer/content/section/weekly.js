$content$.section.weekly = {
	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var articleNode = document.querySelector("section > div.section > article");

		if (windowWidth > 736) {
			articleNode.style.height = (windowHeight - 101) + "px";  // 73 + 18
		} else {
			articleNode.removeAttribute("style");
		}
	},

	service: function() {
		var nodeConf = this.conf;
		this.resize();
		window.addEventListener("resize", this.resize, false);

		var dataset        = this.dataset;
		var memberName     = dataset.member_name;
		var selectedUserId = null;

		i18n = dataset.i18n;

		if (memberName == null)  memberName = i18n.label_not_selected;

		$jnode$.pushHistory(nodeConf);

		var weekCalendar   = document.querySelector("section > div.section > footer > ul > li > ul > li:last-child > div > ul > li > div > div > ul > li:first-child > div.calendar");
		var weekPeriod     = document.querySelector("section > div.section > footer > ul > li > ul > li:last-child > div > ul > li > div > div > ul > li:nth-child(2)");
		var weekSelect     = document.querySelector("section > div.section > footer > ul > li > ul > li:last-child > button");
		var blindDiv       = document.querySelector("section > div.section > div");
		var periodDoms     = new Array(3);
		var rStartdate     = dateUtil.parse(dataset.report_startdate);
		var rEnddate       = dateUtil.parse(dataset.report_enddate);
		var rStartdateText = dateFormatter.format(rStartdate, dateFormatter.DateStyle.MEDIUM);
		var rEnddateText   = dateFormatter.format(rEnddate, dateFormatter.DateStyle.MEDIUM);
		var sStartdate     = dateUtil.parse(dataset.scheduled_startdate);
		var sEnddate       = dateUtil.parse(dataset.scheduled_enddate);
		var sStartdateText = dateFormatter.format(sStartdate, dateFormatter.DateStyle.MEDIUM);
		var sEnddateText   = dateFormatter.format(sEnddate, dateFormatter.DateStyle.MEDIUM);
		var historyUserCallback = null;
		var historyWeekCallback = null;

		setSectionTitle(nodeConf.nodeId, dataset.report_period + " " + i18n.label_weekly + " <SPAN>(" + memberName + ")</SPAN>");
		weekSelect.innerHTML = dataset.report_period + " (" + rStartdateText + " ~ " + rEnddateText + ")";

		document.querySelector("section > div.section > article > ul > li:first-child > header:first-of-type > font").innerHTML = "(" + rStartdateText + " ~ " + rEnddateText + ")";
		document.querySelector("section > div.section > article > ul > li:first-child > header:nth-of-type(2) > font").innerHTML = "(" + sStartdateText + " ~ " + sEnddateText + ")";

		displayMonthCalendar(rStartdate, document.querySelector("section > div.section > article > ul > li:first-child > ul:first-of-type > li:last-child > div"), true);
		displayMonthCalendar(sEnddate,   document.querySelector("section > div.section > article > ul > li:first-child > ul:last-of-type > li:last-child > div"), true);

		periodDoms[0] = weekPeriod.querySelector("li > span:first-of-type" );
		periodDoms[1] = weekPeriod.querySelector("li > span:nth-of-type(2)");
		periodDoms[2] = weekPeriod.querySelector("li > span:last-of-type"  );

		periodDoms[0].innerHTML = dataset.report_period;
		periodDoms[1].innerHTML = rStartdateText + "<FONT>" + dataset.report_startdate + "</FONT>";
		periodDoms[2].innerHTML = rEnddateText + "<FONT>" + dataset.report_enddate + "</FONT>";

		var issueList = this.dataset.issueList;
		var memoList  = this.dataset.memoList;

		for (var i = 0; i < issueList.length; i++) {
			var noteId = issueList[i].note_id;

			var issues = document.querySelectorAll("section > div.section > article > ul > li:first-child > header + ul > li:first-child > div > div > span.issue[id='" + noteId + "']");
			for (var j = 0; j < issues.length; j++) {
				issues[j].innerHTML = (i + 1).toString();
			}
		}

		for (var i = 0; i < memoList.length; i++) {
			var noteId = memoList[i].note_id;

			var memos = document.querySelectorAll("section > div.section > article > ul > li:first-child > header + ul > li:first-child > div > div > span.memo[id='" + noteId + "']");
			for (var j = 0; j < memos.length; j++) {
				memos[j].innerHTML = (i + 1).toString();
			}
		}

		function moveWeekly(userId) {
			var options = {
				useLoading:       true,
				user_id:          userId,
				report_user:      document.querySelector("section > div.section > footer > ul > li > ul > li:last-child > div > ul > li > div > div > ul > li:last-child > ul > li > select").value,
				report_startdate: document.querySelector("section > div.section > footer > ul > li > ul > li:last-child > div > ul > li > div > div > ul > li:nth-child(2) > span:nth-of-type(2) > font").innerHTML,
				report_enddate:   document.querySelector("section > div.section > footer > ul > li > ul > li:last-child > div > ul > li > div > div > ul > li:nth-child(2) > span:nth-of-type(3) > font").innerHTML
			};

			if (options.report_user == dataset.report_user)  options.display_user = document.querySelector("section > div.section > header > select").value;

			$jnode$.requireContent("section", "/weekly", options);
		}

		if (dataset.adminRole) {
			var userSelect  = document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > button");
			var userNameDiv = document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > div > ul > li > div > div > ul > li:last-child > ul > li:first-child > div");
			var repositionUserSelect = false;
			var controllerName = "grid";

			if (dataset.selected_user) {
				selectedUserId        = dataset.user_id;
				userSelect.innerHTML  = $jnode$.escapeXML(dataset.selected_user);
				userNameDiv.innerHTML = $jnode$.escapeXML(dataset.selected_user);
			} else {
				userSelect.innerHTML  = $jnode$.escapeXML(i18n.label_not_selected);
				userNameDiv.innerHTML = "";
			}

			if (dataset.use_org)  controllerName = "tree";

			$jnode$.requireController(controllerName, {caller:nodeConf}).on(function() {
				var closeUserButton = document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > div > ul > li > div > button");

				if (dataset.use_org) {
					function setTreeText(entrySet) {
						var textDiv = document.createElement("div");
						textDiv.setAttribute("class", entrySet.type);

						var textSpan = document.createElement("span");
						textSpan.appendChild(document.createTextNode(entrySet.name));
						textDiv.appendChild(textSpan);

						if (entrySet.type == "user") {
							textDiv.appendChild(document.createTextNode(" ("));

							userIdSpan = document.createElement("span");
							userIdSpan.appendChild(document.createTextNode(entrySet.id));
							textDiv.appendChild(userIdSpan);

							textDiv.appendChild(document.createTextNode(" / "));

							positionNameSpan = document.createElement("span");
							positionNameSpan.appendChild(document.createTextNode(entrySet.position_name));
							textDiv.appendChild(positionNameSpan);
							textDiv.appendChild(document.createTextNode(")"));
						} else {
							textDiv.appendChild(document.createTextNode(" "));

							var orgSpan = document.createElement("span");
							orgSpan.setAttribute("class", "count");
							orgSpan.appendChild(document.createTextNode("(" + entrySet.org_count + ", " + entrySet.user_count + ")"));
							textDiv.appendChild(orgSpan);
						}

						return textDiv;
					}

					function setTreeList(entrySet) {
						if (entrySet.org_count + entrySet.user_count == 0)  return null;
						else                                                return [];
					}

					function addTreeClickListener(textNode, entrySet) {
						if (entrySet.type == "user") {
							var selectedUser = document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > div > ul > li > div > div > ul > li:first-child > aside.tree.org ul > li:last-child > span.checked");
							if (selectedUser)  selectedUser.removeAttribute("class");

							textNode.setAttribute("class", "checked");
							
							userNameDiv.innerHTML = $jnode$.escapeXML(entrySet.name) + " (" + entrySet.id + " / " + entrySet.position_name + ") @ " + entrySet.org_name;
							selectedUserId = entrySet.id;
						} else {
							$controller$.tree.toggle(entrySet.id);
						}
					}

					$controller$.tree.service({
						height: 268,
						datas:  dataset.orgDatas,
						text:   setTreeText,
						list:   setTreeList,
						click:  addTreeClickListener,
						retrieve: {
							url: "/ajax/org.json",
							method: "POST",
							params: {
								command: "getOrgUserList"
							},
							loading: {
								show: $controller$.loading.show,
								hide: $controller$.loading.hide
							}
						},
					});
				} else {
					var userTbody = document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > div > ul > li > div > div > ul > li:first-child > aside.grid > div > table > tbody");

					function addClickHandler(row, userData) {
						row.addEventListener("click", function(event) {
							var selectedRow = document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > div > ul > li > div > div > ul > li:first-child > aside.grid > div > table > tbody > tr.selected");
							if (selectedRow)  selectedRow.removeAttribute("class");

							this.setAttribute("class", "selected");
							userNameDiv.innerHTML = $jnode$.escapeXML(userData.user_name) + " (" + userData.user_id + " / " + userData.position_name + ")";
							selectedUserId = userData.user_id;
						}, false);
					}

					for (var i = 0; i < dataset.userList.length; i++) {
						var userData = dataset.userList[i];
						var row = document.createElement("tr");
						row.setAttribute("id", userData.user_id);
						userTbody.appendChild(row);

						var nameCell = row.insertCell(0);
						nameCell.appendChild(document.createTextNode(userData.user_name));

						var idCell = row.insertCell(1);
						idCell.appendChild(document.createTextNode(userData.user_id));

						var positionCell = row.insertCell(2);
						positionCell.appendChild(document.createTextNode(userData.position_name));

						addClickHandler(row, userData);
					}
				}

				userSelect.addEventListener("click", function(event) {
					if (isPhone)  document.body.style.overflow = "hidden";

					historyUserCallback = $jnode$.node.pushPseudoHistory(function() {
						closeUserButton.click();
					});

					if (!repositionUserSelect && (window.innerWidth > 736)) {
						userSelect.previousElementSibling.lastElementChild.style.right = (weekSelect.parentNode.offsetWidth - 10) + "px";
						repositionUserSelect = true;
					}

					if (this.previousElementSibling.getAttribute("class") == "show") {
						closeUserButton.click();
					} else {
						this.previousElementSibling.setAttribute("class", "show");
						blindDiv.setAttribute("class", "show user");

						userNameDiv.innerHTML = $jnode$.escapeXML(dataset.selected_user ? dataset.selected_user : "");

						if (dataset.use_org) {
							var selectedUser = document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > div > ul > li > div > div > ul > li:first-child > aside.tree.org ul > li:last-child > span.checked");
							if (selectedUser)  selectedUser.removeAttribute("class");

							if (dataset.user_id)  $controller$.tree.click(dataset.user_id);
						} else {
							var selectedRow = document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > div > ul > li > div > div > ul > li:first-child > aside.grid > div > table > tbody > tr.selected");
							if (selectedRow)  selectedRow.removeAttribute("class");

							if (dataset.user_id)  document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > div > ul > li > div > div > ul > li:first-child > aside.grid > div > table > tbody > tr[id='" + dataset.user_id + "']").setAttribute("class", "selected");

							$controller$.grid.service({height:268, sortable:true});
						}
					}

				}, false);

				userSelect.previousElementSibling.firstElementChild.addEventListener("click", function(event) {
					if (window.innerWidth > 736) {
						closeUserButton.click();
					}
				}, false);

				closeUserButton.addEventListener("click", function(event) {
					if (isPhone)  document.body.style.removeProperty("overflow");
					if (historyUserCallback)  historyUserCallback();

					this.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "hide");
					blindDiv.removeAttribute("class");
				}, false);

				document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > div > ul > li > div > div > ul > li:last-child > ul > li > button").addEventListener("click", function(event) {
					if (selectedUserId) {
						closeUserButton.click();
						moveWeekly(selectedUserId);
					} else {
						userNameDiv.innerHTML = "<FONT class=\"alert\">" + i18n.alert_select_report_user + "</FONT>";
					}
				}, false);
			});
		}

		var closeWeekButton = document.querySelector("section > div.section > footer > ul > li > ul > li:last-child > div > ul > li > div > button");

		weekSelect.addEventListener("click", function(event) {
			if (this.previousElementSibling.getAttribute("class") == "show") {
				closeWeekButton.click();
			} else {
				if (dataset.adminRole && dataset.selected_user == null) {
					$controller$.prompt.confirm(i18n.alert_select_report_user, function(close) {
						close();
						document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > button").click();
					});
				} else {
					if (isPhone)  document.body.style.overflow = "hidden";

					historyWeekCallback = $jnode$.node.pushPseudoHistory(function() {
						closeWeekButton.click();
					});

					if (parseInt(dataset.report_enddate.substring(dataset.report_enddate.length - 2), 10) > 2) {
						displayCalendar(rEnddate, "week", periodDoms, weekCalendar, dataset.report_enddate);
					} else {
						displayCalendar(rStartdate, "week", periodDoms, weekCalendar, dataset.report_startdate);
					}

					this.previousElementSibling.setAttribute("class", "show");
					blindDiv.setAttribute("class", "show period");
				}
			}
		}, false);

		weekSelect.previousElementSibling.firstElementChild.addEventListener("click", function(event) {
			if (window.innerWidth > 736) {
				closeWeekButton.click();
			}
		}, false);

		blindDiv.addEventListener("click", function(event) {
			if (this.getAttribute("class") == "show user") {
				document.querySelector("section > div.section > footer > ul > li > ul > li.select_user > div > ul > li > div > button").click();
			} else {
				closeWeekButton.click();
			}
		}, false);

		closeWeekButton.addEventListener("click", function(event) {
			if (isPhone)  document.body.style.removeProperty("overflow");
			if (historyWeekCallback)  historyWeekCallback();

			this.parentNode.parentNode.parentNode.parentNode.setAttribute("class", "hide");
			blindDiv.removeAttribute("class");
		}, false);

		document.querySelector("section > div.section > header > select").addEventListener("change", function(event) {
			document.querySelector("section > div.section > article > ul > li:first-child").setAttribute("class", this.value);
		}, false);

		document.querySelector("section > div.section > footer > ul > li > ul > li:last-child > div > ul > li > div > div > ul > li:last-child > ul > li > button").addEventListener("click", function(event) {
			closeWeekButton.click();
			moveWeekly(dataset.user_id);
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};