$$css_refer$$("pohe_kr.w.slider");
$$js_import$$("pohe_kr.w.slider.Resolver");
$$js_import$$("pohe_kr.w.slider.Service");