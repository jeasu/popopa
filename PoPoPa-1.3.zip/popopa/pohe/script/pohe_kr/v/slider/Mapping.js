/*
 * @(#)pohe_kr.v.slider.Mapping.js  1.4, 2014-03-24
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.4, 2014-03-24
 */
$$js_namespace$$("pohe_kr.v.slider");

/**
 * POHE SLIDER를 Wide Screen 사용자와 Mobile Screen 사용자의 UX 환경에 맞게 설정해 주는 Mapping 객체.
 */
pohe_kr.v.slider.Mapping = {
};