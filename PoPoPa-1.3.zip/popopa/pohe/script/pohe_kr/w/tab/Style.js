/*
 * @(#)pohe_kr.w.tab.Style.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.tab");

/**
 * position 설정 가능하고 전체 너비가 영역을 벗어날 때 스크롤이 생기는 TAB의 Style 객체.
 */
pohe_kr.w.tab.Style = {

	/**
	 * corona style
	 */
	".corona" : {
		tabs: {
			width:"100%",
			height:null,
			border:"1",
			bordercolor:"#6979B9",
			borderradius:null,
			padding:"3px",
			bgcolor:"#E2F0FC",
			spacing:"1px",
			spacingcolor:"#CCE3FC",
			spacingbackground:null,
			positionrevision:"1",
			align:"left",
			layout:"filled"
		},
		":selected": {
			align:"center",
			height:"20",
			hspace:"-1",
			hpad:"7",
			outerradius:null,
			innerradius:null,
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/corona/${tab_position}/tab_selected_bg.gif') repeat-x ${tab_opposite_position}"
		},
		":hover": {
			font:"font-size:9pt; color:#08429A; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/corona/${tab_position}/tab_hover_bg.gif')"
		},
		":link": {
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/corona/${tab_position}/tab_link_bg.gif')"
		}
	},

	/**
	 * ie style
	 */
	".ie" : {
		tabs: {
			width:"100%",
			height:null,
			border:"1",
			bordercolor:"#737B83",
			borderradius:null,
			padding:"3px",
			bgcolor:"#FFFFFF",
			spacing:"0px",
			spacingcolor:"#FFFFFF",
			spacingbackground:null,
			positionrevision:"1",
			align:"left",
			layout:"fixed"
		},
		":selected": {
			align:"center",
			height:"28",
			hspace:"-1",
			hpad:"7",
			outerradius:null,
			innerradius:null,
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/ie/${tab_position}/tab_selected_bg.gif') repeat-x ${tab_opposite_position}"
		},
		":hover": {
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/ie/${tab_position}/tab_hover_bg.gif')"
		},
		":link": {
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/ie/${tab_position}/tab_link_bg.gif')"
		}
	},

	/**
	 * mac style
	 */
	".mac" : {
		tabs: {
			width:"100%",
			height:null,
			border:"1",
			bordercolor:"#6E6C71",
			borderradius:null,
			padding:"3px",
			bgcolor:"#FFFFFF",
			spacing:"0px; spacing-${tab_position}:6px",
			spacingcolor:"#6E6C71",
			spacingbackground:"url('${pohe_img_base_url}/w/tab/mac/${tab_position}/tab_border_${tab_position}.gif') repeat-x ${tab_position}",
			positionrevision:"1",
			align:"center",
			layout:"fixed"
		},
		":selected": {
			align:"center",
			height:"21",
			hspace:"0",
			hpad:"7",
			outerradius:"10px",
			innerradius:null,
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/mac/${tab_position}/tab_selected_bg.gif') repeat-x ${tab_opposite_position}"
		},
		":hover": {
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/mac/${tab_position}/tab_hover_bg.gif')"
		},
		":link": {
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/mac/${tab_position}/tab_link_bg.gif')"
		}
	},

	/**
	 * macx style
	 */
	".macx" : {
		tabs: {
			width:"100%",
			height:null,
			border:"1",
			bordercolor:"#C7C7C7",
			borderradius:"4px",
			padding:"7px 10px",
			bgcolor:"#E5E5E5",
			spacing:"3px 0px",
			spacingcolor:"#E5E5E5",
			spacingbackground:null,
			positionrevision:"11",
			align:"center",
			layout:"fixed"
		},
		":selected": {
			align:"center",
			height:"21",
			hspace:"-1",
			hpad:"7",
			outerradius:"4px",
			innerradius:"4px",
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/macx/tab_selected_bg.gif')"
		},
		":hover": {
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/macx/tab_hover_bg.gif')"
		},
		":link": {
			font:"font-size:9pt; color:#000000; text-decoration:none; cursor:default",
			background:"url('${pohe_img_base_url}/w/tab/macx/tab_link_bg.gif')"
		}
	}
};