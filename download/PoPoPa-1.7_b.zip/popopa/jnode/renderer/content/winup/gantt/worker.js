$content$.winup.gantt.worker = {
	service: function() {
		var that = this;
		replaceTargetSelect = document.workerForm.replace_target;
		replaceTargetSelect.style.maxWidth = replaceTargetSelect.offsetWidth + "px";
		replaceTargetSelect.style.width    = "100%";

		var memberTbody = document.querySelector("aside.winup article > div.winup > form > table.form > tbody");
		var includedMemberList = this.dataset.includedMemberList;
		var excludedMemberList = this.dataset.excludedMemberList;
		var memberList         = this.dataset.memberList;
		var useOrg             = this.dataset.use_org;

		var includedMemberCount = includedMemberList.length;
		var excludedMemberCount = excludedMemberList.length;

		function appendSelect(td, selectedInfo) {
			var select = document.createElement("select");
			td.appendChild(select);

			for (var i = 0; i < memberList.length; i++) {
				var userId    = memberList[i].user_id;
				var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
				var userInfo  = (isRetiree ? i18n.label_retiree + ": " : "") + memberList[i].user_name + " (" + (isRetiree ? userId.substring(13, userId.length - 1) : userId) + " / " + memberList[i].position_name + ")";
				if (useOrg)  userInfo += " @ " + memberList[i].org_name;

				var option = new Option(userInfo, userId, false, false);
				select.options.add(option);

				if (isRetiree)  option.setAttribute("class", "retiree");
			}

			if (Object.prototype.toString.call(selectedInfo) == "[object Object]") {
				var userId    = selectedInfo.user_id;
				var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
				var userInfo  = (isRetiree ? i18n.label_retiree + " / " : "") + i18n.label_nonmember + ": " + selectedInfo.user_name + " (" + (isRetiree ? userId.substring(13, userId.length - 1) : userId) + " / " + selectedInfo.position_name + ")";
				if (useOrg)  userInfo += " @ " + selectedInfo.org_name;

				var option = new Option(userInfo, userId, true, true);
				select.options.add(option);

				select.setAttribute("name", userId);
				if (isRetiree)  option.setAttribute("class", "retiree");
			} else {
				select.setAttribute("name", selectedInfo);
				select.value = selectedInfo;
			}
		}

		for (var i = 0; i < includedMemberCount; i++) {
			var userId    = includedMemberList[i].user_id;
			var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
			var userInfo  = (isRetiree ? i18n.label_retiree + ": " : "") + includedMemberList[i].user_name + " (" + (isRetiree ? userId.substring(13, userId.length - 1) : userId) + " / " + includedMemberList[i].position_name + ")";
			if (useOrg)  userInfo += " @ " + includedMemberList[i].org_name;

			var tr = document.createElement("tr");
			memberTbody.appendChild(tr);

			var completedCountSpan = document.createElement("span");
			completedCountSpan.setAttribute("title", i18n.label_completed_task_count);
			completedCountSpan.innerHTML = includedMemberList[i].completed_count

			var scheduledCountSpan = document.createElement("span");
			scheduledCountSpan.setAttribute("title", i18n.label_scheduled_task_count);
			scheduledCountSpan.innerHTML = includedMemberList[i].scheduled_count

			var th = document.createElement("th");
			th.appendChild(document.createTextNode(userInfo + " ["));
			th.appendChild(completedCountSpan);
			th.appendChild(document.createTextNode(", "));
			th.appendChild(scheduledCountSpan);
			th.appendChild(document.createTextNode("]"));
			tr.appendChild(th);

			if (isRetiree)  th.setAttribute("class", "retiree");

			var td = document.createElement("td");
			td.setAttribute("class", "select");
			tr.appendChild(td);

			appendSelect(td, userId);
		}

		if (excludedMemberCount > 0) {
			var excludedTr = document.createElement("tr");
			memberTbody.appendChild(excludedTr);

			var excludedTh = document.createElement("th");
			excludedTh.colSpan = 2;
			excludedTh.setAttribute("class", "worker_nonmember");
			excludedTh.appendChild(document.createTextNode(i18n.label_change_worker_nonmember));
			excludedTr.appendChild(excludedTh);
		}

		for (var i = 0; i < excludedMemberCount; i++) {
			var userId    = excludedMemberList[i].user_id;
			var isRetiree = (userId.search(/^[$][{].+[}]$/) == 0);
			var userInfo  = (isRetiree ? i18n.label_retiree + ": " : "") + excludedMemberList[i].user_name + " (" + (isRetiree ? userId.substring(13, userId.length - 1) : userId) + " / " + excludedMemberList[i].position_name + ")";
			if (useOrg)  userInfo += " @ " + excludedMemberList[i].org_name;

			var tr = document.createElement("tr");
			memberTbody.appendChild(tr);

			var completedCountSpan = document.createElement("span");
			completedCountSpan.setAttribute("title", i18n.label_completed_task_count);
			completedCountSpan.innerHTML = excludedMemberList[i].completed_count

			var scheduledCountSpan = document.createElement("span");
			scheduledCountSpan.setAttribute("title", i18n.label_scheduled_task_count);
			scheduledCountSpan.innerHTML = excludedMemberList[i].scheduled_count

			var th = document.createElement("th");
			th.appendChild(document.createTextNode(userInfo + " ["));
			th.appendChild(completedCountSpan);
			th.appendChild(document.createTextNode(", "));
			th.appendChild(scheduledCountSpan);
			th.appendChild(document.createTextNode("]"));
			tr.appendChild(th);

			if (isRetiree)  th.setAttribute("class", "retiree");

			var td = document.createElement("td");
			td.setAttribute("class", "select");
			tr.appendChild(td);

			appendSelect(td, excludedMemberList[i]);
		}

		var winupHeight = 118 + 31 * (includedMemberCount + excludedMemberCount) + (excludedMemberCount > 0 ? 36 : 0);
		if (winupHeight > 495)  winupHeight = 495;

		$controller$.winup.resize(700, winupHeight);
		$controller$.winup.moveToCenter();

		document.querySelector("aside.winup article > div.winup > form > ul.submit > li:last-child > button").addEventListener("click", function(event) {
			var users = [];
			var replacedUsers = document.querySelectorAll("aside.winup article > div.winup > form > table > tbody > tr > td > select");

			for (var i = 0; i < replacedUsers.length; i++) {
				var userId    = replacedUsers[i].getAttribute("name");
				var newUserId = replacedUsers[i].value;

				if (userId != newUserId) {
					users.push({
						user_id:     userId,
						new_user_id: newUserId
					});
				}
			}

			var userCount = users.length;

			if (userCount > 0) {
				$controller$.loading.show();

				var replaceTarget = document.querySelector("aside.winup article > div.winup > form > ul.submit > li:first-child > select").value;

				var params = {
					command:        "replaceTaskUser",
					project_id:     that.conf.project_id,
					replacedUsers:  JSON.stringify(users),
					replace_target: replaceTarget
				}

				$jnode$.ajax.service({
					"url":      "/ajax/project.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						var userMap = $content$.section.gantt.userMap;

						for (var i = 0; i < userCount; i++) {
							var newUserId = users[i].new_user_id;
							var isRetiree = (newUserId.search(/^[$][{].+[}]$/) == 0);
							var userLis = document.querySelectorAll("body > section > div > ul > li:first-child > ul > li:last-child > div > div > label > div > ul" + (replaceTarget == "scheduled" ? ":not(.completed)" : "") + " > li:last-child > ul > li:last-child[id='" + users[i].user_id + "']");

							for (var j = 0; j < userLis.length; j++) {
								userLis[j].setAttribute("id", newUserId);

								if (isRetiree) {
									userLis[j].setAttribute("class", "retiree");
									userLis[j].innerHTML = "<SPAN>" + $jnode$.escapeXML(userMap[newUserId].user_name) + "</SPAN>";
								} else {
									userLis[j].removeAttribute("class");
									userLis[j].innerHTML = $jnode$.escapeXML(userMap[newUserId].user_name);
								}
							}
						}

						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			} else {
				$controller$.winup.close();
			}
		}, false);
	}
};