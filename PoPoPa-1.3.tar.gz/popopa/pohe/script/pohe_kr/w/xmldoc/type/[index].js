$$js_import$$("pohe_kr.w.xmldoc.type.JSD");
$$js_import$$("pohe_kr.w.xmldoc.type.TLD");