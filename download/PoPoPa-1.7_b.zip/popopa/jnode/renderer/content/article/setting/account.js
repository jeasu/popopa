$content$.article.setting.account = {
	service: function() {
		var that      = this;
		var updateOrg = false;

		$jnode$.pushHistory(that.conf);

		if (!that.dataset.readonly) {
			if (useOrg && ((that.dataset.userInfo.level_id == "1") || !that.dataset.exclude_admin)) {
				updateOrg = true;

				document.userForm.org_name.addEventListener("click", function(event) {
					$jnode$.requireContent("winup", "/setting/org/select", {
						useLoading: true,
						icon:       true,
						title:      i18n.label_select_org,
						width:      420,
						height:     268,
						renderer:   "-j"
					});
				}, false);
			}

			document.querySelector("div.section > article > div.article > ul.submit > li:last-child > button:first-child").addEventListener("click", function(event) {
				var alertNode      = this.parentNode.previousElementSibling;
				var positionSelect = document.userForm.position_id;
				var params = {
					command:       "updateUser",
					user_name:     document.userForm.user_name.value.trim(),
					user_id:       document.userForm.user_id.value,
					position_id:   positionSelect.value,
					position_name: positionSelect.options[positionSelect.selectedIndex].text
				};

				if (updateOrg) {
					params.update_org = "true";
					params.org_id     = document.userForm.org_id.value;
					params.org_name   = document.userForm.org_name.value;
				}

				var alertMessage    = null;

				if (params.user_name == "") {
					alertMessage = i18n.alert_input_user_name;
					document.userForm.user_name.select();
				}
				
				if (alertMessage) {
					alertNode.innerHTML = alertMessage;
				} else {
					$controller$.loading.show();

					$jnode$.ajax.service({
						"url":      "/ajax/user.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							document.querySelector("body > header > ul > li:last-child > ul > li.account").innerHTML = $jnode$.escapeHTML(params.user_name);
							alertNode.innerHTML = "";
							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});
				}
			}, false);
		}

		document.querySelector("div.section > article > div.article > ul.submit > li:last-child > button:last-child").addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/user/password_change", {
				useLoading: true,
				icon:       true,
				title:      i18n.label_change_password,
				width:      420,
				height:     225
			});
		}, false);
	}
};