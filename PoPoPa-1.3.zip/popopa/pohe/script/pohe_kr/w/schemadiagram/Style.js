/*
 * @(#)pohe_kr.w.schemadiagram.Style.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.schemadiagram");

/**
 * XML Schema를 Diagram으로 표현해주는 HTMLElement의 Style 객체.
 */
pohe_kr.w.schemadiagram.Style = {
	/**
	 * grobal style
	 */
	"$" : {
		width:null,
		height:null,
		expand:"element",
		border:"1",
		bordercolor:"#ABADB3",
		bgcolor:"#FFFFFF",
		padding:"10px",
		fontsize : "14px",
		elementcolor : "#6E6C00",
		attributecolor : "#7F007F",
		attributevaluecolor : "#2A00FF",
		typecolor : "#008080",
		childcolor : "#BF5F3F",
		annotationcolor : "#3F7F5F",
		annotationtype : "html"
	}
};