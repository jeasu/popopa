i18n = JSON.parse($module$.base64.decode(i18n));

document.querySelector("body > header > ul > li:last-child > ul > li.help").addEventListener("click", function(event) {
	var helpWin = window.open($jnode$.contextPath + "/help/", "popopa_help", "menubar=no, status=no, toolbar=no, scrollbars=yes, resizable=yes");
	helpWin.focus();
}, false);

document.querySelector("body > header > ul > li:last-child > ul > li.logout").addEventListener("click", function(event) {
	$controller$.loading.show();
	document.logoutForm.submit();
}, false);

var langContainer = document.querySelector("body > section > div.section > form > ul.status > li:last-child");
var langSelect = langContainer.firstElementChild;
langContainer.style.width = (langSelect.offsetWidth + 2) + "px";

var button = document.querySelector("body > section > div.section > form > article > div.article > ul > li:last-child > button");

langSelect.addEventListener("change", function(event) {
	$controller$.loading.show();
	var lang = this.value;

	$jnode$.ajax.service({
		"url":      "/ajax/regist.json",
		"method":   "POST",
		"datatype": "json",
		"headers": {
			"Content-Type": "application/json",
			"Accept":       "application/json"
		},
		"params": {
			"command": "changeLang",
			"lang":    lang
		},
		"success": function(response) {
			langContainer.style.removeProperty("width");

			i18n = response.i18n;
			document.querySelector("html").setAttribute("lang", i18n.lang);
			document.querySelector("body > section > div.section > form > article > div.article > div.notes").innerHTML = i18n.label_create_admin_desc;
			document.querySelector("body > section > div.section > form > ul.status > li:first-child").innerHTML = i18n.label_create_admin;
			document.registForm.querySelector("th.account_info"    ).innerHTML = i18n.label_account_info;
			document.registForm.querySelector("th.admin_name"      ).innerHTML = i18n.label_admin_name;
			document.registForm.querySelector("th.admin_id"        ).innerHTML = i18n.label_admin_id;
			document.registForm.querySelector("th.password"        ).innerHTML = i18n.label_password;
			document.registForm.querySelector("th.confirm_password").innerHTML = i18n.label_confirm_password;
			document.registForm.querySelector("th.additional_info" ).innerHTML = i18n.label_additional_info;
			document.registForm.querySelector("th.position"        ).innerHTML = i18n.label_position;
			document.registForm.querySelector("th.admin_role"      ).innerHTML = i18n.label_admin_role;
			button.innerHTML = i18n.label_create_admin;
			$controller$.prompt.setLabel({ok:i18n.label_ok, cancel:i18n.label_cancel});

			var excludeAdminOptions = document.registForm.exclude_admin.options;
			excludeAdminOptions[0].text = i18n.label_admin_role_only;
			excludeAdminOptions[1].text = i18n.label_admin_role_member;

			var positionOptions = document.registForm.position_id.options;
			for (var i = 0; i < positionOptions.length; i++) {
				positionOptions[i].text = response.positionList[i + 1].position_name;
			}

			langContainer.style.width = (langSelect.offsetWidth + 2) + "px";

			$controller$.loading.hide();
		},
		"error": function(error) {
			$jnode$.ajax.alertError(error);
			$controller$.loading.hide();
		}
	});
}, false);

document.registForm.exclude_admin.addEventListener("change", function(event) {
	var that = this;

	$controller$.prompt.confirm((that.value == "true" ? i18n.alert_change_admin_role_only : i18n.alert_change_admin_role_member), null, function(close) {
		that.value = (that.value == "true" ? "false" : "true");
		close();
	});
}, false);

button.addEventListener("click", function(event) {
	var alertMessage = "";

	if (document.registForm.user_name.value == "") {
		alertMessage = i18n.alert_input_admin_name;
		document.registForm.user_name.focus();
	} else if (document.registForm.user_id.value == "") {
		alertMessage = i18n.alert_input_admin_id;
		document.registForm.user_id.focus();
	} else if (!/^[\w|\.|\-]+$/g.test(document.registForm.user_id.value)) {
		alertMessage = i18n.alert_invalid_admin_id;
		document.registForm.user_id.select();
	} else if (document.registForm.user_id.value.length > 30) {
		alertMessage = i18n.alert_maxlength_admin_id;
		document.registForm.user_id.select();
	} else if (document.registForm.user_password.value == "") {
		alertMessage = i18n.alert_input_password;
		document.registForm.user_password.focus();
	} else if (document.registForm.user_password.value != document.registForm.confirm_password.value) {
		alertMessage = i18n.alert_different_password;
		document.registForm.confirm_password.select();
	}

	if (alertMessage) {
		document.querySelector("body > section > div.section > form > article > div.article > ul > li.alert").innerHTML = alertMessage;
	} else {
		$controller$.loading.show();
		document.registForm.submit();
	}
}, false);

document.registForm.user_name.focus();