/*
 * @(#)pohe_kr.w.htmleditor.Style.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.htmleditor");

/**
 * HTML을 WYSIWYG(What You See Is What You Get) 형태로 편집이 가능한 HTMLEDITOR의 Style 객체.
 */
pohe_kr.w.htmleditor.Style = {

	/**
	 * grobal style sheet
	 */
	"$" : {
		width:"100%",
		height:"300",
		border:"1",
		bordercolor:"#ABADB3",
		toolbarbgcolor:"#D1D1D1",
		switchmode:"false",
		editsource:"false"
	}
};