$jnode$.requireContent("helpnav", "/menu", {useLoading:true, renderer:"-j", blang:document.langForm.lang.value});

document.querySelector("body > header").addEventListener("click", function(event) {
	if (window.innerWidth < 737) {
		if (this.getAttribute("class") == "unfold")  this.setAttribute("class", "fold");
		else                                         this.setAttribute("class", "unfold");
	}
}, false);


document.querySelector("body > section").addEventListener("click", function(event) {
	var header = this.parentNode.firstElementChild;

	if (header.getAttribute("class") == "unfold")  header.setAttribute("class", "fold");
}, false);

document.langForm.lang.addEventListener("change", function(event) {
	$controller$.loading.show();
	document.langForm.submit();
}, false);

var menuClassDiv = document.querySelector("body > header > ul > li:last-child > div.menu_class");