$content$.article.setting.org = {
	posSortMap: {},
	appendUserRow: function(userTbody, userData) {
		var row = document.createElement("tr");
		userTbody.appendChild(row);

		var nameCell = row.insertCell(0);
		nameCell.appendChild(document.createTextNode(userData.user_name));

		var idCell = row.insertCell(1);
		idCell.appendChild(document.createTextNode(userData.user_id));

		var positionCell = row.insertCell(2);
		positionCell.appendChild(document.createTextNode(userData.position_name));
		positionCell.setAttribute("id", userData.position_id);
		positionCell.setAttribute("sid", $content$.article.setting.org.posSortMap[userData.position_id.toString()]);

		row.addEventListener("click", function(event) {
			var selectedRow = userTbody.querySelector("tbody > tr.selected");
			if (selectedRow)  selectedRow.removeAttribute("class");

			this.setAttribute("class", "selected");
			document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:nth-child(2)").disabled = false;
			document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:last-child").disabled = false;
		}, false);
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;

		if (windowWidth > 736) {
			$controller$.grid.resize(null, windowHeight - 143);  // 43 + 30 + 10 + 37 + 10 + 10 + 18
			$controller$.tree.resize(null, windowHeight - 177);
		} else {
			$controller$.grid.removeHeight();
			$controller$.tree.resize(null, windowHeight - 56);
		}

		$controller$.grid.resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();
		var that = this;
		$jnode$.pushHistory(that.conf);

		var positionList = this.dataset.positionList;

		function lpad(sortIndex) {
			if (sortIndex < 10) {
				return "0" + sortIndex.toString();
			} else {
				return sortIndex.toString();
			}
		}

		for (var i = 0; i < positionList.length; i++) {
			this.posSortMap[positionList[i].position_id.toString()] = lpad(i);
		}

		$jnode$.requireControllers(["grid", "tree"], {caller:that.conf}, function() {
			$controller$.grid.service({sortable:true});

			var orgDatas           = that.dataset.orgDatas;
			var topOrgId           = orgDatas.org_id;
			var orgAddButton       = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:first-child > button:first-child");
			var orgEditButton      = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:first-child > button:nth-child(2)");
			var reorganizeButton   = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:first-child > button:nth-child(3)");
			var useOrgSelect       = document.querySelector("div.section > article > div.article > fieldset > ul > li:first-child > select");
			var userAddButton      = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:first-child");
			var userEditButton     = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:nth-child(2)");
			var userPasswordButton = document.querySelector("div.section > article > div.article > fieldset > ul > li:last-child > button:last-child");
			var userTbody          = document.querySelector("aside.grid > div > table > tbody");
			var tumbtrackButton    = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:last-child > button:first-child");
			var orgCloseButton     = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > div:last-child > ul > li:last-child > button:last-child");
			var orgContainer       = document.querySelector("aside.tree:not([id])");
			var historyOrgCallback = null;

			orgAddButton.disabled       = true;
			orgEditButton.disabled      = true;
			reorganizeButton.disabled   = true;
			userEditButton.disabled     = true;
			userPasswordButton.disabled = true;

			function addMovableEvent(observerNode) {
				var selectedOrg = null;
				var movedOrg    = null;

				var compensatedWidth = ($jnode$.device.type == "desktop") ? 0 : 8;

				function createCloneNode() {
					orgContainer.setAttribute("class", "tree move");

					var currentOrgLi = selectedOrg.parentNode.parentNode;
					var currentOrgChildren = currentOrgLi.querySelectorAll("li > span + div ul > li:last-child");

					currentOrgLi.setAttribute("class", "current");

					for (var i = 0; i < currentOrgChildren.length; i++) {
						currentOrgChildren[i].setAttribute("class", "current");
					}

					movedOrg = selectedOrg.cloneNode(true);
					movedOrg.setAttribute("class", "moving");
					movedOrg.firstElementChild.innerHTML = "";
					movedOrg.style.top  = (selectedOrg.offsetTop - 2) + "px";
					movedOrg.style.left = (selectedOrg.offsetLeft -2) + "px";
					orgContainer.appendChild(movedOrg);
				}

				function repositonCloneNode(containerRange, movedX, movedY) {
					var cloneX = orgContainer.scrollLeft + movedX;
					var cloneY = orgContainer.scrollTop + movedY;

					// X축 스크롤 이동
					if (movedX > containerRange.width) {
						orgContainer.scrollLeft = cloneX - containerRange.width;
					} else if ((movedX < 0) && (orgContainer.scrollLeft > 0)) {
						orgContainer.scrollLeft = cloneX;
					}

					// 위치 이동 아이콘 이동
					if (movedX < 0) {
						if (orgContainer.scrollLeft > 0)  movedOrg.style.left = orgContainer.scrollLeft + "px";
						else                              movedOrg.style.left = 0 + "px";
					} else if (cloneX > containerRange.right) {
						movedOrg.style.left = containerRange.right + "px";
					} else {
						movedOrg.style.left = cloneX + "px";
					}

					// Y축 스크롤 이동
					if (movedY > containerRange.height) {
						orgContainer.scrollTop = cloneY - containerRange.height;
					} else if ((movedY < 0) && (orgContainer.scrollTop > 0)) {
						orgContainer.scrollTop = cloneY;
					}

					// 위치 이동 아이콘 이동
					if (movedY < 0) {
						if (orgContainer.scrollTop > 0)  movedOrg.style.top = orgContainer.scrollTop + "px";
						else                             movedOrg.style.top = 0 + "px";
					} else if (cloneY > containerRange.bottom) {
						movedOrg.style.top = containerRange.bottom + "px";
					} else {
						movedOrg.style.top = cloneY + "px";
					}

					var movableCursors = orgContainer.querySelectorAll("aside ul > li:not(.current):last-child > span > div > span:first-child");
					for (var i = 0; i < movableCursors.length; i++) {
						var cursorContainer = movableCursors[i].parentNode;
						var outbound = true;

						if ((cloneY > cursorContainer.offsetTop - 3) && (cloneY < cursorContainer.offsetTop + compensatedWidth + 18)) {
							if ((i > 0) && (cloneX > cursorContainer.offsetLeft - compensatedWidth - 10) && (cloneX < cursorContainer.offsetLeft + compensatedWidth + 7)) {
								movableCursors[i].firstElementChild.checked = true;
								outbound = false;
								break;
							} else if ((cloneX > cursorContainer.offsetLeft + compensatedWidth + 6) && (cloneX < cursorContainer.offsetLeft + compensatedWidth + 30)) {
								movableCursors[i].lastElementChild.previousElementSibling.checked = true;
								outbound = false;
								break;
							}
						}

						if (outbound) {
							var hoverCursor = orgContainer.querySelector("aside ul > li:not(.current):last-child > span > div > span:first-child > input:checked");
							if (hoverCursor)  hoverCursor.checked = false;
						}
					}
				}

				function applyMovableEvent() {
					var currentOrgLis = selectedOrg.parentNode.parentNode.parentNode.querySelectorAll("li.current");

					for (var i = 0; i < currentOrgLis.length; i++) {
						currentOrgLis[i].removeAttribute("class");
					}

					if (movedOrg)  orgContainer.removeChild(movedOrg);

					var hoverCursor = orgContainer.querySelector("aside ul > li:last-child > span > div > span:first-child > input:checked");
					if (hoverCursor) {
						hoverCursor.checked = false;
						var cursorOrgs   = hoverCursor.value.split("_");
						var cursor       = cursorOrgs[0];
						var orgId        = cursorOrgs[1];
						var nextOrgUl    = null;
						var movedOrgUl   = selectedOrg.parentNode.parentNode.parentNode;
						var parentOrgDiv = null;
						var oldParentDiv = movedOrgUl.parentNode;
						var orgSibling   = "0";
						var cursorValue  = cursor;

						if (cursor == "child") {
							parentOrgDiv = orgContainer.querySelector("aside ul[id='" + orgId + "'] > li:last-child > span + div");
							nextOrgUl    = parentOrgDiv.firstElementChild;
						} else {
							var prevOrgUl = orgContainer.querySelector("aside ul[id='" + orgId + "']");

							parentOrgDiv = prevOrgUl.parentNode;
							nextOrgUl    = prevOrgUl.nextElementSibling;

							if (nextOrgUl) {
								cursorValue = "previous";
								orgSibling  = nextOrgUl.getAttribute("id");
							} else {
								orgSibling  = prevOrgUl.getAttribute("id");
							}
						}

						if (movedOrgUl != nextOrgUl) {
							$controller$.loading.show();

							var params = {
								command:     "sortOrg",
								cursor:      cursorValue,
								org_sibling: orgSibling,
								old_parent:  oldParentDiv.parentNode.parentNode.getAttribute("id"),
								org_parent:  parentOrgDiv.parentNode.parentNode.getAttribute("id"),
								org_id:      movedOrgUl.getAttribute("id"),
							}

							$jnode$.ajax.service({
								"url":      "/ajax/org.json",
								"method":   "POST",
								"datatype": "json",
								"headers": {
									"Content-Type": "application/json",
									"Accept":       "application/json"
								},
								"params":  params,
								"success": function(response) {
									if (oldParentDiv != parentOrgDiv) {
										if (oldParentDiv.childElementCount == 1) {
											oldParentDiv.parentNode.previousElementSibling.removeAttribute("class");
										}
									}

									if (parentOrgDiv.childElementCount == 0) {
										parentOrgDiv.parentNode.previousElementSibling.setAttribute("class", "unfold");
									} else {
										$controller$.tree.unfold(params.org_parent);
									}

									parentOrgDiv.insertBefore(movedOrgUl, nextOrgUl);
									$controller$.loading.hide();
								},
								"error": function(error) {
									$jnode$.ajax.alertError(error);
									$controller$.loading.hide();
								}
							});
						}
					}
				}

				// Touch Event
				function handleTouchMovableEvent(iconNode, event) {
					selectedOrg = iconNode.parentNode;

					var startX = event.touches[0].pageX;
					var startY = event.touches[0].pageY;

					var containerRange = {
						right:  orgContainer.scrollWidth - 20,
						bottom: orgContainer.scrollHeight - 20,
						width:  orgContainer.offsetWidth - 22,
						height: orgContainer.offsetHeight - 20
					};

					function reposition(event) {
						var movedX = event.touches[0].pageX - (startX + orgContainer.scrollLeft - selectedOrg.offsetLeft);
						var movedY = event.touches[0].pageY - (startY + orgContainer.scrollTop  - selectedOrg.offsetTop);

						repositonCloneNode(containerRange, movedX, movedY);
					}

					function moveCloneNode(event) {
						createCloneNode();
						document.addEventListener("touchmove", reposition, false);
					}

					function detectMovableEvent(event) {
						if ((Math.abs(event.touches[0].pageX - startX) > 3) || (Math.abs(event.touches[0].pageY - startY) > 3)) {
							selectedOrg.removeEventListener("touchmove", detectMovableEvent, false);
							moveCloneNode(event);
						}
					}

					function clearMovableEvent(event) {
						orgContainer.setAttribute("class", "tree");
						selectedOrg.removeEventListener("touchmove", detectMovableEvent, false);
						selectedOrg.removeEventListener("touchend", clearMovableEvent, false);
						document.removeEventListener("touchmove", reposition, false);

						applyMovableEvent();
					}

					selectedOrg.addEventListener("touchmove", detectMovableEvent, false);
					selectedOrg.addEventListener("touchend", clearMovableEvent, false);
					event.preventDefault();
				}

				// Mouse Event
				function handleMouseMovableEvent(iconNode, event) {
					selectedOrg = iconNode.parentNode;

					var startX = event.pageX;
					var startY = event.pageY;

					var containerRange = {
						right:  orgContainer.scrollWidth - 20,
						bottom: orgContainer.scrollHeight - 20,
						width:  orgContainer.offsetWidth - 22,
						height: orgContainer.offsetHeight - 20
					};

					function reposition(event) {
						var movedX = event.pageX - (startX + orgContainer.scrollLeft - selectedOrg.offsetLeft);
						var movedY = event.pageY - (startY + orgContainer.scrollTop  - selectedOrg.offsetTop);

						repositonCloneNode(containerRange, movedX, movedY);
					}

					function moveCloneNode(event) {
						createCloneNode();
						document.addEventListener("mousemove", reposition, false);
					}

					function detectMovableEvent(event) {
						if ((Math.abs(event.pageX - startX) > 3) || (Math.abs(event.pageY - startY) > 3)) {
							selectedOrg.removeEventListener("mousemove", detectMovableEvent, false);
							moveCloneNode(event);
						}
					}

					function clearMovableEvent(event) {
						orgContainer.setAttribute("class", "tree");
						selectedOrg.removeEventListener("mousemove", detectMovableEvent, false);
						document.removeEventListener("mousemove", reposition, false);
						document.removeEventListener("mouseup", clearMovableEvent, false);

						applyMovableEvent();
					}

					selectedOrg.addEventListener("mousemove", detectMovableEvent, false);
					document.addEventListener("mouseup", clearMovableEvent, false);
					event.preventDefault();
				}

				observerNode.addEventListener("touchstart", function(event) {
					handleTouchMovableEvent(this, event);
				}, false);
				observerNode.addEventListener("mousedown", function(event) {
					handleMouseMovableEvent(this, event);
				}, false);
			}

			function setTreeText(entrySet) {
				var iconSpan = document.createElement("span");
				iconSpan.setAttribute("class", (entrySet.org_parent ? "org" : "company"));

				if (entrySet.org_parent > 0) {
					var nextCursorInput = document.createElement("input");
					nextCursorInput.setAttribute("type", "radio");
					nextCursorInput.setAttribute("name", "moved_cursor");
					nextCursorInput.setAttribute("value", "next_" + entrySet.org_id);

					iconSpan.appendChild(nextCursorInput);
					iconSpan.appendChild(document.createElement("span"));
				}

				var childCursorInput = document.createElement("input");
				childCursorInput.setAttribute("type", "radio");
				childCursorInput.setAttribute("name", "moved_cursor");
				childCursorInput.setAttribute("value", "child_" + entrySet.org_id);

				iconSpan.appendChild(childCursorInput);
				iconSpan.appendChild(document.createElement("span"));

				var textSpan = document.createElement("span");
				textSpan.appendChild(document.createTextNode(entrySet.org_name));

				var textContainer = document.createElement("div");
				textContainer.appendChild(iconSpan);
				textContainer.appendChild(textSpan);

				if (entrySet.org_parent > 0)  addMovableEvent(iconSpan);

				return textContainer;
			}

			function setTreeList(entrySet) {
				var list = entrySet.sub_org;
				return ((list && list.length) ? list : null);
			}

			function addTreeClickListener(textNode, entrySet) {
				document.querySelector("div.section > article > div.article > ul > li:first-child > div:first-child").innerHTML = $jnode$.escapeXML(entrySet.org_name);

				var selectedNode = document.querySelector("div.section > article > div.article > ul > li:first-child > div:last-child > ul > li > div > div > aside.tree ul > li > span.selected");
				if (selectedNode) {
					selectedNode.removeAttribute("class");
				}

				textNode.setAttribute("class", "selected");
				orgAddButton.disabled       = false;
				orgEditButton.disabled      = false;
				reorganizeButton.disabled   = false;
				userEditButton.disabled     = true;
				userPasswordButton.disabled = true;

				$controller$.loading.show();
				$controller$.grid.clear();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params": {
						command: "getUserList",
						org_id:  entrySet.org_id
					},
					"success": function(response) {
						for (var i = 0; i < response.length; i++) {
							that.appendUserRow(userTbody, response[i]);
						}

						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});

				if (tumbtrackButton.getAttribute("class") == null)  orgCloseButton.click();
			}

			$controller$.tree.service({
				datas:     orgDatas,
				id:        function(entrySet) { return entrySet.org_id },
				text:      setTreeText,
				list:      setTreeList,
				click:     addTreeClickListener,
				unfoldAll: true
			});

			$controller$.tree.click(topOrgId);

			window.addEventListener("resize", that.resize, false);
			that.resize();

			orgAddButton.addEventListener("click", function(event) {
				var selectedNode = document.querySelector("aside.tree ul > li > span.selected");

				$jnode$.requireContent("winup", "/setting/org/add", {
					useLoading: true,
					icon:       true,
					title:      i18n.label_add_org,
					width:      400,
					height:     118,
					renderer:   "-j",
					org_parent: selectedNode.parentNode.parentNode.getAttribute("id")
				});
			}, false);

			orgEditButton.addEventListener("click", function(event) {
				var selectedNode = document.querySelector("aside.tree ul > li > span.selected");
				var selectedTree = selectedNode.parentNode.parentNode;
				var orgParent    = selectedTree.parentNode.parentNode.parentNode.getAttribute("id");

				if (orgParent == null)  orgParent == "0";

				$jnode$.requireContent("winup", "/setting/org/edit", {
					useLoading: true,
					icon:       true,
					title:      i18n.label_edit_org,
					width:      400,
					height:     118,
					renderer:   "-j",
					top_org:    topOrgId,
					org_id:     selectedTree.getAttribute("id"),
					org_name:   selectedNode.firstElementChild.lastElementChild.firstChild.nodeValue,
					org_parent: orgParent
				});
			}, false);

			reorganizeButton.addEventListener("click", function(event) {
				var selectedNode = document.querySelector("aside.tree ul > li > span.selected");

				$jnode$.requireContent("winup", "/setting/org/reorganize", {
					useLoading: true,
					title:      i18n.label_reorganize_members,
					left_org:   selectedNode.parentNode.parentNode.getAttribute("id"),
					right_org:  topOrgId,
					open:       false
				});

				$controller$.winup.open({
					icon:   true,
					width:  705,
					height: 428
				}, function(close) {
					$content$.winup.setting.org.reorganize.applyParentTree();
					close();
				});
			}, false);

			// IE 9는 select의 콤보 아이콘을 수정하면 2개가 나옴.
			if (navigator.userAgent.indexOf(" MSIE 9.") > -1) {
				useOrgSelect.parentNode.setAttribute("class", "ie9");
			}

			useOrgSelect.addEventListener("change", function(event) {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/org.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  {
						command: "changeUsingOrg",
						use_org: "false"
					},
					"success": function(response) {
						setUserSettingMenu(false);
						document.querySelector("body > section > div.section > nav > div:last-child > fieldset > div > ul > li > label > input[name='article_menu'][value='/setting/user']").click();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}, false);

			userAddButton.addEventListener("click", function(event) {
				var selectedNode = document.querySelector("aside.tree ul > li > span.selected");

				$jnode$.requireContent("winup", "/setting/user/add", {
					useLoading: true,
					icon:       true,
					title:      i18n.label_add_user,
					width:      420,
					height:     310,
					renderer:   "-j",
					parentNode: "org",
					org_id:     selectedNode.parentNode.parentNode.getAttribute("id")
				});
			}, false);

			userEditButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/user/edit", {
					useLoading: true,
					icon:       true,
					title:      i18n.label_edit_user,
					width:      420,
					height:     248,
					renderer:   "-j",
					parentNode: "org"
				});
			}, false);

			userPasswordButton.addEventListener("click", function(event) {
				$jnode$.requireContent("winup", "/setting/user/password_reset", {
					useLoading: true,
					icon:       true,
					title:      i18n.label_reset_password,
					width:      420,
					height:     150,
					renderer:   "-j"
				});
			}, false);

			// 폰에서 부서 선택 팝업창을 띄우는 작업
			document.querySelector("div.section > article > div.article > ul > li:first-child > div:first-child").addEventListener("click", function(event) {
				if (isPhone) {
					document.body.style.overflow = "hidden";

					historyOrgCallback = $jnode$.node.pushPseudoHistory(function() {
						orgCloseButton.click();
					});
				}

				this.nextElementSibling.setAttribute("class", "popup");
			}, false);

			orgCloseButton.addEventListener("click", function(event) {
				if (isPhone) {
					document.body.style.removeProperty("overflow");
					if (historyOrgCallback)  historyOrgCallback();
				}

				this.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.removeAttribute("class");
			}, false);

			tumbtrackButton.addEventListener("click", function(event) {
				if (this.getAttribute("class") == "on")  this.removeAttribute("class");
				else                                     this.setAttribute("class", "on");
			}, false);
		});
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};