$$js_import$$("pohe_kr.m.switcher.Resolver");
$$js_import$$("pohe_kr.m.switcher.Service");