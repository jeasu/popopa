/*
 * @(#)pohe_kr.w.table.Style.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.table");

/**
 * Scrollable, Sortable, Shiftable 가능한 TABLE의 Style 객체.
 */
pohe_kr.w.table.Style = {

	/**
	 * grobal style
	 */
	"$" : {
		table: {
			width:"100%",
			height:null,
			cellspacing:"-1",
			cellpadding:"3",
			border:"1",
			bordercolor:"#8A9096",
			borderstyle:"solid",
			bgcolor:null
		},
		thead: {
			bgcolor:"#CED4DB",
			background:null
		},
		tbody: {
			bgcolor:null,
			background:null
		}
	}
};