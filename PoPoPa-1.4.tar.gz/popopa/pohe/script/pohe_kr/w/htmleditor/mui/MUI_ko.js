/*
 * @(#)pohe_kr.w.htmleditor.MUI_ko.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.htmleditor");

/**
 * The Korean(ko) Internationalization Object of HTMLEDITOR that is editable with WYSIWYG(What You See is What You Get).
 */
pohe_kr.w.htmleditor.MUI = {
	"defalut_font" : "맑은 고딕, Microsoft JhengHei, Meiryo",
	"font_name" : "글자체",
	"font_size" : "글자크기",
	"font_color" : "글자색",
	"highlight" : "강조",
	"bold" : "굵게",
	"italic" : "기울임꼴",
	"underline" : "밑줄",
	"strikethrough" : "취소선",
	"superscript" : "위첨자",
	"subscript" : "아래첨자",
	"leftpara" : "왼쪽 정렬",
	"centerpara" : "가운데 정렬",
	"rightpara" : "오른쪽 정렬",
	"orderedlist" : "번호 서식",
	"unorderedlist" : "글머리 기호 서식",
	"outdent" : "내어쓰기",
	"indent" : "들여쓰기",
	"cut" : "잘라내기",
	"copy" : "복사하기",
	"paste" : "붙여넣기",
	"paste_special" : "선택하여 붙여넣기",
	"remove_format" : "서식 제거",
	"undo" : "실행 취소",
	"redo" : "다시 실행",
	"refresh" : "새로 고침",
	"hyperlink" : "하이퍼링크",
	"table" : "표",
	"picture" : "이미지",
	"picture_url" : "이미지 주소",
	"picture_file" : "이미지 파일",
	"horizontalline" : "가로줄",
	"datetime" : "날짜/시간",
	"symbol" : "기호",
	"number" : "번호",
	"color" : "색",
	"border" : "두께",
	"line_style" : "선 모양",
	"paste_text" : "서식없는 텍스트 붙여넣기",
	"paste_html" : "HTML 형식으로 붙여넣기",
	"paste_clipboard" : "Clipboard로부터 붙여넣기",
	"retrieve_file" : "파일로 불러오기...",
	"retrieve_url" : "URL로 불러오기...",
	"mode_html" : "HTML 모드",
	"mode_text" : "텍스트 모드",
	"html_editor" : "HTML 편집",
	"html_source" : "HTML 소스",
	"file" : "파일",
	"url" : "URL",
	"ok" : "확인",
	"cancel" : "취소",
	"confirm" : "확인",
	"alert" : "알림",
	"confirm_textmode_attention" : "서식을 HTML에서 일반 TEXT로 변경하면 현재의 모든 서식이 지워집니다. 계속하시겠습니까?",
	"alert_hyperlink" : "하이퍼 링크를 만들어줄 영역를 선택해 주세요.",
	"alert_picture_pro_url" : "&quot;파일로 불러오기...&quot; 설정이 안 되어 있습니다. 관리자에게 문의해 주시기 바랍니다.",
	"alert_picture_pro_file" : "picturePro의 &quot;파일로 불러오기...&quot; 메뉴는 네트워크 환경에서만 사용할 수 있습니다.",
	"alert_number_range_alert" : "${0}에서 ${1} 사이의 값을 지정하십시오.",
	"alert_number_greater0_alert" : "0보다 큰 값을 지정하십시오."
};