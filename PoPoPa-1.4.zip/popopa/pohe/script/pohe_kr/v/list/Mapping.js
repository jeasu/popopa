/*
 * @(#)pohe_kr.v.list.Mapping.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.v.list");

/**
 * POHE LIST를 Wide Screen 사용자와 Mobile Screen 사용자의 UX 환경에 맞게 설정해 주는 Mapping 객체.
 */
pohe_kr.v.list.Mapping = {

	"styleclass" : {
		"$" : {
			"w" : "win7",
			"m" : "ios"
		},
		"menu" : {
			"w" : "menu",
			"m" : "ios"
		}
	}
};