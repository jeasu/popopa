/*
 * @(#)pohe_kr.w.toolbar.Style.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.toolbar");

/**
 * TOOLBAR로 표현해주는 HTMLElement의 Style 객체.
 */
pohe_kr.w.toolbar.Style = {

	/**
	 * grobal style
	 */
	"$" : {
		linkbordercolor : "#FFBD69",
		linkbgcolor : "#FFE7A2",
		submenubordercolor : "#ABADB3",
		submenubgcolor : "#FAFAFA",
		submenuseparatecolor : "#C5C5C5"
	}
};