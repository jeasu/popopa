var refreshButton = document.querySelector("body > section > div.section > article > div.article > ul > li > ul.error > li:last-child > div.button > button");
if (refreshButton) {
	refreshButton.addEventListener("click", function(event) {
		$controller$.loading.show();
		document.location.reload();
	}, false);
}