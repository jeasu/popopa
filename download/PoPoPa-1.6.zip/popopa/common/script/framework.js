var useOrg = false;

function handleHash(hash, nodeConf) {
	var separatedHashs = hash.split(":");
	var nodeType       = separatedHashs[0].substring(1);
	var nodeId         = separatedHashs[1];

	if (nodeId) {
		if (nodeId.indexOf("/") != 0)  nodeId = "/" + nodeId;
	} else {
		nodeId = "/index";
	}

	if (nodeType == "section") {
		var menuInput = document.querySelector("body > nav > ul > li > label > input[name='section_menu'][value='" + nodeId + "']");

		if (nodeConf && (nodeId == "/weekly" || nodeId == "/monthly")) {
			menuInput.checked = true;
			$jnode$.requireContent("section", nodeId, nodeConf);
		} else {
			if (menuInput)  menuInput.click();
			else            $jnode$.requireContent("section", nodeId, {useLoading:true});
		}
	} else {
		if (nodeType == "article") {
			var separatedIds = nodeId.split("/");
			var sectionId    = "/" + separatedIds[1];

			if (nodeId == "/setting/user" || nodeId == "/setting/org") {
				if (useOrg)  nodeId == "/setting/org";
				else         nodeId == "/setting/user";
			}

			var articleMenu = document.querySelector("body > section > div.section > nav > div:last-child > fieldset > div > ul > li > label > input[name='article_menu'][value='" + nodeId +"']");
			if (articleMenu) {
				articleMenu.click();
			} else {
				$jnode$.requireContent("section", sectionId, {useLoading:true, "articleId":nodeId});
			}
		} else {
			$jnode$.requireContent(nodeType, nodeId, {useLoading:true});
		}
	}
}

var errorHandler = {
	"*": function(error, options, doEmbeddedErrorHandler) {
		doEmbeddedErrorHandler(error, options, function() {
			if (options.nodeType == "article") {
				if      (options.nodeId.indexOf("/setting/") == 0)  $content$.section.setting.resize();
				else if (options.nodeId.indexOf("/project/") == 0)  $content$.section.project.resize();
			}
		});
	},
	"503": function(error, options, doEmbeddedErrorHandler) {
		if (options.nodeType == "article" && options.nodeId == "/setting/about") {
			doEmbeddedErrorHandler(error, options, function() {
				$content$.section.setting.resize();
				var refreshButton = document.querySelector("body > section > div.section > article > div.article > ul > li > ul.error > li:last-child > div.button > button");
				if (refreshButton) {
					refreshButton.addEventListener("click", function(event) {
						handleHash("#article:/setting/about");
					}, false);
				}
			});
		} else {
			document.location.reload();
		}
	}
};

var historyHandler = {
	handler: handleHash
}