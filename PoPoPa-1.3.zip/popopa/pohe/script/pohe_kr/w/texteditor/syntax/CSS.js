/*
 * @(#)pohe_kr.w.texteditor.syntax.CSS.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.texteditor.syntax");

/**
 * TEXT 문자열에 CSS 타입으로 color syntax를 보여주는 객체.
 */
pohe_kr.w.texteditor.syntax.CSS = {

	/**
	 * TEXT 문자열에 CSS 타입으로 설정할 syntax color.
	 */
	ColorSyntax: {
		"comments": "#3F7F5F",
		"selector": "#6E6C00",
		"property": "#7F007F",
		"value":    "#2A00FF"
	},

	/**
	 * TEXT 문자열을 CSS 타입으로 color syntax를 준다.
	 *
	 * @param  {String} text  {@nullable false} CSS 타입으로 color syntax를 줄 TEXT 문자열
	 * @return {String} CSS 타입으로 color syntax를 준 HTML 코드
	 */
	getColorSyntax: function(text) {
		var colorSyntaxComments=pohe_kr.w.texteditor.syntax.CSS.ColorSyntax.comments;var colorSyntaxSelector=pohe_kr.w.texteditor.syntax.CSS.ColorSyntax.selector;var colorSyntaxProperty=pohe_kr.w.texteditor.syntax.CSS.ColorSyntax.property;var colorSyntaxValue=pohe_kr.w.texteditor.syntax.CSS.ColorSyntax.value;text="}"+text.replace(/\&/g,"[\tamp\t]").replace(/\</g,
"[\tlt\t]").replace(/\>/g,"[\tgt\t]");var blockCommentsMatched=text.match(new RegExp("/\\*[\\s\\S]*?\\*/","gm"));var objBlockCommentsReg={};if(blockCommentsMatched)for(var i=0;i<blockCommentsMatched.length;i++){objBlockCommentsReg["[[/*\tblock comments "+i+"\t*/]]"]=blockCommentsMatched[i];text=text.replace(blockCommentsMatched[i],"[[/*\tblock comments "+i+"\t*/]]")}var propertyValueMatched=text.match(new RegExp("{[\\s\\S]*?}","gm"));var objPropertyValueReg={};if(propertyValueMatched)for(var i=0;i<
propertyValueMatched.length;i++){objPropertyValueReg["{[[-- css property-value syntax "+i+" --]]}"]=getPropertyValueSyntax(propertyValueMatched[i]);text=text.replace(propertyValueMatched[i],"{[[-- css property-value syntax "+i+" --]]}")}var directiveMatched=text.match(new RegExp("@[\\S]+[\\s]+[\\s\\S]*?[;|\n]","g"));var objDirectiveReg={};if(directiveMatched)for(var i=0;i<directiveMatched.length;i++){objDirectiveReg["{[[-- css directive syntax "+i+" --]]}"]=getDirectiveSyntax(directiveMatched[i]);
text=text.replace(directiveMatched[i],"{[[-- css directive syntax "+i+" --]]}")}function getPropertyValueSyntax(value){var separatedPropertyValues=value.substring(1,value.length-1).split(";");var propertyValueSyntax="";for(var i in separatedPropertyValues){var index=separatedPropertyValues[i].indexOf(":");if(index>0){var semicolon=";";if(i==separatedPropertyValues.length-1&&value.substring(value.length-1)!=";")semicolon="";propertyValueSyntax=propertyValueSyntax+'<FONT color="'+colorSyntaxProperty+
'">'+separatedPropertyValues[i].substring(0,index).replace(/\"/g,"&quot;").replace(/\'/g,"&#39;")+'</FONT>:<FONT color="'+colorSyntaxValue+'">'+separatedPropertyValues[i].substring(index+1).replace(/\"/g,"&quot;").replace(/\'/g,"&#39;")+"</FONT>"+semicolon}else propertyValueSyntax+=separatedPropertyValues[i].replace(/\"/g,"&quot;").replace(/\'/g,"&#39;")}return"{"+propertyValueSyntax+"}"}function getDirectiveSyntax(value){var valueLastIndex=value.length;var valueLast="";if(value.substring(value.length-
1)==";"){valueLastIndex-=1;valueLast=";"}var index=value.indexOf(" ");return'<FONT color="'+colorSyntaxProperty+'">'+value.substring(0,index).replace(/\"/g,"&quot;").replace(/\'/g,"&#39;")+'</FONT> <FONT color="'+colorSyntaxValue+'">'+value.substring(index+1,valueLastIndex).replace(/\"/g,"&quot;").replace(/\'/g,"&#39;")+"</FONT>"+valueLast}var selectorMatched=text.match(new RegExp("[;|}|>][\\s\\S]*?[{|<]","gm"));if(selectorMatched)for(var i=0;i<selectorMatched.length;i++){var replacedKey=selectorMatched[i].replace(/\//g,
"\\/").replace(/\?/g,"\\?").replace(/\$/g,"\\$").replace(/\{/g,"\\{").replace(/\}/g,"\\}").replace(/\[/g,"\\[").replace(/\]/g,"\\]").replace(/\*/g,"\\*").replace(/\(/g,"\\(").replace(/\)/g,"\\)").replace(/\|/g,"\\|").replace(/\+/g,"\\+");text=text.replace(new RegExp(replacedKey,"gm"),selectorMatched[i].substring(0,1)+'<FONT color="'+colorSyntaxSelector+'">'+selectorMatched[i].substring(1,selectorMatched[i].length-1).replace(/\"/g,"&quot;").replace(/\'/g,"&#39;").replace(/\$/g,"$$$$")+"</FONT>"+selectorMatched[i].substring(selectorMatched[i].length-
1))}for(var key in objDirectiveReg)text=text.replace(key,objDirectiveReg[key].replace(/\$/g,"$$$$"));for(var key in objPropertyValueReg)text=text.replace(key,objPropertyValueReg[key].replace(/\$/g,"$$$$"));for(var key in objBlockCommentsReg)text=text.replace(key,'<FONT color="'+colorSyntaxComments+'">'+objBlockCommentsReg[key].replace(/\"/g,"&quot;").replace(/\'/g,"&#39;").replace(/\$/g,"$$$$")+"</FONT>");return text.substring(1).replace(/\[\tamp\t\]/g,"&amp;").replace(/\[\tlt\t\]/g,"&lt;").replace(/\[\tgt\t\]/g,
"&gt;").replace(/\r\n/g,"\n").replace(/\n/g,"<BR />").replace(/\s\<BR \/\>/g,"&nbsp;<BR />").replace(/\s\s/g,"&nbsp; ")
	}
};