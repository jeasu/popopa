$$js_import$$("pohe_kr.m.slider.Resolver");
$$js_import$$("pohe_kr.m.slider.Service");