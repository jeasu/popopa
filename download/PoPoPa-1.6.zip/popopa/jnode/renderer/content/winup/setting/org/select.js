$content$.winup.setting.org.select = {
	service: function() {
		var that = this;

		$jnode$.requireController("tree", {caller:that.conf}).on(function() {
			var orgLi    = document.querySelector("aside.winup article > div.winup > ul:last-child > li:first-child");

			var orgDatas = that.dataset.orgDatas;

			function setTreeText(entrySet) {
				var textDiv = document.createElement("div");
				textDiv.setAttribute("class", (entrySet.org_parent ? "org" : "company"));
				textDiv.appendChild(document.createTextNode(entrySet.org_name));

				return textDiv;
			}

			function setTreeList(entrySet) {
				var list = entrySet.sub_org;
				return ((list && list.length) ? list : null);
			}

			function addTreeClickListener(textNode, entrySet) {
				var selectedNode = document.querySelector("aside.tree.org ul > li > span.selected");
				if (selectedNode) {
					selectedNode.removeAttribute("class");
				}

				textNode.setAttribute("class", "selected");
				orgLi.innerHTML = $jnode$.escapeXML(entrySet.org_name);
			}

			$controller$.tree.service({
				datas:     orgDatas,
				id:        function(entrySet) { return entrySet.org_id; },
				text:      setTreeText,
				list:      setTreeList,
				click:     addTreeClickListener,
				unfoldAll: true
			});

			document.querySelector("aside.winup article > div.winup > ul:last-child > li:last-child > button").addEventListener("click", function(event) {
				document.userForm.org_id.value   = document.querySelector("aside.tree.org ul > li > span.selected").parentNode.parentNode.getAttribute("id");
				document.userForm.org_name.value = $jnode$.escapeXML(orgLi.innerHTML);
				$controller$.winup.close();
			}, false);

			$controller$.tree.click(document.userForm.org_id.value);
		});
	}
};