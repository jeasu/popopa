$content$.article.setting.personal = {
	service: function() {
		var settingInfo = this.dataset.settingInfo;
		var systemInfo  = this.dataset.systemInfo;
		$jnode$.pushHistory(this.conf);

		document.querySelector("article > div.article > form > ul.submit > li > button:first-child").addEventListener("click", function(event) {
			$controller$.loading.show();
			var params = $jnode$.toJSON(document.settingForm);
			params.command = "updatePersonalSettings"

			$jnode$.ajax.service({
				"url":      "/ajax/setting.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  params,
				"success": function(response) {
					if (params.lang == settingInfo.lang) {
						$controller$.loading.hide();
					} else {
						$jnode$.requireContent("section", "/setting", {useLoading:true, articleId:"/setting/personal"});
					}
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);

		document.querySelector("article > div.article > form > ul.submit > li > button:last-child").addEventListener("click", function(event) {
			$controller$.loading.show();
			var params = $jnode$.toJSON(document.settingForm);
			params.command = "updatePersonalSettings"

			$jnode$.ajax.service({
				"url":      "/ajax/setting.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  {
					command: "initializeSettings"
				},
				"success": function(response) {
					if (systemInfo.lang == settingInfo.lang) {
						$jnode$.requireContent("article", "/setting/personal", {useLoading:true});
					} else {
						$jnode$.requireContent("section", "/setting", {useLoading:true, articleId:"/setting/personal"});
					}
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);
	}
};