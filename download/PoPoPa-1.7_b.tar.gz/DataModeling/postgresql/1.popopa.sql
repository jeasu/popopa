/*
DROP TABLE setting;
DROP TABLE code;
DROP TABLE usr;
DROP TABLE pos;
DROP TABLE org;
DROP TABLE team;
DROP TABLE project;
DROP TABLE member;
DROP TABLE task;
DROP TABLE note;
DROP TABLE history;
DROP TABLE version;
*/

-- -----------------------------------------------------
-- Table: setting
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS setting (
  user_id        VARCHAR(30) NOT NULL DEFAULT '-',
  setting_key    VARCHAR(30) NOT NULL,
  setting_value  VARCHAR(30) NOT NULL,
  CONSTRAINT pk_setting PRIMARY KEY (user_id, setting_key)
);

-- -----------------------------------------------------
-- Table: code
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS code (
  code_group  VARCHAR(30) NOT NULL DEFAULT '-',
  code_id     VARCHAR(30) NOT NULL,
  code_name   VARCHAR(50) NOT NULL,
  code_sort   INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_code PRIMARY KEY (code_group, code_id)
);

CREATE INDEX idx_code ON code(code_sort);

-- -----------------------------------------------------
-- Table: usr
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS usr (
  user_id        VARCHAR(45) NOT NULL,
  user_name      VARCHAR(50) NOT NULL,
  user_password  VARCHAR(50) NOT NULL,
  user_level     VARCHAR(3)  NOT NULL,
  user_changed   VARCHAR(20) NOT NULL,  /* YYYY-MM-ddTHH:mm:ss */
  user_retired   VARCHAR(20)     NULL,
  position_id    INT             NULL,
  org_id         INT             NULL,
  CONSTRAINT pk_usr PRIMARY KEY (user_id)
);

CREATE INDEX idx_usr ON usr(user_name, user_retired, position_id, org_id);

-- -----------------------------------------------------
-- Table: pos
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS pos (
  position_id    SERIAL,
  position_name  VARCHAR(50) NOT NULL,
  position_sort  INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_pos PRIMARY KEY (position_id)
);

CREATE INDEX idx_pos ON pos(position_sort);

/*
SELECT CASE 
         WHEN is_called THEN last_value + 1 ELSE last_value
       END AS nextval
  FROM pos_position_id_seq;

SELECT nextval(pg_get_serial_sequence('pos', 'position_id'))
*/

-- -----------------------------------------------------
-- Table: org
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS org (
  org_id      SERIAL,
  org_name    VARCHAR(50) NOT NULL,
  org_parent  INT         NOT NULL DEFAULT 0,
  org_sort    INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_org PRIMARY KEY (org_id)
);

CREATE INDEX idx_org ON org(org_sort);

-- -----------------------------------------------------
-- Table: team
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS team (
  team_manager     VARCHAR(45) NOT NULL,
  team_engineer    VARCHAR(45) NOT NULL,
  team_createdate  VARCHAR(20) NOT NULL,
  member_status    VARCHAR(10) NOT NULL DEFAULT 'reserved',
  CONSTRAINT pk_team PRIMARY KEY (team_manager, team_engineer)
);

CREATE INDEX idx_team ON team(member_status);

-- -----------------------------------------------------
-- Table: project
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS project (
  project_id    SERIAL,
  project_name  VARCHAR(100) NOT NULL,
  startdate     VARCHAR( 20) NOT NULL,
  enddate       VARCHAR( 20) NOT NULL,
  project_desc  TEXT             NULL,
  completion    VARCHAR( 20)     NULL,
  project_sort  INT          NOT NULL DEFAULT 0,
  CONSTRAINT pk_project PRIMARY KEY (project_id)
);

CREATE INDEX idx_project ON project(project_name);

-- -----------------------------------------------------
-- Table: member
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS member (
  group_type   VARCHAR(10) NOT NULL,
  group_id     INT         NOT NULL,
  user_id      VARCHAR(45) NOT NULL,
  member_type  VARCHAR(30) NOT NULL,
  member_sort  INT         NOT NULL DEFAULT 0,
  group_sort   INT         NOT NULL DEFAULT 0,
  CONSTRAINT pk_member PRIMARY KEY (group_type, group_id, user_id)
);

-- -----------------------------------------------------
-- Table: task
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS task (
  project_id   INT          NOT NULL,
  task_id      SERIAL,
  task_name    VARCHAR(100) NOT NULL,
  user_id      VARCHAR( 45)     NULL,
  startdate    VARCHAR( 20)     NULL,
  enddate      VARCHAR( 20)     NULL,
  progress     INT              NULL,
  task_parent  INT          NOT NULL DEFAULT 0,
  task_sort    INT          NOT NULL DEFAULT 0,
  CONSTRAINT pk_task PRIMARY KEY (task_id)
);

CREATE INDEX idx_task ON task(project_id, user_id, startdate, enddate, task_parent, task_sort);

-- -----------------------------------------------------
-- Table: note
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS note (
  project_id  INT          NOT NULL,
  task_id     INT          NOT NULL,
  note_id     SERIAL,
  note_name   VARCHAR(100) NOT NULL,
  note_type   VARCHAR( 10) NOT NULL,
  note_desc   TEXT         NOT NULL,
  action      TEXT             NULL,
  completion  VARCHAR(20)      NULL,
  CONSTRAINT pk_note PRIMARY KEY (note_id)
);

CREATE INDEX idx_note ON note(project_id, task_id);

-- -----------------------------------------------------
-- Table: history
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS history (
  history_id    SERIAL,
  project_id    INT         NOT NULL,
  user_id       VARCHAR(45) NOT NULL,
  history_date  TIMESTAMP   NOT NULL DEFAULT NOW(),
  history_type  VARCHAR(30) NOT NULL,
  target_id     VARCHAR(30) NOT NULL,
  target_name   VARCHAR(50) NOT NULL,
  target_crud   VARCHAR(1)  NOT NULL,
  CONSTRAINT pk_history PRIMARY KEY (history_id)
);

CREATE INDEX idx_history ON history(project_id, history_type);

-- -----------------------------------------------------
-- Table: version
-- -----------------------------------------------------
CREATE TABLE IF NOT EXISTS version (
  version_id    SERIAL,
  version_name  VARCHAR(20) NOT NULL,
  user_id       VARCHAR(45) NOT NULL,
  released      VARCHAR(20) NOT NULL,
  updated       VARCHAR(20) NOT NULL DEFAULT '0',  /* 0: start upgrade, 1: continue after rebooting, YYYY-MM-ddTHH:mm:ss: upgraded date */
  CONSTRAINT pk_version PRIMARY KEY (version_id)
);

/**********************************/
/* auth_level                     */
/**********************************/                              /* code_group  , code_id     , code_name   , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'         , 'auth_level', 'Auth level', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('auth_level', 'high'      , 'High'      , 0); /* 인증 실패시 ID와 비밀번호 중 틀린 부분을 알려 주지 않음. */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('auth_level', 'low'       , 'Low'       , 1); /* 인증 실패시 ID와 비밀번호 중 틀린 부분을 알려줌. */

/**********************************/
/* user_level                     */
/**********************************/                              /* code_group  , code_id     , code_name         , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'         , 'user_level', 'User level'      , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('user_level', '9'         , 'PoPoPa Admin'    , 0); /* admin */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('user_level', '1'         , 'Project Engineer', 1); /* pe     */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('user_level', '0'         , 'Admin Creator'   , 2); /* admin_creator */

/**********************************/
/* group_type                     */
/**********************************/                              /* code_group  , code_id     , code_name      , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'         , 'group_type', 'Group type'   , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('group_type', 'project'   , 'Project group', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('group_type', 'team'      , 'Team group'   , 1);

/**********************************/
/* member_type                    */
/**********************************/                              /* code_group   , code_id      , code_name    , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'          , 'member_type', 'Member type', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_type', 'manager'    , 'Manager'    , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_type', 'engineer'   , 'Engineer'   , 1);

/**********************************/
/* team_status                    */
/**********************************/                              /* code_group     , code_id        , code_name      , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'            , 'member_status', 'Member status', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_status', 'reserved'     , 'Reserved'     , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_status', 'included'     , 'Included'     , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_status', 'excluded'     , 'Excluded'     , 2);

/**********************************/
/* note_type                      */
/**********************************/                              /* code_group , code_id    , code_name  , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'        , 'note_type', 'Note type', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('note_type', 'memo'     , 'Memo'     , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('note_type', 'issue'    , 'Issue'    , 1);

/**********************************/
/* anchor_week                    */
/**********************************/                              /* code_group   , code_id      , code_name      , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'          , 'anchor_week', 'Base week'    , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_week', 'prev'       , 'Previous week', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_week', 'curr'       , 'Current week' , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_week', 'auto'       , 'Auto'         , 2);

/**********************************/
/* anchor_month                   */
/**********************************/                              /* code_group    , code_id       , code_name       , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'           , 'anchor_month', 'Base month'    , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_month', 'prev'        , 'Previous month', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_month', 'curr'        , 'Current month' , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_month', 'auto'        , 'Auto'          , 2);

/**********************************/
/* report_user                   */
/**********************************/                              /* code_group   , code_id      , code_name                     , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'          , 'report_user', 'Task of team members'        , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('report_user', 'member'     , 'Include task of team members', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('report_user', 'alone'      , 'Exclude task of team members', 1);

/**********************************/
/* history_type                   */
/**********************************/                              /* code_group    , code_id       , code_name     , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'           , 'history_type', 'History type', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'user'        , 'User'        , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'project'     , 'Project'     , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'task'        , 'Task'        , 2);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'weekly'      , 'Weekly'      , 3);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'monthly'     , 'Monthly'     , 4);

/**********************************/
/* 초기 설정 값                   */
/**********************************/                          /*  user_id, setting_key     , setting_value */
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'lang'          , 'auto'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'use_init_admin', 'true'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'update_account', 'false' );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'sync_setting'  , 'false' );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'use_org'       , 'false' );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'exclude_admin' , 'false' );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'auth_level'    , 'high'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'anchor_week'   , 'auto'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'anchor_month'  , 'auto'  );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'report_user'   , 'member');
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'display_user'  , 'false' );
INSERT INTO setting (user_id, setting_key, setting_value) VALUES ('-'    , 'start_page'    , 'gantt' );

/**********************************/
/* 초기 설정된 관리자             */
/**********************************/                                                                                  /* user_id   , user_name        , user_password, user_level, user_changed                                        , user_retired, position_id, org_id */
INSERT INTO usr (user_id, user_name, user_password, user_level, user_changed, user_retired, position_id, org_id) values ('${admin}', 'PoPoPa Customer', '${admin}'   , '0'       , TO_CHAR(CURRENT_TIMESTAMP,'YYYY-MM-DD"T"HH24:MI:SS'), NULL        , NULL       , NULL);
