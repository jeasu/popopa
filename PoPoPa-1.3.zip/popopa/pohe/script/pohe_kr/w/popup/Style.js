/*
 * @(#)pohe_kr.w.popup.Style.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.popup");

/**
 * Movable, Modallable, Resizable 가능한 POPUP의 Style 객체.
 * <BR/><BR/>
 * 
 * 아래의 속성들은 %를 사용할 수 없다.
 * 
 * <UL>
 *   <LI><CODE>pohe_kr.w.popup.Style[${styleclass}].popup.left</CODE></LI>
 *   <LI><CODE>pohe_kr.w.popup.Style[${styleclass}].popup.top</CODE></LI>
 *   <LI><CODE>pohe_kr.w.popup.Style[${styleclass}].popup.winwidth</CODE></LI>
 *   <LI><CODE>pohe_kr.w.popup.Style[${styleclass}].popup.winheight</CODE></LI>
 * </Ul>
 */
pohe_kr.w.popup.Style = {

	/**
	 * grobal style
	 */
	"$" : {
		popup: {
			left:null,
			top:null,
			winwidth:"320",
			winheight:"240",
			border:"3",
			bordercolor:"#8A9096",
			bgcolor:"#E9EDF1",
			winpadding:"2",
			zindex:null,
			modal:"opacity:-1; bgcolor:#C8CCD1"
		},
		title: {
			bgcolor:"#CED4DB",
			background:null,
			padding:"0px 3px",
			border:"0",
			bordercolor:"#8A9096"
		},
		content: {
			bgcolor:"#FFFFFF",
			background:null,
			margin:"5px",
			padding:"3px",
			border:"1",
			bordercolor:"#8A9096"
		}
	},

	".xp" : {
		popup: {
			left:null,
			top:null,
			winwidth:"320",
			winheight:"240",
			border:"3",
			bordercolor:"#0934DA",
			bgcolor:"#E9EDF1",
			winpadding:"0",
			zindex:null,
			modal:"opacity:-1; bgcolor:#C8CCD1"
		},
		title: {
			bgcolor:"#036FFB",
			background:"url('${pohe_img_base_url}/w/popup/xp_title_bg.png') repeat-x bottom",
			padding:"0px 3px",
			border:"0",
			bordercolor:"#8A9096"
		},
		content: {
			bgcolor:"#FFFFFF",
			background:null,
			margin:"0px",
			padding:"3px",
			border:"0",
			bordercolor:"#8A9096"
		}
	},
	
	/**
	 * no content border style
	 */
	".no_content_border" : {
		popup: {},
		title: {},
		content: {
			bgcolor:"#E9EDF1",
			margin:"0px",
			border:"0"
		}
	}
};