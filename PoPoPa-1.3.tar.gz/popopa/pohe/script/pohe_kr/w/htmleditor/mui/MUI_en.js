/*
 * @(#)pohe_kr.w.htmleditor.MUI_en.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.htmleditor");

/**
 * The English(en) Internationalization Object of HTMLEDITOR that is editable with WYSIWYG(What You See is What You Get).
 */
pohe_kr.w.htmleditor.MUI = {
	"defalut_font" : "Segoe UI",
	"font_name" : "Font Name",
	"font_size" : "Font Size",
	"font_color" : "Font Color",
	"highlight" : "Highlight",
	"bold" : "Bold",
	"italic" : "Italic",
	"underline" : "Underline",
	"strikethrough" : "Strikethrough",
	"superscript" : "Superscript",
	"subscript" : "Subscript",
	"leftpara" : "Align Left",
	"centerpara" : "Align Center",
	"rightpara" : "Align Right",
	"orderedlist" : "Formatting Numbers",
	"unorderedlist" : "Formatting Bullets",
	"outdent" : "Decrease Indentation",
	"indent" : "Increase Indentation",
	"cut" : "Cut",
	"copy" : "Copy",
	"paste" : "Paste",
	"paste_special" : "Paste Special",
	"remove_format" : "Remove Format",
	"undo" : "Undo",
	"redo" : "Redo",
	"refresh" : "Refresh",
	"hyperlink" : "Hyper Link",
	"table" : "Table",
	"picture" : "Picture",
	"picture_url" : "Picture URL",
	"picture_file" : "Picture File",
	"horizontalline" : "Horizontal Line",
	"datetime" : "Date / Time",
	"symbol" : "Symbol",
	"number" : "Number",
	"color" : "Color",
	"border" : "Border",
	"line_style" : "Line Style",
	"paste_text" : "Paste Plain Text",
	"paste_html" : "Paste As HTML",
	"paste_clipboard" : "Paste From Clipboard",
	"retrieve_file" : "Retrieve from file...",
	"retrieve_url" : "Retrieve from URL...",
	"mode_html" : "HTML Mode",
	"mode_text" : "Text Mode",
	"html_editor" : "HTML Editor",
	"html_source" : "HTML Source",
	"file" : "File",
	"url" : "URL",
	"ok" : "OK",
	"cancel" : "Cancel",
	"confirm" : "Confirm",
	"alert" : "Alert",
	"confirm_textmode_attention" : "By changing the formatting of this message from HTML to plain TEXT, you will lose any current formatting in the message. Select Ok to continue.",
	"alert_hyperlink" : "Select the range to create the Hyper link.",
	"alert_picture_pro_url" : "The setting for &quot;Retrieve from file...&quot; has not been, inquire the administrator.",
	"alert_picture_pro_file" : "The menu for &quot;Retrieve from file...&quot; of picturePro can be usued at the network environment only.",
	"alert_number_range_alert" : "The number must be between ${0} and ${1}.",
	"alert_number_greater0_alert" : "The number must be greater than 0."
};