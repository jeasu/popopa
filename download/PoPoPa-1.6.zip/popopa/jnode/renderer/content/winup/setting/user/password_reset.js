$content$.winup.setting.user.password_reset = {
	service: function() {
		var userId    = document.querySelector("aside.grid > div > table > tbody > tr.selected > td:nth-child(2)").firstChild.nodeValue;
		var alertNode = document.passwordForm.querySelector("form > ul.submit > li.alert");

		document.passwordForm.querySelector("form > ul.submit > li > button").addEventListener("click", function(event) {
			var params = {
				command:       "resetPassword",
				user_id:       userId,
				user_password: document.passwordForm.user_password.value
			};

			var confirmPassword = document.passwordForm.confirm_password.value;
			var alertMessage    = null;

			if (params.user_password == "") {
				alertMessage = i18n.alert_input_new_password;
				document.passwordForm.user_password.focus();
			} else if (params.user_password != confirmPassword) {
				alertMessage = i18n.alert_different_new_password;
				document.passwordForm.confirm_password.select();
			}
			
			if (alertMessage) {
				alertNode.innerHTML = alertMessage;
			} else {
				$controller$.loading.show();

				$jnode$.ajax.service({
					"url":      "/ajax/user.json",
					"method":   "POST",
					"datatype": "json",
					"headers": {
						"Content-Type": "application/json",
						"Accept":       "application/json"
					},
					"params":  params,
					"success": function(response) {
						$controller$.winup.close();
						$controller$.loading.hide();
					},
					"error": function(error) {
						$jnode$.ajax.alertError(error);
						$controller$.loading.hide();
					}
				});
			}
		}, false);

		document.passwordForm.user_password.focus();
	}
};