/**********************************/
/* auth_level                     */
/**********************************/                              /* code_group  , code_id     , code_name  , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'         , 'auth_level', '인증 등급', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('auth_level', 'high'      , '높음'     , 0); /* 인증 실패시 ID와 비밀번호 중 틀린 부분을 알려 주지 않음. */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('auth_level', 'low'       , '낮음'     , 1); /* 인증 실패시 ID와 비밀번호 중 틀린 부분을 알려줌. */

/**********************************/
/* user_level                     */
/**********************************/                              /* code_group  , code_id     , code_name        , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'         , 'user_level', '사용자 등급'    , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('user_level', '9'         , '관리자'         , 0); /* admin */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('user_level', '5'         , '프로젝트 관리자', 1); /* pm     */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('user_level', '1'         , '프로젝트 팀원'  , 2); /* pe     */
/* INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('user_level', '0'         , '관리자 생성자'  , 3); */ /* admin_creator */

/**********************************/
/* group_type                     */
/**********************************/                              /* code_group  , code_id     , code_name      , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'         , 'group_type', '그룹 유형'    , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('group_type', 'project'   , '프로젝트 그룹', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('group_type', 'team'      , '팀 그룹'      , 1);

/**********************************/
/* member_type                    */
/**********************************/                              /* code_group   , code_id      , code_name  , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'          , 'member_type', '팀원 유형', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_type', 'manager'    , '팀장'     , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_type', 'engineer'   , '팀원'     , 1);

/**********************************/
/* team_status                    */
/**********************************/                              /* code_group     , code_id        , code_name  , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'            , 'member_status', '팀원 상태', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_status', 'reserved'     , '대기중'   , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_status', 'included'     , '포함된'   , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('member_status', 'excluded'     , '제외된'   , 2);

/**********************************/
/* note_type                      */
/**********************************/                              /* code_group , code_id    , code_name  , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'        , 'note_type', '노트 유형', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('note_type', 'memo'     , '메모'     , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('note_type', 'issue'    , '이슈'     , 1);

/**********************************/
/* anchor_week                    */
/**********************************/                              /* code_group   , code_id      , code_name    , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'          , 'anchor_week', '기준 주(週)', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_week', 'prev'       , '지난주'     , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_week', 'curr'       , '이번주'     , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_week', 'auto'       , '자동'       , 2);

/**********************************/
/* anchor_month                   */
/**********************************/                              /* code_group    , code_id       , code_name    , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'           , 'anchor_month', '기준 월(月)', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_month', 'prev'        , '지난달'     , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_month', 'curr'        , '이번달'     , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('anchor_month', 'auto'        , '자동'       , 2);

/**********************************/
/* report_user                   */
/**********************************/                              /* code_group   , code_id      , code_name         , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'          , 'report_user', '보고서 출력 인원', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('report_user', 'member'     , '팀원 포함'       , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('report_user', 'alone'      , '내 업무만'       , 1);

/**********************************/
/* history_type                   */
/**********************************/                              /* code_group    , code_id       , code_name       , code_sort */
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('-'           , 'history_type', '이력 관리 유형', 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'user'        , '사용자'        , 0);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'project'     , '프로젝트'      , 1);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'task'        , '일감'          , 2);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'weekly'      , '주간보고'      , 3);
INSERT INTO code (code_group, code_id, code_name, code_sort) VALUES ('history_type', 'monthly'     , '월간보고'      , 4);