$$js_import$$("pohe_kr.w.switcher.Resolver");
$$js_import$$("pohe_kr.w.switcher.Service");