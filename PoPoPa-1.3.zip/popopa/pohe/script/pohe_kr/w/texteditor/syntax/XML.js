/*
 * @(#)pohe_kr.w.texteditor.syntax.XML.js  1.0, 2012-11-04
 *
 * Copyright (C) 2010 by Jeasu Kim. All rights reserved.
 *
 * @author  Jeasu Kim
 * @version 1.0, 2012-11-04
 */
$$js_namespace$$("pohe_kr.w.texteditor.syntax");

/**
 * TEXT 문자열에 XML 타입으로 color syntax를 보여주는 객체.
 */
pohe_kr.w.texteditor.syntax.XML = {

	/**
	 * TEXT 문자열에 XML 타입으로 설정할 syntax color.
	 */
	ColorSyntax: {
		"comments":       "#3F7F5F",
		"element":        "#6E6C00",
		"attributename":  "#7F007F",
		"attributevalue": "#2A00FF"
	},

	/**
	 * TEXT 문자열을 XML 타입으로 color syntax를 준다.
	 *
	 * @param  {String} text  {@nullable false} XML 타입으로 color syntax를 줄 TEXT 문자열
	 * @return {String} XML 타입으로 color syntax를 준 HTML 코드
	 */
	getColorSyntax: function(text) {
		var colorSyntaxComments=pohe_kr.w.texteditor.syntax.XML.ColorSyntax.comments;var colorSyntaxElement=pohe_kr.w.texteditor.syntax.XML.ColorSyntax.element;var colorSyntaxAttributename=pohe_kr.w.texteditor.syntax.XML.ColorSyntax.attributename;var colorSyntaxAttributevalue=pohe_kr.w.texteditor.syntax.XML.ColorSyntax.attributevalue;var matched=
null;text=text.replace(/\&/g,"\x26amp;").replace(/\</g,"\x26lt;").replace(/\>/g,"\x26gt;");var attrValueMatched=text.match(new RegExp("(\"[^\"]*\")|('[^']*')","gm"));text=text.replace(/\"/g,"\x26quot;").replace(/\'/g,"\x26#39;");matched=text.match(new RegExp("\x26lt;!--[\\s\\S]*?--\x26gt;","gm"));var objCommentsReg={};if(matched)for(var i=0;i<matched.length;i++){objCommentsReg["\x26lt;!-- comments "+i+" --\x26gt;"]=matched[i];text=text.replace(matched[i],'\x3cFONT color\x3d"'+colorSyntaxComments+
'"\x3e\x26lt;!-- comments '+i+" --\x26gt;\x3c/FONT\x3e")}matched=text.match(new RegExp("\x26lt;!\\[CDATA\\[[\\s\\S]*?\\]\\]\x26gt;","gm"));var objCdataReg={};if(matched)for(var i=0;i<matched.length;i++){var cdataValue=matched[i].substring(12,matched[i].length-6);var skipObjCdataReg=false;var commentsCheckMatched=cdataValue.match(new RegExp('\x3cFONT color\x3d"'+colorSyntaxComments+'"\x3e\x26lt;!-- comments\\s.*\\s--\x26gt;\x3c/FONT\x3e',"gm"));if(commentsCheckMatched){var commentsCheckMatcheds=[];
setCommentsCheckMatcheds(commentsCheckMatcheds,commentsCheckMatched[0]);for(var j=0;j<commentsCheckMatcheds.length;j++){var replacedValue=objCommentsReg[commentsCheckMatcheds[j].substring(22,commentsCheckMatcheds[j].length-7)];if(replacedValue==null){skipObjCdataReg=true;break}cdataValue=cdataValue.replace(commentsCheckMatcheds[j],replacedValue.replace(/\$/g,"$$$$"))}}function setCommentsCheckMatcheds(commentsCheckMatcheds,commentsCheckMatchedValue){var endIndex=commentsCheckMatchedValue.indexOf("--\x26gt;\x3c/FONT\x3e");
if(endIndex>0)if(commentsCheckMatchedValue.length-13>endIndex){commentsCheckMatcheds.push(commentsCheckMatchedValue.substring(0,endIndex+13));var startIndex=commentsCheckMatchedValue.indexOf('\x3cFONT color\x3d"'+colorSyntaxComments+'"\x3e\x26lt;!-- comments ',endIndex+13);if(startIndex>0)setCommentsCheckMatcheds(commentsCheckMatcheds,commentsCheckMatchedValue.substring(startIndex))}else commentsCheckMatcheds.push(commentsCheckMatchedValue)}if(skipObjCdataReg==false){var replacedValue='\x3cFONT color\x3d"'+
colorSyntaxElement+'"\x3e\x26lt;![CDATA[\x3c/FONT\x3e CDATA '+i+' \x3cFONT color\x3d"'+colorSyntaxElement+'"\x3e]]\x26gt;\x3c/FONT\x3e';var key='\x3cFONT color\x3d"'+colorSyntaxElement+'"\x3e\x26lt;![CDATA[\x3c/FONT\x3e CDATA '+i+' \x3cFONT color\x3d"'+colorSyntaxElement+'"\x3e]]\x3cFONT color\x3d"'+colorSyntaxElement+'"\x3e\x26gt;\x3c/FONT\x3e\x3c/FONT\x3e';objCdataReg[key]='\x3cFONT color\x3d"'+colorSyntaxElement+'"\x3e\x26lt;![CDATA[\x3c/FONT\x3e'+cdataValue+'\x3cFONT color\x3d"'+colorSyntaxElement+
'"\x3e]]\x26gt;\x3c/FONT\x3e';text=text.replace(matched[i],replacedValue)}}matched=text.match(new RegExp("(\x26lt;)/?(!\\w)?([\\w,\\-,:]+(\x26gt;)?|\\?xml)|(\\s|/|\\?)+(\x26gt;)","gm"));if(matched){var duplicatedChecks={};for(var i=0;i<matched.length;i++){var replacedKey=matched[i].replace(/\//g,"\\/").replace(/\?/g,"\\?");if(duplicatedChecks[matched[i]]==null){duplicatedChecks[matched[i]]=replacedKey;text=text.replace(new RegExp(replacedKey,"gm"),'\x3cFONT color\x3d"'+colorSyntaxElement+'"\x3e'+
matched[i]+"\x3c/FONT\x3e")}}}text=text.replace(/\&quot;\&gt;/g,'\x26quot;\x3cFONT color\x3d"'+colorSyntaxElement+'"\x3e\x26gt;\x3c/FONT\x3e');text=text.replace(/\&#39;\&gt;/g,'\x26#39;\x3cFONT color\x3d"'+colorSyntaxElement+'"\x3e\x26gt;\x3c/FONT\x3e');text=text.replace(/\)\&gt;/g,')\x3cFONT color\x3d"'+colorSyntaxElement+'"\x3e\x26gt;\x3c/FONT\x3e');text=text.replace(/\]\&gt;/g,']\x3cFONT color\x3d"'+colorSyntaxElement+'"\x3e\x26gt;\x3c/FONT\x3e');if(attrValueMatched){var duplicatedChecks={};for(var i=
0;i<attrValueMatched.length;i++){var key=attrValueMatched[i].replace(/\"/g,"\x26quot;").replace(/\'/g,"\x26#39;");var replacedKey=key.replace(/\//g,"\\/").replace(/\?/g,"\\?").replace(/\$/g,"\\$").replace(/\{/g,"\\{").replace(/\}/g,"\\}").replace(/\[/g,"\\[").replace(/\]/g,"\\]").replace(/\*/g,"\\*").replace(/\(/g,"\\(").replace(/\)/g,"\\)").replace(/\|/g,"\\|").replace(/\+/g,"\\+");if(duplicatedChecks[key]==null){duplicatedChecks[key]=replacedKey;text=text.replace(new RegExp(replacedKey,"gm"),'\x3cFONT color\x3d"'+
colorSyntaxAttributevalue+'"\x3e'+key.replace(/\$/g,"$$$$")+"\x3c/FONT\x3e")}}}matched=text.match(new RegExp("\\s[\\w,\\-,:]+\x3d\x3cFONT color\x3d","gm"));if(matched)for(var i=0;i<matched.length;i++)text=text.replace(new RegExp(matched[i],"gm"),matched[i].substring(0,1)+'\x3cFONT color\x3d"'+colorSyntaxAttributename+'"\x3e'+matched[i].substring(1,matched[i].length-13)+"\x3c/FONT\x3e\x3d\x3cFONT color\x3d");for(var key in objCdataReg)text=text.replace(key,objCdataReg[key].replace(/\$/g,"$$$$"));for(var key in objCommentsReg)text=
text.replace('\x3cFONT color\x3d"'+colorSyntaxComments+'"\x3e'+key+"\x3c/FONT\x3e",'\x3cFONT color\x3d"'+colorSyntaxComments+'"\x3e'+objCommentsReg[key].replace(/\$/g,"$$$$")+"\x3c/FONT\x3e");return text.replace(/\r\n/g,"\n").replace(/\n/g,"\x3cBR /\x3e").replace(/\s\<BR \/\>/g,"\x26nbsp;\x3cBR /\x3e").replace(/\s\s/g,"\x26nbsp; ")
	}
};

/**
 * TEXT 문자열에 color syntax를 보여 줄때 XML 타입과 동일한 syntax를 줄 DTD 타입의 객체
 */
pohe_kr.w.texteditor.syntax.DTD = pohe_kr.w.texteditor.syntax.XML;

/**
 * TEXT 문자열에 color syntax를 보여 줄때 XML 타입과 동일한 syntax를 줄 JSD 타입의 객체
 */
pohe_kr.w.texteditor.syntax.JSD = pohe_kr.w.texteditor.syntax.XML;

/**
 * TEXT 문자열에 color syntax를 보여 줄때 XML 타입과 동일한 syntax를 줄 TLD 타입의 객체
 */
pohe_kr.w.texteditor.syntax.TLD = pohe_kr.w.texteditor.syntax.XML;

/**
 * TEXT 문자열에 color syntax를 보여 줄때 XML 타입과 동일한 syntax를 줄 XSD 타입의 객체
 */
pohe_kr.w.texteditor.syntax.XSD = pohe_kr.w.texteditor.syntax.XML;

/**
 * TEXT 문자열에 color syntax를 보여 줄때 XML 타입과 동일한 syntax를 줄 XSD4J 타입의 객체
 */
pohe_kr.w.texteditor.syntax.XSD4J = pohe_kr.w.texteditor.syntax.XML;