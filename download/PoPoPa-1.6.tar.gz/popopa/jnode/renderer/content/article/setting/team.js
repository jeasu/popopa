$content$.article.setting.team = {
	appendUserInfo: function(row, userInfo) {
		var positionCell = row.insertCell(2);
		positionCell.appendChild(document.createTextNode(userInfo.position_name));

		var cellIndex = 3;

		if ($content$.article.setting.team.dataset.use_org) {
			var orgCell = row.insertCell(cellIndex++);
			orgCell.appendChild(document.createTextNode(userInfo.org_name));
		}

		var createCell = row.insertCell(cellIndex++);
		createCell.setAttribute("class", userInfo.team_createdate);
		createCell.appendChild(document.createTextNode(dateFormatter.format(dateUtil.parse(userInfo.team_createdate), dateFormatter.DateStyle.MEDIUM)));

		return cellIndex;
	},

	appendMyManager: function(managerInfo) {
		var managerId = managerInfo.manager_id;
		var status    = managerInfo.member_status;
		var tbody     = document.querySelector("aside.grid#my > div > table > tbody");
		var row       = document.createElement("tr");

		row.setAttribute("id", managerId);
		row.setAttribute("class", status);
		tbody.appendChild(row);

		var nameCell = row.insertCell(0);
		nameCell.appendChild(document.createTextNode(managerInfo.manager_name));

		// 모바일 화면을 위해 이름 뒤에 정보를 다 붙여 표시
		var nameSpan = document.createElement("span");
		nameCell.appendChild(nameSpan);
		nameSpan.appendChild(document.createTextNode("(" + managerId + " / " + managerInfo.position_name + ")"));

		if ($content$.article.setting.team.dataset.use_org) {
			nameSpan.appendChild(document.createTextNode(" @ " + managerInfo.org_name));
		}

		var idCell = row.insertCell(1);
		idCell.appendChild(document.createTextNode(managerId));

		var cellIndex = $content$.article.setting.team.appendUserInfo(row, managerInfo);

		var statusCell = row.insertCell(cellIndex++);
		statusCell.appendChild(document.createTextNode(i18n["label_" + status]));
		if (status != "included") {
			var cancelLink = document.createElement("a");
			cancelLink.appendChild(document.createTextNode(i18n.label_cancel));

			statusCell.appendChild(document.createTextNode(" ("));
			statusCell.appendChild(cancelLink);
			statusCell.appendChild(document.createTextNode(")"));

			cancelLink.addEventListener("click", function(event) {
				$controller$.prompt.confirm(i18n.confirm_cancel_join_team, function(close) {
					$controller$.loading.show();

					var params = {
						command:      "deleteMember",
						team_manager: managerId
					};

					$jnode$.ajax.service({
						"url":      "/ajax/team.json",
						"method":   "POST",
						"datatype": "json",
						"headers": {
							"Content-Type": "application/json",
							"Accept":       "application/json"
						},
						"params":  params,
						"success": function(response) {
							tbody.removeChild(tbody.querySelector("tbody > tr[id='" + managerId + "']"));

							$controller$.loading.hide();
						},
						"error": function(error) {
							$jnode$.ajax.alertError(error);
							$controller$.loading.hide();
						}
					});

					close();
				});
			}, false);
		}
	},

	appendEngineer: function(engineerInfo) {
		var engineerId = engineerInfo.engineer_id;
		var status     = engineerInfo.member_status;
		var tbody      = document.querySelector("aside.grid#included > div > table > tbody");
		var row        = document.createElement("tr");

		row.setAttribute("id", engineerId);
		tbody.appendChild(row);

		var nameCell = row.insertCell(0);
		var idCell   = row.insertCell(1);
		var nameSpan = document.createElement("span");
		var engineerOrigId = engineerId

		if (engineerInfo.engineer_id.search(/^[$][{].+[}]$/) == 0) {
			engineerOrigId = engineerId.substring(13, engineerId.length - 1);
			var retireeSpan = document.createElement("span");
			retireeSpan.appendChild(document.createTextNode(i18n.label_retiree + ": " + engineerInfo.engineer_name));
			retireeSpan.appendChild(nameSpan);

			nameCell.setAttribute("class", "retiree");
			nameCell.appendChild(retireeSpan);

			idCell.appendChild(document.createTextNode(engineerOrigId));
		} else {
			nameCell.appendChild(document.createTextNode(engineerInfo.engineer_name));
			nameCell.appendChild(nameSpan);
			idCell.appendChild(document.createTextNode(engineerId));
		}

		// 모바일 화면을 위해 이름 뒤에 정보를 다 붙여 표시
		nameSpan.appendChild(document.createTextNode("(" + engineerOrigId + " / " + engineerInfo.position_name + ")"));

		if ($content$.article.setting.team.dataset.use_org) {
			nameSpan.appendChild(document.createTextNode(" @ " + engineerInfo.org_name));
		}

		var cellIndex = $content$.article.setting.team.appendUserInfo(row, engineerInfo);

		var excludeLink = document.createElement("a");
		excludeLink.appendChild(document.createTextNode(i18n.label_exclude));

		var excludeCell = row.insertCell(cellIndex++);
		excludeCell.appendChild(excludeLink);

		excludeLink.addEventListener("click", function(event) {
			$controller$.loading.show();

			var params = {
				command:       "changeMemberStatus",
				team_engineer: engineerId,
				member_status: "excluded"
			};

			$jnode$.ajax.service({
				"url":      "/ajax/team.json",
				"method":   "POST",
				"datatype": "json",
				"headers": {
					"Content-Type": "application/json",
					"Accept":       "application/json"
				},
				"params":  params,
				"success": function(response) {
					var excludedCountSpan = document.querySelector("div.section > article > div.article > fieldset:last-child > div > div > button:last-child > div > span:last-child");
					excludedCountSpan.innerHTML = (parseInt(excludedCountSpan.innerHTML, 10) + response.changed_count).toString();

					if (response.changed_count > 0) {
						excludedCountSpan.parentNode.parentNode.disabled = false;
					}

					tbody.removeChild(tbody.querySelector("tbody > tr[id='" + engineerId + "']"));

					$controller$.loading.hide();
				},
				"error": function(error) {
					$jnode$.ajax.alertError(error);
					$controller$.loading.hide();
				}
			});
		}, false);
	},

	resize: function() {
		var windowWidth  = window.innerWidth;
		var windowHeight = window.innerHeight;
		var myTHeadCols  = document.querySelectorAll("aside.grid#my > ul > li:first-child > div > table > colgroup > col");
		var myTbodyCols  = document.querySelectorAll("aside.grid#my > div > table > colgroup > col");
		var inTHeadCols  = document.querySelectorAll("aside.grid#included > ul > li:first-child > div > table > colgroup > col");
		var inTbodyCols  = document.querySelectorAll("aside.grid#included > div > table > colgroup > col");

		var cellCount = 3;
		var widthP    = "33.3333%";

		if (useOrg) {
			cellCount = 4;
			widthP    = "25%";
		}

		if (windowWidth > 736) {
			var gridAllHeight = (windowHeight - 229);
			var gridMyHeight  = Math.max(gridAllHeight / 4, 67);

			$controller$["grid#my"].resize(null, gridMyHeight);
			$controller$["grid#included"].resize(null, gridAllHeight - gridMyHeight);
		} else {
			$controller$["grid#my"].removeHeight();
			$controller$["grid#included"].removeHeight();
		}

		if (windowWidth > 544) {
			for (var i = 0; i < cellCount; i++) {
				myTHeadCols[i].style.width = widthP;
				myTbodyCols[i].style.width = widthP;
				inTHeadCols[i].style.width = widthP;
				inTbodyCols[i].style.width = widthP;
			}

			/*
			myTHeadCols[cellCount].style.width = "90px";
			myTbodyCols[cellCount].style.width = "90px";
			inTHeadCols[cellCount].style.width = "90px";
			inTbodyCols[cellCount].style.width = "90px";
			*/
		} else {
			myTHeadCols[0].style.width = "100%";
			myTbodyCols[0].style.width = "100%";
			inTHeadCols[0].style.width = "100%";
			inTbodyCols[0].style.width = "100%";

			for (var i = 1; i < cellCount; i++) {
				myTHeadCols[i].style.width = "0px";
				myTbodyCols[i].style.width = "0px";
				inTHeadCols[i].style.width = "0px";
				inTbodyCols[i].style.width = "0px";
			}
		}

		$controller$["grid#my"].resizeScrollButtons();
		$controller$["grid#included"].resizeScrollButtons();
	},

	service: function() {
		$controller$.loading.show();
		var that = this;
		$jnode$.pushHistory(that.conf);

		var joinButton       = document.querySelector("div.section > article > div.article > fieldset:first-child > div > div > button:first-child");
		var requestingButton = document.querySelector("div.section > article > div.article > fieldset:last-child > div > div > button:first-child");
		var excludedButton   = document.querySelector("div.section > article > div.article > fieldset:last-child > div > div > button:last-child");

		var reservedCount = that.dataset.reservedCount;
		var excludedCount = that.dataset.excludedCount;
		
		requestingButton.firstElementChild.lastElementChild.innerHTML = reservedCount;
		excludedButton.firstElementChild.lastElementChild.innerHTML   = excludedCount;

		if (reservedCount == 0)  requestingButton.disabled = true;
		if (excludedCount == 0)  excludedButton.disabled = true;

		$jnode$.requireControllers(["grid#my", "grid#included"], {caller:that.conf}, function() {
			$controller$["grid#my"].service({sortable:true});
			$controller$["grid#included"].service({sortable:true});
			window.addEventListener("resize", that.resize, false);
			that.resize();

			var managerList  = that.dataset.managerList;
			var engineerList = that.dataset.engineerList;

			for (var i = 0; i < managerList.length; i++) {
				that.appendMyManager(managerList[i]);
			}

			for (var i = 0; i < engineerList.length; i++) {
				that.appendEngineer(engineerList[i]);
			}

			$controller$.loading.hide();
		});

		joinButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/team/manager", {
				useLoading: true,
				icon:       true,
				title:      i18n.label_select_team_manager,
				width:      360,
				height:     349
			});
		}, false);

		requestingButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/team/requesting", {
				useLoading: true,
				icon:       true,
				title:      i18n.label_select_requesting_team_member,
				width:      500,
				height:     349
			});
		}, false);

		excludedButton.addEventListener("click", function(event) {
			$jnode$.requireContent("winup", "/setting/team/excluded", {
				useLoading: true,
				icon:       true,
				title:      i18n.label_select_excluded_team_member,
				width:      500,
				height:     349
			});
		}, false);
	},

	unload: function() {
		window.removeEventListener("resize", this.resize, false);
	}
};